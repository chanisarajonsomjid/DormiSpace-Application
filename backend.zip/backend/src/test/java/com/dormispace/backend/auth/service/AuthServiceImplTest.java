package com.dormispace.backend.auth.service;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.server.ResponseStatusException;

import com.dormispace.backend.apartment.model.Apartment;
import com.dormispace.backend.apartment.repository.ApartmentRepository;
import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.user.model.AccountStatus;
import com.dormispace.backend.user.model.Role;
import com.dormispace.backend.user.model.User;
import com.dormispace.backend.user.repository.LandlordRepository;
import com.dormispace.backend.user.repository.UserRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;

@ExtendWith(MockitoExtension.class)
class AuthServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private LandlordRepository landlordRepository;

    @Mock
    private ApartmentRepository apartmentRepository;

    @Mock
    private ContractRepository contractRepository;

    @Mock
    private FirebaseAuth firebaseAuth; // No static mocking needed!

    @Mock
    private FirebaseToken firebaseToken;

    @InjectMocks
    private AuthServiceImpl authService;

    @Test
    void authenticate_validToken_bindsFirebaseUid() throws Exception {
        // Arrange
        String tokenStr = "valid-token";
        String email = "tenant@example.com";
        String uid = "fb-uid-123";

        when(firebaseAuth.verifyIdToken(tokenStr)).thenReturn(firebaseToken);
        when(firebaseToken.getEmail()).thenReturn(email);
        when(firebaseToken.getUid()).thenReturn(uid);

        User user = User.builder()
                .id(1L)
                .email(email)
                .role(Role.LANDLORD)
                .firebaseUid(null) // First time login
                .accountStatus(AccountStatus.PENDING)
                .build();

        when(userRepository.findByEmail(email.toLowerCase())).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenAnswer(i -> i.getArguments()[0]);
        when(apartmentRepository.findByUserId(1L)).thenReturn(java.util.Collections.emptyList());

        // Act
        AuthenticatedUser result = authService.authenticate(tokenStr);

        // Assert
        assertEquals(uid, user.getFirebaseUid());
        assertEquals(AccountStatus.ACTIVE, user.getAccountStatus());
        verify(userRepository).save(user);
    }

    @Test
    void authenticate_mismatchedUid_throwsUnauthorized() throws Exception {
        String tokenStr = "valid-token";
        when(firebaseAuth.verifyIdToken(tokenStr)).thenReturn(firebaseToken);
        when(firebaseToken.getEmail()).thenReturn("hacker@example.com");
        when(firebaseToken.getUid()).thenReturn("wrong-uid");

        User existingUser = User.builder()
                .email("hacker@example.com")
                .firebaseUid("original-uid")
                .build();

        when(userRepository.findByEmail("hacker@example.com")).thenReturn(Optional.of(existingUser));

        assertThrows(ResponseStatusException.class, () -> authService.authenticate(tokenStr));
    }

    @Test
    void authenticate_tenantWithContract_setsApartmentId() throws Exception {
        // Arrange
        String tokenStr = "tenant-token";
        String email = "tenant@example.com";
        String uid = "tenant-fb-uid";

        when(firebaseAuth.verifyIdToken(tokenStr)).thenReturn(firebaseToken);
        when(firebaseToken.getEmail()).thenReturn(email);
        when(firebaseToken.getUid()).thenReturn(uid);

        User user = User.builder()
                .id(2L)
                .email(email)
                .role(Role.TENANT)
                .firebaseUid(null)
                .accountStatus(AccountStatus.PENDING)
                .build();

        when(userRepository.findByEmail(email.toLowerCase())).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenAnswer(i -> i.getArguments()[0]);

        Apartment apartment = new Apartment();
        apartment.setApartmentId(99L);

        Room room = new Room();
        room.setApartment(apartment);

        Contract contract = new Contract();
        contract.setRoom(room);

        when(contractRepository.findTopByTenantIdOrderByCreatedAtDesc(2L)).thenReturn(Optional.of(contract));

        // Act
        AuthenticatedUser result = authService.authenticate(tokenStr);

        // Assert
        assertEquals(99L, result.getApartmentId());
        assertEquals(Role.TENANT, result.getRole());
    }
}
