package com.dormispace.backend.auth.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.auth.service.AuthService;
import com.dormispace.backend.user.dto.RegisterLandlordRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public AuthenticatedUser login(Authentication authentication) {

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("Unauthenticated");
        }

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        System.out.println(
                "[AUTH LOGIN] userId = " + user.getUserId() +
                        ", email = " + user.getEmail() +
                        ", role = " + user.getRole()
        );

        return user;
    }

    @PostMapping("/register-landlord")
    public AuthenticatedUser registerLandlord(
            @RequestHeader("Authorization") String authHeader,
            @RequestBody RegisterLandlordRequest request) {

        if (!authHeader.startsWith("Bearer ")) {
            throw new RuntimeException("Missing token");
        }

        String token = authHeader.substring(7);

        return authService.registerLandlord(token, request);
    }
}