package com.dormispace.backend.bill.dto;

import lombok.Data;

@Data
public class PromptPayRequest {
    private Long billId;
}