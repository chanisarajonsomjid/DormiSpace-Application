package com.dormispace.backend.maintenance.repository;

import com.dormispace.backend.maintenance.model.Issue;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IssueRepository extends JpaRepository<Issue, Long> {

    Page<Issue> findByUserId(Long userId, Pageable pageable);

    Page<Issue> findByRoom_Apartment_Landlord_User_Id(Long userId, Pageable pageable);
}