package com.dormispace.backend.bill.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

import java.math.BigDecimal;

/**
 * Request DTO for creating or updating utility settings.
 *
 * Using a dedicated DTO instead of the raw @Entity prevents clients from
 * injecting internal fields like `id` or `apartmentId` via the request body.
 */
public record UtilitySettingRequest(

        // WATER
        BigDecimal waterRate,
        BigDecimal waterMinimum,
        Boolean useWaterMinimum,

        // ELECTRIC
        BigDecimal electricRate,
        BigDecimal electricMinimum,
        Boolean useElectricMinimum,

        // COMMON AREA
        BigDecimal commonAreaFee,

        // LATE FEE
        BigDecimal lateFeePerDay,
        BigDecimal maxLateFee,

        // BILLING CYCLE
        @Min(value = 1,  message = "Billing day must be at least 1")
        @Max(value = 28, message = "Billing day must be at most 28")
        Integer billingDayOfMonth,

        // PAYMENT
        String bankAccountName,
        String bankAccountNumber

) {}
