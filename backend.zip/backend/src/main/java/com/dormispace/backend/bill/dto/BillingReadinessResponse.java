package com.dormispace.backend.bill.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingReadinessResponse {
    private boolean utilitySettingExists;
    private boolean utilitySettingComplete;

    private boolean billingDayConfigured;
    private boolean bankAccountConfigured;

    private int totalOccupiedRooms;
    private int totalBillableRooms;
    private int readyRooms;

    private boolean hasBillableRooms;
    private boolean allMetersReady;

    private boolean canCollectMeter;
    private boolean canAccessBills;
    private boolean canSendBills;

    private List<String> reasons;
    private List<RoomReadinessItem> roomIssues;
}
