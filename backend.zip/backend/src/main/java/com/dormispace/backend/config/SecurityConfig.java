package com.dormispace.backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfigurationSource;

import com.dormispace.backend.auth.filter.JwtAuthenticationFilter;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final CorsConfigurationSource corsConfigurationSource;
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                .cors(cors -> cors.configurationSource(corsConfigurationSource))
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )

                .authorizeHttpRequests(auth -> auth
                        // 🔥 Allow H2 console
                        .requestMatchers("/h2-console/**").permitAll()

                        // 🔥 Public endpoints
                        .requestMatchers(
                                "/h2-console/**",
                                "/api/auth/**",
                                "/health",
                                "/public/**",

                                // 🔥 Invitation
                                "/invitation/**",
                                "/api/invitation/**",

                                "/api/webhook/**",
                                "/api/ocr/**",

                                // 🔥 fixed typo
                                "/api/v1/bill-payments/create-promptpay"
                        ).permitAll()

                        // 🔥 Secure API
                        .requestMatchers("/api/**").authenticated()

                        // 🔥 Everything else denied
                        .anyRequest().denyAll()
                )

                // 🔥 Required for H2 console (iframe support)
                .headers(headers ->
                        headers.frameOptions(frame -> frame.disable())
                )

                .addFilterBefore(
                        jwtAuthenticationFilter,
                        UsernamePasswordAuthenticationFilter.class
                );

        return http.build();
    }
}