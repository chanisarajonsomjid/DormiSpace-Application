package com.dormispace.backend.ocr.service;

import com.dormispace.backend.ocr.dto.OcrRequestDto;
import com.dormispace.backend.ocr.dto.OcrResultDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Set;

@Slf4j
@Service
@RequiredArgsConstructor
public class MeterOcrService {

    private final GoogleVisionOcrService visionService;

    private static final Set<String> ALLOWED_CONTENT_TYPES = Set.of(
            "image/jpeg", "image/png", "image/webp",
            "image/heic", "image/heif"   // FIX: added image/heif for iOS
    );
    private static final long MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;
    private static final int  MAX_READING_VALUE   = 9_999_999;

    public OcrResultDto process(MultipartFile imageFile,
                                OcrRequestDto request) throws IOException {
        validateFile(imageFile);

        log.info("OCR request: roomId={} meterType={} previousReading={} source={}",
                request.getRoomId(), request.getMeterType(),
                request.getPreviousReading(), request.getReadingSource());

        // Pass readingSource into Vision service for logging/confidence weighting
        GoogleVisionOcrService.OcrExtractionResult extraction =
                visionService.extractMeterReading(imageFile, request.getReadingSource());

        if (!extraction.found()) {
            return OcrResultDto.builder()
                    .roomId(request.getRoomId())
                    .meterType(request.getMeterType())
                    .valid(false)
                    .message(extraction.message())
                    .rawText(extraction.rawText())
                    .confidence(extraction.confidence())
                    .readingSource(request.getReadingSource())
                    .build();
        }

        String  validationMessage = sanityCheck(extraction.value(), request);
        boolean isValid           = validationMessage == null && extraction.meetsThreshold();
        String  finalMessage      = validationMessage != null
                ? validationMessage : extraction.message();

        log.info("OCR result: roomId={} reading={} confidence={} valid={} source={}",
                request.getRoomId(), extraction.value(),
                extraction.confidence(), isValid, extraction.readingSource());

        return OcrResultDto.builder()
                .roomId(request.getRoomId())
                .meterType(request.getMeterType())
                .extractedReading(extraction.value())
                .rawText(extraction.rawText())
                .confidence(extraction.confidence())
                .valid(isValid)
                .message(finalMessage)
                .readingSource(extraction.readingSource())  // "CAMERA", "GALLERY", or null
                .build();
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty())
            throw new IllegalArgumentException("Image file must not be empty.");
        if (file.getSize() > MAX_FILE_SIZE_BYTES)
            throw new IllegalArgumentException("Image exceeds maximum allowed size of 10 MB.");
        String ct = file.getContentType();
        if (ct == null || !ALLOWED_CONTENT_TYPES.contains(ct))
            throw new IllegalArgumentException(
                    "Unsupported image format. Allowed: JPEG, PNG, WEBP, HEIC.");
    }

    private String sanityCheck(int reading, OcrRequestDto request) {
        if (reading < 0 || reading > MAX_READING_VALUE)
            return "Extracted reading " + reading
                    + " is out of expected range (0–9,999,999).";

        Integer previous = request.getPreviousReading();
        if (previous != null) {
            if (reading < previous)
                return String.format(
                        "Warning: extracted reading (%d) is less than previous (%d). Please verify.",
                        reading, previous);
            if (reading - previous > 2000)
                return String.format(
                        "Warning: unusually high usage (%d units). Please verify.",
                        reading - previous);
        }
        return null;
    }
}