package com.dormispace.backend.room.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.room.dto.ContractDraftResponse;
import com.dormispace.backend.room.dto.RoomResponse;
import com.dormispace.backend.room.dto.RoomWithContractStatusResponse;
import com.dormispace.backend.room.service.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    @GetMapping("/with-contract-status")
    public List<RoomWithContractStatusResponse> getRoomsWithContractStatus(
            @AuthenticationPrincipal AuthenticatedUser user
    ) {
        return roomService.getRoomsWithContractStatus(user.getUserId());
    }

    @GetMapping("/{roomId}/contract/current")
    public ResponseEntity<?> getCurrentContract(
            @PathVariable Long roomId,
            @AuthenticationPrincipal AuthenticatedUser user
    ) {
        return ResponseEntity.ok(roomService.getCurrentContractResponse(roomId, user));
    }

    @GetMapping("/{id}")
    public RoomResponse getRoom(
            @PathVariable Long id,
            @AuthenticationPrincipal AuthenticatedUser user
    ) {
        return new RoomResponse(
                roomService.getRoomByIdSecure(id, user)
        );
    }

    @GetMapping("/{roomId}/contract-draft")
    public ResponseEntity<ContractDraftResponse> getContractDraft(
            @PathVariable Long roomId,
            @AuthenticationPrincipal AuthenticatedUser user
    ) {
        return ResponseEntity.ok(
                roomService.getContractDraft(roomId, user)
        );
    }
}