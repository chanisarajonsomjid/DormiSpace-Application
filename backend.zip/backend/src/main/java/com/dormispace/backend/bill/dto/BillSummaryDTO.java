package com.dormispace.backend.bill.dto;

import com.dormispace.backend.bill.model.Bill_Item;
import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.model.PaymentMethod;
import com.dormispace.backend.bill.model.PaymentStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * DTO for individual bill summary
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillSummaryDTO {
    private Long billId;
    private Long roomId;
    private Long userId;
    private Long apartmentId;
    private String roomNumber;
    private String tenantName;
    
    // Dates
    private LocalDate createdDate;
    private LocalDate paymentDate;
    private LocalDate receiptDate;
    private LocalDate dueDate;
    
    // Amounts
    private BigDecimal subtotal;
    private BigDecimal lateFee;
    private BigDecimal totalAmount;
    
    // Status
    private PaymentStatus paymentStatus;
    private PaymentMethod paymentMethod;
    
    // Breakdown (optional)
    private BigDecimal waterCharge;
    private BigDecimal electricityCharge;
    private BigDecimal rentCharge;
    private BigDecimal otherCharges;
    
    // Metadata
    private Integer waterUnitsUsed;
    private Integer electricityUnitsUsed;

    public static BillSummaryDTO from(Bill_Payment bill, List<Bill_Item> items) {
        BigDecimal water = BigDecimal.ZERO;
        BigDecimal electric = BigDecimal.ZERO;
        BigDecimal rent = BigDecimal.ZERO;
        BigDecimal other = BigDecimal.ZERO;
        Integer waterUnits = null;
        Integer elecUnits = null;

        for (Bill_Item item : items) {
            switch (item.getItemType()) {
                case "WATER"   -> { water = item.getTotalAmount();
                    waterUnits = item.getUsage(); }
                case "ELECTRIC"-> { electric = item.getTotalAmount();
                    elecUnits = item.getUsage(); }
                case "RENT"    -> rent = item.getTotalAmount();
                case "FIXED"   -> other = other.add(item.getTotalAmount());
            }
        }

        return BillSummaryDTO.builder()
                .billId(bill.getBillId())
                .roomId(bill.getRoomId())
                .userId(bill.getUserId())
                .tenantName(null)
                .createdDate(bill.getCreatedDate())
                .paymentDate(bill.getPaymentDate())
                .dueDate(bill.getDueDate())
                .subtotal(bill.getSubtotal())
                .lateFee(bill.getLateFee())
                .totalAmount(bill.getTotalAmount())
                .paymentStatus(bill.getPaymentStatus())
                .paymentMethod(bill.getPaymentMethod())
                .waterCharge(water)
                .electricityCharge(electric)
                .rentCharge(rent)
                .otherCharges(other)
                .waterUnitsUsed(waterUnits)
                .electricityUnitsUsed(elecUnits)
                .build();
    }
}