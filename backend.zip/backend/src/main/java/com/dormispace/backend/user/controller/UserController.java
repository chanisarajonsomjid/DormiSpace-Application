package com.dormispace.backend.user.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.user.dto.UserResponse;
import com.dormispace.backend.user.model.User;
import com.dormispace.backend.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor

public class UserController {

    private final UserService userService;

    @GetMapping("/me")
    public UserResponse me(@RequestAttribute("authUser") AuthenticatedUser authUser) {
        User user = userService.findById(authUser.getUserId());
        return UserResponse.from(user);
    }
}
