package com.dormispace.backend.contract.service;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.user.model.AccountStatus;
import com.dormispace.backend.user.model.User;
import com.dormispace.backend.user.repository.UserRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class InvitationService {

    private final ContractRepository contractRepository;
    private final UserRepository userRepository;

    // Step 1: Validate token and return tenant email
    public String validateTokenAndGetEmail(String token) {
        Contract contract = contractRepository
                .findByInvitationToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid invitation token"));

        // Check if token is expired
        if (contract.getTokenExpiresAt().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Invitation token has expired");
        }

        // Check if already accepted
        if ("ACCEPTED".equals(contract.getInvitationStatus())) {
            throw new RuntimeException("Invitation already accepted");
        }

        return contract.getTenant().getEmail();
    }

    // Step 2: Generate Firebase custom token for existing user
    public String generateCustomToken(String token) {
        Contract contract = contractRepository
                .findByInvitationToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid invitation token"));

        // Check expiry
        if (contract.getTokenExpiresAt().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token expired");
        }

        String firebaseUid = contract.getTenant().getFirebaseUid();

        if (firebaseUid == null || firebaseUid.isEmpty()) {
            throw new RuntimeException("User has no Firebase account yet");
        }

        try {
            return FirebaseAuth.getInstance().createCustomToken(firebaseUid);
        } catch (FirebaseAuthException e) {
            throw new RuntimeException("Failed to generate Firebase token: " + e.getMessage());
        }
    }

    // Step 3: Complete setup - mark invitation as accepted, activate user
    @Transactional
    public void completeSetup(String token, AuthenticatedUser authUser) {
        Contract contract = contractRepository
                .findByInvitationToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid invitation token"));

        // Update invitation status
        contract.setInvitationStatus("ACCEPTED");
        contractRepository.save(contract);

        // Update user to ACTIVE
        User tenant = userRepository.findById(authUser.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        tenant.setAccountStatus(AccountStatus.ACTIVE);
        userRepository.save(tenant);

        System.out.println("Tenant setup complete: " + tenant.getEmail());
    }
}