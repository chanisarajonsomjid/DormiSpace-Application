package com.dormispace.backend.contract.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${app.invitation.base-url}")
    private String baseUrl;

    public void sendInvitationEmail(
            String tenantEmail,
            String landlordEmail,
            String roomNumber,
            String apartmentName,
            String invitationToken  // ✅ ADD TOKEN PARAMETER
    ) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(tenantEmail);
            helper.setFrom(landlordEmail);
            helper.setSubject("🏠 You've been invited to " + apartmentName);

            // ✅ Firebase Dynamic Link with token
            String invitationLink = baseUrl + "/invitation?token=" + invitationToken;

            String htmlContent = """
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <div style="background-color: #1B434D; padding: 20px; text-align: center;">
                        <h1 style="color: white;">Moonlight Apartment</h1>
                    </div>
                    <div style="padding: 30px;">
                        <h2>You've Been Invited! 🎉</h2>
                        <p>You have been invited to sign a rental contract for:</p>
                        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 8px; margin: 20px 0;">
                            <p><strong>Apartment:</strong> %s</p>
                            <p><strong>Room:</strong> %s</p>
                        </div>
                        <p>Click the button below to set up your account and review your contract:</p>
                        <div style="text-align: center; margin: 30px 0;">
                            <a href="%s"
                               style="background-color: #F2A961;
                                      color: white;
                                      padding: 15px 30px;
                                      text-decoration: none;
                                      border-radius: 8px;
                                      font-size: 16px;
                                      font-weight: bold;">
                                Set Up Account & View Contract
                            </a>
                        </div>
                        <p style="color: #666; font-size: 14px;">
                            ⚠️ This invitation expires in 7 days.
                        </p>
                        <p style="color: #666; font-size: 14px;">
                            If you didn't expect this email, please ignore it.
                        </p>
                    </div>
                </div>
            """.formatted(apartmentName, roomNumber, invitationLink);

            helper.setText(htmlContent, true);
            mailSender.send(message);

            System.out.println("✅ Invitation email sent to: " + tenantEmail);

        } catch (MessagingException e) {
            System.out.println("❌ Failed to send email: " + e.getMessage());
            throw new RuntimeException("Failed to send invitation email: " + e.getMessage());
        }
    }

    // ✅ Resend invitation
    public void resendInvitationEmail(
            String tenantEmail,
            String landlordEmail,
            String roomNumber,
            String apartmentName,
            String invitationToken
    ) {
        // Same as send but with "Reminder" subject
        sendInvitationEmail(
                tenantEmail,
                landlordEmail,
                roomNumber,
                apartmentName,
                invitationToken
        );
    }
}