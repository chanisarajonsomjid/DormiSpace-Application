package com.dormispace.backend.bill.service;

import com.dormispace.backend.apartment.model.Apartment;
import com.dormispace.backend.apartment.repository.ApartmentRepository;
import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.bill.model.*;
import com.dormispace.backend.bill.repository.*;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.room.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Optional;

/**
 * Service for calculating bills based on meter readings and fixed costs
 */
@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class BillCalculationService {

    private final WaterMeterRepository waterMeterRepository;
    private final ElectricityMeterRepository electricityMeterRepository;
    private final FixedCostRepository fixedCostRepository;
    private final BillPaymentRepository billPaymentRepository;
    private final UtilitySettingRepository utilitySettingRepository;
    private final BillItemRepository billItemRepository;
    private final RoomRepository roomRepository;
    private final ContractRepository contractRepository;
    private final ApartmentRepository apartmentRepository;
    private final UtilitySettingService utilitySettingService;

    /**
     * Calculate water charge for a room based on latest meter reading
     */

    public BigDecimal calculateWaterCharge(Long roomId, Long apartmentId,  YearMonth month) {

        Optional<Water_Meter> latestMeter = getLatestWaterMeterForRoom(roomId);

        if (latestMeter.isEmpty() || latestMeter.get().getUsedWaterUnit() == null) {
            log.warn("No water meter reading found for room: {}", roomId);
            return BigDecimal.ZERO;
        }

        UtilitySetting setting = utilitySettingService.getByApartment(apartmentId);

        Water_Meter meter = latestMeter.get();

        BigDecimal usage = BigDecimal.valueOf(meter.getUsedWaterUnit());
        BigDecimal cost = setting.getWaterRate().multiply(usage);

        // Apply minimum logic
        if (Boolean.TRUE.equals(setting.getUseWaterMinimum())
                && setting.getWaterMinimum() != null) {
            cost = cost.max(setting.getWaterMinimum());
        }

        meter.setTotalWaterPrice(cost);
        waterMeterRepository.save(meter);

        log.info("Water charge calculated: {} units → {}", usage, cost);

        return cost;
    }

    /**
     * Calculate electricity charge for a room based on latest meter reading
     */
    public BigDecimal calculateElectricityCharge(Long roomId, Long apartmentId, YearMonth month) {

        Optional<Electricity_Meter> latestMeter = getLatestElectricityMeterForRoom(roomId);

        if (latestMeter.isEmpty() || latestMeter.get().getUsedElecUnit() == null) {
            log.warn("No electricity meter reading found for room: {}", roomId);
            return BigDecimal.ZERO;
        }

        UtilitySetting setting = utilitySettingService.getByApartment(apartmentId);

        Electricity_Meter meter = latestMeter.get();

        BigDecimal usage = BigDecimal.valueOf(meter.getUsedElecUnit());
        BigDecimal cost = setting.getElectricRate().multiply(usage);

        // 🔥 Apply minimum logic
        if (Boolean.TRUE.equals(setting.getUseElectricMinimum())
                && setting.getElectricMinimum() != null) {
            cost = cost.max(setting.getElectricMinimum());
        }

        meter.setTotalElectricityPrice(cost);
        electricityMeterRepository.save(meter);

        log.info("Electricity charge calculated: {} units → {}", usage, cost);

        return cost;
    }

    public BigDecimal calculateWaterCharge(Long roomId, Long apartmentId) {
        return calculateWaterCharge(roomId, apartmentId, YearMonth.now());
    }

    public BigDecimal calculateElectricityCharge(Long roomId, Long apartmentId) {
        return calculateElectricityCharge(roomId, apartmentId, YearMonth.now());
    }

    public void assertReadyForMeterInput(Long apartmentId, Long roomId) {
        UtilitySetting setting = utilitySettingRepository
                .findByApartmentId(apartmentId)
                .orElseThrow(() -> new BadRequestException("Utility setting not found for apartment: " + apartmentId));

        if (!isUtilitySettingComplete(setting)) {
            throw new BadRequestException("Utility setting must be complete before meter input is allowed");
        }

        boolean activeContract = contractRepository.findActiveByRoomId(roomId).isPresent();
        if (!activeContract) {
            throw new BadRequestException("Room " + roomId + " does not have an ACTIVE contract");
        }
    }

    public List<Bill_Payment> generateBillsSecure(Long apartmentId, AuthenticatedUser user, YearMonth month) {
        Apartment apartment = apartmentRepository.findById(apartmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Apartment not found: " + apartmentId));

        if (apartment.getLandlord() == null || apartment.getLandlord().getUser() == null
                || !apartment.getLandlord().getUser().getId().equals(user.getUserId())) {
            throw new AccessDeniedException("You do not own this apartment");
        }

        return generateMonthlyBillsForApartment(apartmentId, month);
    }

    public Bill_Payment generateMonthlyBill(Long roomId, Long apartmentId, Contract contract, YearMonth month, LocalDate dueDate) {
        return generateMonthlyBill(
                roomId,
                apartmentId,
                contract.getTenant().getId(),
                contract.getContractId(),
                contract.getRentalRate(),
                dueDate
        );
    }

    /**
     * Calculate fixed costs for a room (internet, parking, etc.)
     */
    public BigDecimal calculateFixedCosts(Long apartmentId, String appliesTo) {
        // Get all non-metered fixed costs that apply to the specified entity
        List<Fixed_Cost> fixedCosts = fixedCostRepository
                .findByApartmentIdAndIsMetered(apartmentId, false)
                .stream()
                .filter(cost -> cost.appliesTo(appliesTo))
                .toList();

        if (fixedCosts.isEmpty()) {
            log.info("No fixed costs found for apartment: {} applying to: {}", apartmentId, appliesTo);
            return BigDecimal.ZERO;
        }

        // Sum all fixed costs
        BigDecimal totalFixedCosts = fixedCosts.stream()
                .map(Fixed_Cost::getFixedcostPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        log.info("Fixed costs calculated for apartment {}: {} items = {}", 
                apartmentId, fixedCosts.size(), totalFixedCosts);

        return totalFixedCosts;
    }

    /**
     * Generate monthly bill for a room
     */
    public Bill_Payment generateMonthlyBill(Long roomId, Long apartmentId,
                                            Long userId, Long contractId,
                                            BigDecimal rentAmount, LocalDate dueDate) {

        log.info("Generating monthly bill for room: {}, apartment: {}", roomId, apartmentId);

        // 🔥 Get setting ONCE
        UtilitySetting setting = getSetting(apartmentId);

        // Calculate all charges
        BigDecimal waterCharge = calculateWaterCharge(roomId, apartmentId);
        BigDecimal electricityCharge = calculateElectricityCharge(roomId, apartmentId);
        BigDecimal totalFixedCosts = calculateFixedCosts(apartmentId, "room");

        BigDecimal subtotal = rentAmount
                .add(waterCharge)
                .add(electricityCharge)
                .add(totalFixedCosts);

        Contract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new ResourceNotFoundException("Contract not found"));

        // Create bill
        Bill_Payment bill = Bill_Payment.builder()
                .apartmentId(apartmentId)
                .roomId(roomId)
                .userId(userId)
                .contract(contract)
                .createdDate(LocalDate.now())
                .dueDate(dueDate)
                .subtotal(subtotal)
                .lateFee(BigDecimal.ZERO)
                .totalAmount(subtotal)
                .paymentStatus(PaymentStatus.UNPAID)
                .build();

        bill.calculateTotalAmount();
        Bill_Payment savedBill = billPaymentRepository.save(bill);

        // 🔥 ===== BILL ITEMS =====

        // 1. Rent
        billItemRepository.save(Bill_Item.builder()
                .billId(savedBill.getBillId())
                .itemName("Rent")
                .itemType("RENT")
                .unitPrice(rentAmount)
                .totalAmount(rentAmount)
                .build());

        // 2. Water
        Integer waterUsage = getLatestWaterMeterForRoom(roomId)
                .map(Water_Meter::getUsedWaterUnit)
                .orElse(0);

        billItemRepository.save(Bill_Item.builder()
                .billId(savedBill.getBillId())
                .itemName("Water")
                .itemType("WATER")
                .usage(waterUsage)
                .unitPrice(setting.getWaterRate())
                .totalAmount(waterCharge)
                .build());

        // 3. Electricity
        Integer elecUsage = getLatestElectricityMeterForRoom(roomId)
                .map(Electricity_Meter::getUsedElecUnit)
                .orElse(0);

        billItemRepository.save(Bill_Item.builder()
                .billId(savedBill.getBillId())
                .itemName("Electricity")
                .itemType("ELECTRIC")
                .usage(elecUsage)
                .unitPrice(setting.getElectricRate())
                .totalAmount(electricityCharge)
                .build());

        // 4. Fixed Costs
        List<Fixed_Cost> fixedCostList = fixedCostRepository
                .findByApartmentIdAndIsMetered(apartmentId, false)
                .stream()
                .filter(cost -> cost.appliesTo("room"))
                .toList();

        for (Fixed_Cost cost : fixedCostList) {
            billItemRepository.save(Bill_Item.builder()
                    .billId(savedBill.getBillId())
                    .itemName(cost.getFixedcostName())
                    .itemType("FIXED")
                    .unitPrice(cost.getFixedcostPrice())
                    .totalAmount(cost.getFixedcostPrice())
                    .build());
        }

        log.info("Bill generated successfully: ID={}, Total={}",
                savedBill.getBillId(), savedBill.getTotalAmount());

        return savedBill;
    }

    /**
     * Generate bills for all rooms in an apartment for the current month
     */
    public List<Bill_Payment> generateMonthlyBillsForApartment(Long apartmentId, YearMonth month) {

        log.info("Generating monthly bills for apartment: {} for month: {}", apartmentId, month);

        List<Bill_Payment> generatedBills = new java.util.ArrayList<>();

        // Move outside loop (better)
        LocalDate start = month.atDay(1);
        LocalDate end = month.atEndOfMonth();

        // 1. Get all rooms
        List<Room> rooms = roomRepository.findByApartmentId(apartmentId);

        for (Room room : rooms) {

            // 2. Get ACTIVE contract
            Optional<Contract> contractOpt =
                    contractRepository.findActiveByRoomId(room.getRoomId());

            if (contractOpt.isEmpty()) {
                log.warn("No active contract for room {}", room.getRoomId());
                continue;
            }

            // 3. Prevent duplicate bill
            boolean exists = billPaymentRepository
                    .existsByRoomIdAndCreatedDateBetween(
                            room.getRoomId(), // ⚠️ convert Long → Integer
                            start,
                            end
                    );

            if (exists) {
                log.warn("Bill already exists for room {} for month {}", room.getRoomId(), month);
                continue;
            }

            Contract contract = contractOpt.get();

            // 4. Due date
            LocalDate dueDate = month.atDay(7);

            // 5. Generate bill ✅ FIXED PARAMS
            Bill_Payment bill = generateMonthlyBill(
                    room.getRoomId(),
                    apartmentId,
                    contract.getTenant().getId(),   // ✅ correct userId
                    contract.getContractId(), // ✅ correct contractId
                    contract.getRentalRate(),
                    dueDate
            );

            generatedBills.add(bill);
        }

        log.info("Generated {} bills for apartment {}", generatedBills.size(), apartmentId);

        return generatedBills;
    }

    /**
     * Get latest water meter reading for a room
     */
    private Optional<Water_Meter> getLatestWaterMeterForRoom(Long roomId) {
        return waterMeterRepository.findTopByRoomIdOrderByRecordedDateDesc(roomId);
    }

    /**
     * Get latest electricity meter reading for a room
     */
    private Optional<Electricity_Meter> getLatestElectricityMeterForRoom(Long roomId) {
        return electricityMeterRepository.findTopByRoomIdOrderByReadingDateDesc(roomId);
    }

    /**
     * Recalculate bill totals (useful when meter readings are updated)
     */
    public Bill_Payment recalculateBill(Long billId) {
        return billPaymentRepository.findById(billId)
                .map(bill -> {
                    BigDecimal waterCharge = calculateWaterCharge(bill.getRoomId(), bill.getApartmentId());
                    BigDecimal electricityCharge = calculateElectricityCharge(bill.getRoomId(), bill.getApartmentId());
                    BigDecimal fixedCosts = calculateFixedCosts(bill.getApartmentId(), "room");
                    
                    // Update subtotal (rent should already be in the bill)
                    BigDecimal rentAmount = bill.getSubtotal()
                            .subtract(waterCharge)
                            .subtract(electricityCharge)
                            .subtract(fixedCosts);
                    
                    BigDecimal newSubtotal = rentAmount
                            .add(waterCharge)
                            .add(electricityCharge)
                            .add(fixedCosts);
                    
                    bill.setSubtotal(newSubtotal);
                    bill.calculateTotalAmount();
                    
                    return billPaymentRepository.save(bill);
                })
                .orElseThrow(() -> {
                    log.error("Bill not found billId={}", billId);
                    return new ResourceNotFoundException("Bill not found with ID: " + billId);
                });
    }

    /**
     * Get UtilitySetting for apartment
     */
    private UtilitySetting getSetting(Long apartmentId) {
        return utilitySettingRepository
                .findByApartmentId(apartmentId)
                .orElseThrow(() -> new ResourceNotFoundException("UtilitySetting not found"));
    }

    private boolean isUtilitySettingComplete(UtilitySetting setting) {
        if (setting == null) {
            return false;
        }

        return setting.getBillingDayOfMonth() != null
                && setting.getBankAccountName() != null
                && setting.getBankAccountNumber() != null
                && setting.getCommonAreaFee() != null
                && setting.getLateFeePerDay() != null
                && setting.getWaterRate() != null
                && setting.getElectricRate() != null;
    }

}
