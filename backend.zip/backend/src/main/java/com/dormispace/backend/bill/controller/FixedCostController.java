package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.model.Fixed_Cost;
import com.dormispace.backend.bill.repository.FixedCostRepository;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Fixed Costs
 * Handles CRUD operations for apartment fixed costs (water, electricity, internet, parking, etc.)
 */
@RestController
@RequestMapping("/api/v1/fixed-costs")
@RequiredArgsConstructor
@Slf4j
public class FixedCostController {

    private final FixedCostRepository fixedCostRepository;

    @GetMapping
    public ResponseEntity<List<Fixed_Cost>> getAllFixedCosts() {
        log.info("Getting all fixed costs");
        List<Fixed_Cost> fixedCosts = fixedCostRepository.findAll();
        return ResponseEntity.ok(fixedCosts);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Fixed_Cost> getFixedCostById(@PathVariable Long id) {
        log.info("Getting fixed cost by ID: {}", id);
        Fixed_Cost fixedCost = fixedCostRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Fixed cost not found with ID: " + id));
        return ResponseEntity.ok(fixedCost);
    }

    @GetMapping("/apartment/{apartmentId}")
    public ResponseEntity<List<Fixed_Cost>> getFixedCostsByApartment(@PathVariable Long apartmentId) {
        log.info("Getting fixed costs for apartment: {}", apartmentId);
        List<Fixed_Cost> fixedCosts = fixedCostRepository.findByApartmentId(apartmentId);
        return ResponseEntity.ok(fixedCosts);
    }

    @GetMapping("/apartment/{apartmentId}/type/{type}")
    public ResponseEntity<List<Fixed_Cost>> getFixedCostsByApartmentAndType(
            @PathVariable Long apartmentId,
            @PathVariable String type) {

        log.info("Getting fixed costs for apartment: {}, type: {}", apartmentId, type);
        List<Fixed_Cost> fixedCosts = fixedCostRepository.findByApartmentIdAndFixedcostType(apartmentId, type);
        return ResponseEntity.ok(fixedCosts);
    }

    @GetMapping("/apartment/{apartmentId}/metered")
    public ResponseEntity<List<Fixed_Cost>> getMeteredCosts(@PathVariable Long apartmentId) {
        log.info("Getting metered costs for apartment: {}", apartmentId);
        List<Fixed_Cost> meteredCosts = fixedCostRepository.findByApartmentIdAndIsMetered(apartmentId, true);
        return ResponseEntity.ok(meteredCosts);
    }

    @GetMapping("/apartment/{apartmentId}/non-metered")
    public ResponseEntity<List<Fixed_Cost>> getNonMeteredCosts(@PathVariable Long apartmentId) {
        log.info("Getting non-metered costs for apartment: {}", apartmentId);
        List<Fixed_Cost> fixedCosts = fixedCostRepository.findByApartmentIdAndIsMetered(apartmentId, false);
        return ResponseEntity.ok(fixedCosts);
    }

    @GetMapping("/apartment/{apartmentId}/applies-to/{appliesTo}")
    public ResponseEntity<List<Fixed_Cost>> getCostsByAppliesTo(
            @PathVariable Long apartmentId,
            @PathVariable String appliesTo) {

        log.info("Getting costs for apartment: {}, applies to: {}", apartmentId, appliesTo);
        List<Fixed_Cost> costs = fixedCostRepository.findByApartmentIdAndAppliesTo(apartmentId, appliesTo);
        return ResponseEntity.ok(costs);
    }

    @PostMapping
    public ResponseEntity<Fixed_Cost> createFixedCost(@RequestBody Fixed_Cost fixedCost) {
        log.info("Creating new fixed cost: {}", fixedCost.getFixedcostName());
        Fixed_Cost created = fixedCostRepository.save(fixedCost);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Fixed_Cost> updateFixedCost(
            @PathVariable Long id,
            @RequestBody Fixed_Cost fixedCost) {

        log.info("Updating fixed cost: {}", id);

        Fixed_Cost existing = fixedCostRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Fixed cost not found with ID: " + id));

        existing.setFixedcostName(fixedCost.getFixedcostName());
        existing.setFixedcostPrice(fixedCost.getFixedcostPrice());
        existing.setApartmentId(fixedCost.getApartmentId());
        existing.setUnit(fixedCost.getUnit());
        existing.setFixedcostType(fixedCost.getFixedcostType());
        existing.setChargeMethod(fixedCost.getChargeMethod());
        existing.setAppliesTo(fixedCost.getAppliesTo());
        existing.setIsMetered(fixedCost.getIsMetered());

        Fixed_Cost updated = fixedCostRepository.save(existing);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFixedCost(@PathVariable Long id) {
        log.info("Deleting fixed cost: {}", id);

        if (!fixedCostRepository.existsById(id)) {
            throw new ResourceNotFoundException("Fixed cost not found with ID: " + id);
        }

        fixedCostRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/apartment/{apartmentId}/summary")
    public ResponseEntity<Map<String, Object>> getFixedCostsSummary(@PathVariable Long apartmentId) {
        log.info("Getting fixed costs summary for apartment: {}", apartmentId);

        List<Fixed_Cost> allCosts = fixedCostRepository.findByApartmentId(apartmentId);
        List<Fixed_Cost> meteredCosts = fixedCostRepository.findByApartmentIdAndIsMetered(apartmentId, true);
        List<Fixed_Cost> fixedCosts = fixedCostRepository.findByApartmentIdAndIsMetered(apartmentId, false);

        Map<String, Object> summary = new HashMap<>();
        summary.put("apartmentId", apartmentId);
        summary.put("totalCosts", allCosts.size());
        summary.put("meteredCosts", meteredCosts.size());
        summary.put("fixedCosts", fixedCosts.size());
        summary.put("allCosts", allCosts);

        Map<String, Long> costsByType = allCosts.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                    cost -> cost.getFixedcostType() != null ? cost.getFixedcostType() : "Other",
                    java.util.stream.Collectors.counting()
                ));
        summary.put("costsByType", costsByType);

        return ResponseEntity.ok(summary);
    }
}
