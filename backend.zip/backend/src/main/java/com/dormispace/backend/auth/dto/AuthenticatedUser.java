package com.dormispace.backend.auth.dto;

import com.dormispace.backend.user.model.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor

public class AuthenticatedUser {
    private Long userId; // db reference
    private String firebaseUid; // auth identity
    private String email; // user identity
    private Role role; // authorization
    private Long apartmentId;

}
