package com.dormispace.backend.bill.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "utility_setting")
@Data
public class UtilitySetting {

    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "apartment_id", unique = true, nullable = false)
    private Long apartmentId;

    // WATER
    @Column(precision = 10, scale = 2)
    private BigDecimal waterRate;

    @Column(precision = 10, scale = 2)
    private BigDecimal waterMinimum;

    private Boolean useWaterMinimum;

    // ELECTRIC
    @Column(precision = 10, scale = 2)
    private BigDecimal electricRate;

    @Column(precision = 10, scale = 2)
    private BigDecimal electricMinimum;

    private Boolean useElectricMinimum;

    // COMMON AREA
    @Column(precision = 10, scale = 2)
    private BigDecimal commonAreaFee;

    // LATE FEE
    @Column(name = "late_fee_per_day", precision = 10, scale = 2)
    private BigDecimal lateFeePerDay;

    @Column(name = "max_late_fee", precision = 10, scale = 2)
    private BigDecimal maxLateFee;

    // BILLING CYCLE
    /**
     * Day of month on which bills are generated for all rooms (1–28).
     * Capped at 28 to avoid issues with February.
     * Example: 1 = bills generated on the 1st of every month.
     */
    @Min(1)
    @Max(28)
    @Column(name = "billing_day_of_month", nullable = false)
    private Integer billingDayOfMonth = 1;

    // PAYMENT
    private String bankAccountName;
    private String bankAccountNumber;

    // --- Helpers ---

    /**
     * Returns true if utility settings are complete enough to allow
     * meter reading and bill generation for this apartment.
     */
    public boolean isReadyForBilling() {
        return waterRate != null
                && electricRate != null
                && billingDayOfMonth != null;
    }
}