package com.dormispace.backend.user.service;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.user.model.User;
import com.dormispace.backend.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public User findByFirebaseUid(String firebaseUid) {
        return userRepository.findByFirebaseUid(firebaseUid)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public User findOrCreate(AuthenticatedUser authUser) {

        return userRepository.findByFirebaseUid(authUser.getFirebaseUid())
                .orElseGet(() -> {
                    User newUser = User.builder()
                            .firebaseUid(authUser.getFirebaseUid())
                            .email(authUser.getEmail())
                            .role(authUser.getRole())
                            .build();

                    return userRepository.save(newUser);
                });
    }

}