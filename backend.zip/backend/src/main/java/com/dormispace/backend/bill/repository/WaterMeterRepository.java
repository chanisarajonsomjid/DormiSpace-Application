package com.dormispace.backend.bill.repository;

import com.dormispace.backend.bill.model.Water_Meter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface WaterMeterRepository extends JpaRepository<Water_Meter, Long> {

    Optional<Water_Meter> findTopByRoomIdOrderByRecordedDateDesc(Long roomId);

    boolean existsByRoomIdAndRecordedDateBetween(Long roomId, LocalDate start, LocalDate end);

    List<Water_Meter> findByRoomIdInAndRecordedDateBetween(List<Long> roomIds, LocalDate start, LocalDate end);

    @Query("SELECT COALESCE(SUM(m.usedWaterUnit), 0) FROM Water_Meter m " +
            "WHERE m.roomId = :roomId AND m.usedWaterUnit IS NOT NULL")
    Integer sumUsedUnitsByRoomId(@Param("roomId") Long roomId);

    @Query("SELECT AVG(m.usedWaterUnit) FROM Water_Meter m " +
            "WHERE m.roomId = :roomId AND m.usedWaterUnit IS NOT NULL")
    Double avgUsedUnitsByRoomId(@Param("roomId") Long roomId);

}
