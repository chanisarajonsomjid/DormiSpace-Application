package com.dormispace.backend.room.factory;

import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.room.model.RoomStatus;
import com.dormispace.backend.apartment.model.Floor;

import java.util.ArrayList;
import java.util.List;

public class RoomFactory {

    public static List<Room> generateRooms(Floor floor, int roomCount) {

        List<Room> rooms = new ArrayList<>();

        for (int i = 1; i <= roomCount; i++) {

            Room room = new Room();

            String roomNumber =
                    floor.getFloorNumber() + String.format("%02d", i);

            room.setRoomNumber(roomNumber);
            room.setStatus(RoomStatus.VACANT);

            room.setFloor(floor);
            room.setApartment(floor.getApartment());

            rooms.add(room);
        }

        return rooms;
    }
}