package com.dormispace.backend.bill.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PromptPayResponse {
    private String qrImageUrl;
    private String sourceId;
    private String chargeId;
}