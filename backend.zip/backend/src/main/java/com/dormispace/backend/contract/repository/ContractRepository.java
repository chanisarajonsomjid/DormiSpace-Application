package com.dormispace.backend.contract.repository;

import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.model.ContractStatus;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.user.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ContractRepository extends JpaRepository<Contract, Long> {

    // Prevent duplicate active/draft contracts per room
    boolean existsByRoomAndStatusIn(
            Room room,
            List<ContractStatus> statuses
    );

    // Tenant fetches latest contract
    Optional<Contract> findTopByTenantIdOrderByCreatedAtDesc(Long userId);

    @Query("""
    SELECT c FROM Contract c
    JOIN c.room r
    JOIN r.apartment a
    WHERE a.landlord.user.id = :landlordId
      AND c.status IN :statuses
""")
    List<Contract> findByLandlordIdAndStatusIn(
            Long landlordId,
            List<ContractStatus> statuses
    );

    boolean existsByRoomAndStatus(
            Room room,
            ContractStatus contractStatus
    );

    Optional<Contract> findTopByRoomAndStatusInOrderByCreatedAtDesc(
            Room room,
            List<ContractStatus> statuses
    );

    Optional<Contract> findByInvitationToken(String token);

    Optional<Contract> findByTenant_IdAndStatus(Long tenantId, ContractStatus status);

    @Query("SELECT c FROM Contract c WHERE c.room.roomId = :roomId AND c.status = 'ACTIVE'")
    Optional<Contract> findActiveByRoomId(Long roomId);

    boolean existsByTenantAndStatus(User tenant, ContractStatus status);

    List<Contract> findByRoom_RoomIdInAndStatus(List<Long> roomIds, ContractStatus contractStatus);

    int countByRoom_Apartment_ApartmentIdAndStatus(int apartmentId, ContractStatus status);
}