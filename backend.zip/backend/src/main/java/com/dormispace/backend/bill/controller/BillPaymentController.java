package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.dto.BillSummaryDTO;
import com.dormispace.backend.bill.dto.PromptPayRequest;
import com.dormispace.backend.bill.dto.PromptPayResponse;
import com.dormispace.backend.bill.gateway.OmiseGateway;
import com.dormispace.backend.bill.model.Bill_Item;
import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.model.PaymentMethod;
import com.dormispace.backend.bill.repository.BillItemRepository;
import com.dormispace.backend.bill.repository.BillPaymentRepository;
import com.dormispace.backend.bill.service.BillPaymentService;
import com.dormispace.backend.bill.service.PaymentProcessingService;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.room.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * REST Controller for Bill_Payment
 * Handles HTTP requests for bill payment operations
 */
@RestController
@RequestMapping("/api/v1/bill-payments")
@RequiredArgsConstructor
public class BillPaymentController {

    private final BillPaymentService billPaymentService;
    private final BillItemRepository billItemRepository;
    private final PaymentProcessingService paymentProcessingService;
    private final OmiseGateway omiseGateway;
    private final BillPaymentRepository billPaymentRepository;
    private final RoomRepository roomRepository;

    @PostMapping("/create-promptpay")
    public ResponseEntity<PromptPayResponse> createPromptPay(
            @RequestBody PromptPayRequest request) {

        if (request.getBillId() == null) {
            throw new BadRequestException("Bill ID is required");
        }

        PromptPayResponse response =
                paymentProcessingService.createPromptPay(request.getBillId());

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/promptpay/{chargeId}/qr")
    public ResponseEntity<?> getQr(@PathVariable String chargeId) {
        String qr = omiseGateway.getQrFromCharge(chargeId);
        return ResponseEntity.ok(qr);
    }

//    @GetMapping("/{billId}/qr-image")
//    public ResponseEntity<byte[]> getQrImage(@PathVariable Long billId) {
//        Bill_Payment bill = billPaymentRepository.findById(billId)
//                .orElseThrow(() -> new ResourceNotFoundException("Bill not found: " + billId));
//
//        String chargeId = bill.getOmiseChargeId();
//        if (chargeId == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        String qrUrl = paymentGateway.getQrFromCharge(chargeId);
//        if (qrUrl == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        // Fetch from Omise with auth and proxy the bytes to Flutter
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setBasicAuth(omiseSecretKey, "");
//
//        ResponseEntity<byte[]> response = restTemplate.exchange(
//                qrUrl,
//                HttpMethod.GET,
//                new HttpEntity<>(headers),
//                byte[].class
//        );
//
//        return ResponseEntity.ok()
//                .contentType(MediaType.IMAGE_PNG)
//                .body(response.getBody());
//    }

    @PostMapping
    public ResponseEntity<Bill_Payment> createBillPayment(@RequestBody Bill_Payment billPayment) {
        Bill_Payment created = billPaymentService.createBillPayment(billPayment);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<Bill_Payment>> getAllBillPayments() {
        List<Bill_Payment> billPayments = billPaymentService.getAllBillPayments();
        return ResponseEntity.ok(billPayments);
    }

    @GetMapping("/{billId}")
    public ResponseEntity<Bill_Payment> getBillPaymentById(@PathVariable Long billId) {
        Bill_Payment bill = billPaymentService.getBillPaymentById(billId)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found with ID: " + billId));
        return ResponseEntity.ok(bill);
    }

    @PutMapping("/{billId}")
    public ResponseEntity<Bill_Payment> updateBillPayment(@PathVariable Long billId,
                                                          @RequestBody Bill_Payment billPayment) {
        Bill_Payment updated = billPaymentService.updateBillPayment(billId, billPayment);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{billId}")
    public ResponseEntity<Void> deleteBillPayment(@PathVariable Long billId) {
        billPaymentService.deleteBillPayment(billId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{billId}/mark-as-paid")
    public ResponseEntity<Bill_Payment> markAsPaid(@PathVariable Long billId,
                                                   @RequestParam LocalDate paymentDate,
                                                   @RequestParam PaymentMethod paymentMethod) {
        Bill_Payment paid = billPaymentService.markAsPaid(billId, paymentDate, paymentMethod);
        return ResponseEntity.ok(paid);
    }

    @PostMapping("/{billId}/mark-as-overdue")
    public ResponseEntity<Bill_Payment> markAsOverdue(@PathVariable Long billId) {
        Bill_Payment overdue = billPaymentService.markAsOverdue(billId);
        return ResponseEntity.ok(overdue);
    }

    @PostMapping("/{billId}/apply-late-fee")
    public ResponseEntity<Bill_Payment> applyLateFee(@PathVariable Long billId,
                                                     @RequestParam BigDecimal lateFeeAmount) {
        Bill_Payment withFee = billPaymentService.applyLateFee(billId, lateFeeAmount);
        return ResponseEntity.ok(withFee);
    }

    @GetMapping("/{billId}/is-overdue")
    public ResponseEntity<Boolean> isPaymentOverdue(@PathVariable Long billId) {
        boolean isOverdue = billPaymentService.isPaymentOverdue(billId);
        return ResponseEntity.ok(isOverdue);
    }

    @GetMapping("/{billId}/is-paid")
    public ResponseEntity<Boolean> isPaymentPaid(@PathVariable Long billId) {
        boolean isPaid = billPaymentService.isPaymentPaid(billId);
        return ResponseEntity.ok(isPaid);
    }

    @GetMapping("/user/{userId}/outstanding-amount")
    public ResponseEntity<BigDecimal> getTotalOutstandingAmount(@PathVariable Long userId) {
        BigDecimal outstanding = billPaymentService.getTotalOutstandingAmount(userId);
        return ResponseEntity.ok(outstanding);
    }

    @GetMapping("/apartment/{apartmentId}/summary")
    public ResponseEntity<List<BillSummaryDTO>> getBillsSummaryByApartment(
            @PathVariable Long apartmentId) {

        List<Bill_Payment> bills = billPaymentRepository
                .findByApartmentId(apartmentId);

        List<BillSummaryDTO> result = bills.stream()
                .map(bill -> {
                    List<Bill_Item> items = billItemRepository
                            .findByBillId(bill.getBillId());

                    BillSummaryDTO dto = BillSummaryDTO.from(bill, items);

                    // Room number
                    roomRepository.findById(bill.getRoomId())
                            .ifPresent(room -> dto.setRoomNumber(room.getRoomNumber()));

                    if (bill.getContract() != null) {
                        Contract contract = bill.getContract();

                        String name = ((contract.getFirstName() != null
                                ? contract.getFirstName() : "")
                                + " "
                                + (contract.getLastName() != null
                                ? contract.getLastName() : "")).trim();

                        dto.setTenantName(name);
                    }

                    return dto;
                })
                .toList();

        return ResponseEntity.ok(result);
    }

    @PostMapping("/{billId}/declare-cash-payment")
    public ResponseEntity<Bill_Payment> declareCashPayment(@PathVariable Long billId) {
        Bill_Payment updated = billPaymentService.declareCashPayment(billId);
        return ResponseEntity.ok(updated);
    }

    @GetMapping("/user/{userId}/bills")
    public ResponseEntity<List<Bill_Payment>> getBillsByUser(
            @PathVariable Long userId) {
        return ResponseEntity.ok(
                billPaymentRepository.findByUserId(userId)
        );
    }
}
