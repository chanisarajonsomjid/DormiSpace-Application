package com.dormispace.backend.room.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomWithContractStatusResponse {

    private Long roomId;
    private String roomNumber;
    private String roomStatus;
    private Long contractId;
    private Long apartmentId;
    private String tenantEmail;
}