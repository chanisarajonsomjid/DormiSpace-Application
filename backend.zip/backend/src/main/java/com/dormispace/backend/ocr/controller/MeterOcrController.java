package com.dormispace.backend.ocr.controller;

import com.dormispace.backend.ocr.dto.OcrRequestDto;
import com.dormispace.backend.ocr.dto.OcrResultDto;
import com.dormispace.backend.ocr.service.MeterOcrService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/ocr")
@RequiredArgsConstructor
public class MeterOcrController {

    private final MeterOcrService meterOcrService;

    @PostMapping(value = "/meter", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<OcrResultDto> extractMeterReading(
            @RequestPart("image")                                        MultipartFile imageFile,
            @RequestPart("roomId")                                       String roomId,
            @RequestPart("meterType")                                    String meterType,
            @RequestPart(value = "previousReading", required = false)    String previousReading,
            // FIX: accept readingSource so Flutter can tell us CAMERA vs GALLERY
            @RequestPart(value = "readingSource",   required = false)    String readingSource
    ) throws IOException {

        OcrRequestDto requestDto = OcrRequestDto.builder()
                .roomId(Long.parseLong(roomId.trim()))   // FIX: Long, not Integer
                .meterType(meterType.trim().toLowerCase())
                .previousReading(parseOptionalInt(previousReading))
                .readingSource(readingSource != null ? readingSource.trim().toUpperCase() : null)
                .build();

        OcrResultDto result = meterOcrService.process(imageFile, requestDto);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of("status", "ok", "service", "meter-ocr"));
    }

    // ─── Exception handlers ───────────────────────────────────────────────────

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleValidation(IllegalArgumentException ex) {
        log.warn("OCR validation error: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
    }

    @ExceptionHandler(NumberFormatException.class)
    public ResponseEntity<Map<String, String>> handleNumberFormat(NumberFormatException ex) {
        log.warn("OCR number format error: {}", ex.getMessage());
        return ResponseEntity.badRequest()
                .body(Map.of("error", "roomId and previousReading must be integers."));
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<Map<String, String>> handleIo(IOException ex) {
        log.error("OCR I/O error: {}", ex.getMessage());
        return ResponseEntity.internalServerError()
                .body(Map.of("error", "Failed to process image. Please try again."));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handleGeneral(Exception ex) {
        log.error("Unexpected OCR error", ex);
        return ResponseEntity.internalServerError()
                .body(Map.of("error", "An unexpected error occurred. Please try again."));
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private Integer parseOptionalInt(String value) {
        if (value == null || value.isBlank()) return null;
        return Integer.parseInt(value.trim());
    }
}