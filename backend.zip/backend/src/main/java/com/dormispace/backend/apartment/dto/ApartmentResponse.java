package com.dormispace.backend.apartment.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ApartmentResponse {

    private Long apartmentId;
    private String name;
    private String address;
    private String district;
    private String province;
    private String postcode;
    private String city;
    private String phoneNum;
    private Integer totalRooms;
}