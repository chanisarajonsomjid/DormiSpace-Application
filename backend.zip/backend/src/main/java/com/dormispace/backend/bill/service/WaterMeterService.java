package com.dormispace.backend.bill.service;

import com.dormispace.backend.bill.model.Water_Meter;
import com.dormispace.backend.bill.repository.WaterMeterRepository;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class WaterMeterService {

    private final WaterMeterRepository   waterMeterRepository;
    private final BillCalculationService billCalculationService;

    // ─── Create ───────────────────────────────────────────────────────────────

    /**
     * Save a new water meter reading.
     *
     * FIX 1: assertReadyForMeterInput — blocks save if utility settings are
     *         incomplete or room has no active contract.
     * FIX 2: previousRead is always fetched from the last saved currentRead
     *         for this room, never trusted from the incoming payload.
     * FIX 3: readingSource and ocrConfidence are preserved from the payload.
     *
     * @param meter       the reading to save — currentRead, recordedDate,
     *                    roomId, readingSource, ocrConfidence must be set.
     * @param apartmentId needed for the utility setting prerequisite check.
     */
    public Water_Meter createWaterMeterReading(
            Water_Meter meter, Long apartmentId) {

        log.info("Creating water meter reading: roomId={} source={}",
                meter.getRoomId(), meter.getReadingSource());

        // FIX 1: prerequisite gate
        billCalculationService.assertReadyForMeterInput(
                apartmentId, meter.getRoomId());

        // FIX 2: enforce previousRead from DB, not from client
        enforceCorrectPreviousRead(meter);

        meter.calculateUsedUnits();

        // Guard: current must not be less than previous
        if (!meter.isValidReading()) {
            throw new BadRequestException(
                    "Current reading (" + meter.getCurrentRead()
                            + ") cannot be less than previous reading ("
                            + meter.getPreviousRead() + ").");
        }

        Water_Meter saved = waterMeterRepository.save(meter);
        log.info("Created water meter: meterId={} units={}",
                saved.getMeterWaterId(), saved.getUsedWaterUnit());
        return saved;
    }

    // ─── Update ───────────────────────────────────────────────────────────────

    /**
     * Update an existing water meter reading.
     * When the landlord corrects an OCR result, readingSource should be
     * "CORRECTED" — the controller sets this before calling here.
     */
    public Water_Meter updateWaterMeterReading(Long meterId, Water_Meter meter) {
        log.info("Updating water meter: meterId={}", meterId);

        return waterMeterRepository.findById(meterId)
                .map(existing -> {
                    existing.setRecordedDate(meter.getRecordedDate());
                    existing.setCurrentRead(meter.getCurrentRead());
                    existing.setPreviousRead(meter.getPreviousRead());
                    existing.setCollectedWaterImage(meter.getCollectedWaterImage());

                    // Preserve audit fields if provided
                    if (meter.getReadingSource() != null) {
                        existing.setReadingSource(meter.getReadingSource());
                    }
                    if (meter.getOcrConfidence() != null) {
                        existing.setOcrConfidence(meter.getOcrConfidence());
                    }
                    if (meter.getOcrRawText() != null) {
                        existing.setOcrRawText(meter.getOcrRawText());
                    }

                    existing.calculateUsedUnits();

                    if (!existing.isValidReading()) {
                        throw new BadRequestException(
                                "Current reading cannot be less than previous reading.");
                    }

                    Water_Meter updated = waterMeterRepository.save(existing);
                    log.info("Updated water meter: meterId={} units={}",
                            meterId, updated.getUsedWaterUnit());
                    return updated;
                })
                .orElseThrow(() -> waterMeterNotFound(meterId));
    }

    // ─── Read ─────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public Optional<Water_Meter> getWaterMeterById(Long meterId) {
        return waterMeterRepository.findById(meterId);
    }

    @Transactional(readOnly = true)
    public List<Water_Meter> getAllWaterMeterReadings() {
        return waterMeterRepository.findAll();
    }

    /**
     * FIX: uses existing repository method instead of findAll().stream().
     */
    @Transactional(readOnly = true)
    public Optional<Water_Meter> getLastReadingForRoom(Long roomId) {
        return waterMeterRepository.findTopByRoomIdOrderByRecordedDateDesc(roomId);
    }

    /**
     * FIX: uses repository query instead of findAll().stream().filter().
     * Add the JPQL query below to WaterMeterRepository:
     *
     *   @Query("SELECT COALESCE(SUM(m.usedWaterUnit), 0) FROM Water_Meter m
     *           WHERE m.roomId = :roomId AND m.usedWaterUnit IS NOT NULL")
     *   Integer sumUsedUnitsByRoomId(@Param("roomId") Long roomId);
     */
    @Transactional(readOnly = true)
    public Integer getTotalWaterUsageForRoom(Long roomId) {
        return waterMeterRepository.sumUsedUnitsByRoomId(roomId);
    }

    /**
     * FIX: uses repository query instead of findAll().stream().filter().
     * Add the JPQL query below to WaterMeterRepository:
     *
     *   @Query("SELECT AVG(m.usedWaterUnit) FROM Water_Meter m
     *           WHERE m.roomId = :roomId AND m.usedWaterUnit IS NOT NULL")
     *   Double avgUsedUnitsByRoomId(@Param("roomId") Long roomId);
     */
    @Transactional(readOnly = true)
    public Double getAverageMonthlyUsageForRoom(Long roomId) {
        Double avg = waterMeterRepository.avgUsedUnitsByRoomId(roomId);
        return avg != null ? avg : 0.0;
    }

    // ─── Validation ───────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public boolean isValidReading(Long meterId) {
        return waterMeterRepository.findById(meterId)
                .map(Water_Meter::isValidReading)
                .orElse(false);
    }

    // ─── Delete ───────────────────────────────────────────────────────────────

    public void deleteWaterMeterReading(Long meterId) {
        log.info("Deleting water meter: meterId={}", meterId);
        waterMeterRepository.deleteById(meterId);
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    /**
     * FIX: previousRead enforcement — same logic as ElectricityMeterService.
     * The authoritative previousRead is the last saved currentRead for this
     * room. Client value is overridden if it differs.
     */
    private void enforceCorrectPreviousRead(Water_Meter meter) {
        waterMeterRepository
                .findTopByRoomIdOrderByRecordedDateDesc(meter.getRoomId())
                .ifPresent(last -> {
                    if (last.getCurrentRead() != null
                            && !last.getCurrentRead().equals(meter.getPreviousRead())) {
                        log.warn(
                                "previousRead mismatch for roomId={}: client sent {}, "
                                        + "overriding with last currentRead {}",
                                meter.getRoomId(),
                                meter.getPreviousRead(),
                                last.getCurrentRead());
                        meter.setPreviousRead(last.getCurrentRead());
                    }
                });
    }

    private ResourceNotFoundException waterMeterNotFound(Long meterId) {
        log.error("Water meter not found: meterId={}", meterId);
        return new ResourceNotFoundException(
                "Water meter not found with ID: " + meterId);
    }
}