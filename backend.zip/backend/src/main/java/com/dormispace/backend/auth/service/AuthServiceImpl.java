package com.dormispace.backend.auth.service;

import com.dormispace.backend.apartment.model.Apartment;
import com.dormispace.backend.apartment.repository.ApartmentRepository;
import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.user.dto.RegisterLandlordRequest;
import com.dormispace.backend.user.model.AccountStatus;
import com.dormispace.backend.user.model.Landlord;
import com.dormispace.backend.user.model.Role;
import com.dormispace.backend.user.model.User;
import com.dormispace.backend.user.repository.LandlordRepository;
import com.dormispace.backend.user.repository.UserRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final LandlordRepository landlordRepository;
    private final FirebaseAuth firebaseAuth;
    private final ApartmentRepository apartmentRepository;

    @Override
    public AuthenticatedUser authenticate(String firebaseToken) {

        FirebaseToken decoded;
        try {
            decoded = firebaseAuth.verifyIdToken(firebaseToken);
        } catch (Exception e) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Invalid Firebase token"
            );
        }

        String firebaseUid = decoded.getUid();
        String email = decoded.getEmail();

        if (email == null || email.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Email not found in Firebase token"
            );
        }
        email = email.toLowerCase();

        // User MUST already exist in backend (invited / registered)
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "User not invited or not registered"
                ));

        if (user.getFirebaseUid() == null) {
            user.setFirebaseUid(firebaseUid);
        }

        if (user.getAccountStatus() != AccountStatus.ACTIVE) {
            user.setAccountStatus(AccountStatus.ACTIVE);
        }

        userRepository.save(user);

        // Prevent account takeover
        if (!firebaseUid.equals(user.getFirebaseUid())) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Firebase account does not match this user"
            );
        }

        // Account status check
        if (user.getAccountStatus() != AccountStatus.ACTIVE) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Account is not active"
            );
        }

        // Replace the return at the end of authenticate()
        Long apartmentId = apartmentRepository
                .findByUserId(user.getId())
                .stream()
                .findFirst()
                .map(Apartment::getApartmentId)
                .orElse(null);

        return new AuthenticatedUser(
                user.getId(),
                user.getFirebaseUid(),
                user.getEmail(),
                user.getRole(),
                apartmentId
        );
    }

    @Override
    @Transactional
    public AuthenticatedUser registerLandlord(String firebaseToken, RegisterLandlordRequest request) {
        FirebaseToken decoded;
        try {
            decoded = FirebaseAuth.getInstance().verifyIdToken(firebaseToken);
        } catch (Exception e) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Invalid Firebase token"
            );
        }

        String uid = decoded.getUid();
        String email = decoded.getEmail();

        if (email == null) {
            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "Email not found in Firebase token"
            );
        }

        email = email.toLowerCase();

        // prevent duplicate registration
        if (userRepository.findByEmail(email).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "This email is already registered"
            );
        }

        if (request.getFirstName() == null || request.getFirstName().isBlank()
                || request.getLastName() == null || request.getLastName().isBlank()
                || request.getPhoneNumber() == null || request.getPhoneNumber().isBlank()) {
            throw new IllegalArgumentException("First name, last name and phone number are required");
        }

        // save user first
        User landlordUser = new User();
        landlordUser.setFirebaseUid(uid);
        landlordUser.setEmail(email);
        landlordUser.setRole(Role.LANDLORD);
        landlordUser.setAccountStatus(AccountStatus.ACTIVE);

        User saved = userRepository.save(landlordUser);

        // Then save landlord profile
        Landlord landlord = new Landlord();
        landlord.setUser(saved);
        landlord.setFirstName(request.getFirstName());
        landlord.setLastName(request.getLastName());
        landlord.setPhoneNumber(request.getPhoneNumber());
        landlordRepository.save(landlord);

        return new AuthenticatedUser(
                saved.getId(),
                saved.getFirebaseUid(),
                saved.getEmail(),
                saved.getRole(),
                null
        );
    }
}