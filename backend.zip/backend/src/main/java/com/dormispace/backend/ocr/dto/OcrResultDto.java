package com.dormispace.backend.ocr.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class OcrResultDto {

    private Long    roomId;
    private String  meterType;

    /** The extracted meter reading. Null if OCR found nothing. */
    private Integer extractedReading;

    private Float   confidence;
    private boolean valid;
    private String  message;
    private String  rawText;

    /**
     * How the reading was obtained. Passed back to Flutter so the
     * Save request can persist it on the meter record.
     * Values: "CAMERA", "GALLERY", "MANUAL", "CORRECTED", or null.
     * Flutter should:
     *   - set "MANUAL"    when the landlord types the reading directly
     *   - set "CORRECTED" when OCR ran but the landlord edited the result
     *   - pass through this field unchanged when OCR succeeded without edits
     */
    private String  readingSource;
}