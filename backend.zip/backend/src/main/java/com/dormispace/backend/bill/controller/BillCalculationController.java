package com.dormispace.backend.bill.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.service.BillCalculationService;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.contract.model.ContractStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/bill-calculation")
@RequiredArgsConstructor
@Slf4j
public class BillCalculationController {

    private final BillCalculationService billCalculationService;
    private final ContractRepository     contractRepository;

    @PostMapping("/apartment/{apartmentId}/generate")
    public ResponseEntity<?> generateBills(
            @PathVariable Long apartmentId,
            @AuthenticationPrincipal AuthenticatedUser user
    ) {

        billCalculationService.generateBillsSecure(
                apartmentId,
                user,
                YearMonth.now()
        );

        return ResponseEntity.ok(Map.of(
                "message", "Bills generated successfully",
                "apartmentId", apartmentId,
                "period", YearMonth.now().toString()
        ));
    }

    @GetMapping("/water")
    public ResponseEntity<Map<String, Object>> calculateWaterCharge(
            @RequestParam Long roomId,
            @RequestParam Long apartmentId,
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month) {

        YearMonth ym = (year != null && month != null)
                ? YearMonth.of(year, month)
                : YearMonth.now();

        BigDecimal charge = billCalculationService
                .calculateWaterCharge(roomId, apartmentId, ym);

        return ResponseEntity.ok(Map.of(
                "roomId", roomId, "apartmentId", apartmentId,
                "period", ym.toString(), "waterCharge", charge,
                "calculatedAt", LocalDate.now()));
    }

    @GetMapping("/electricity")
    public ResponseEntity<Map<String, Object>> calculateElectricityCharge(
            @RequestParam Long roomId,
            @RequestParam Long apartmentId,
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month) {

        YearMonth ym = (year != null && month != null)
                ? YearMonth.of(year, month)
                : YearMonth.now();

        BigDecimal charge = billCalculationService
                .calculateElectricityCharge(roomId, apartmentId, ym);

        return ResponseEntity.ok(Map.of(
                "roomId", roomId, "apartmentId", apartmentId,
                "period", ym.toString(), "electricityCharge", charge,
                "calculatedAt", LocalDate.now()));
    }

    @GetMapping("/fixed-costs")
    public ResponseEntity<Map<String, Object>> calculateFixedCosts(
            @RequestParam Long apartmentId,
            @RequestParam(defaultValue = "room") String appliesTo) {

        BigDecimal fixedCosts = billCalculationService
                .calculateFixedCosts(apartmentId, appliesTo);

        return ResponseEntity.ok(Map.of(
                "apartmentId", apartmentId, "appliesTo", appliesTo,
                "fixedCosts", fixedCosts, "calculatedAt", LocalDate.now()));
    }

    /**
     * Generate a bill for a single room.
     * FIX: validates the contract is ACTIVE before generating,
     * so a direct call cannot bypass the contract status check
     * that bulk generation does implicitly.
     */
    @PostMapping("/generate-monthly")
    public ResponseEntity<Bill_Payment> generateMonthlyBill(
            @RequestBody MonthlyBillRequest request) {

        Contract contract = contractRepository
                .findById(request.getContractId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Contract not found: " + request.getContractId()));

        if (contract.getStatus() != ContractStatus.ACTIVE) {
            throw new com.dormispace.backend.common.exception.BadRequestException(
                    "Contract " + request.getContractId()
                            + " is not ACTIVE (status: " + contract.getStatus() + "). "
                            + "Cannot generate a bill for a non-active contract.");
        }

        YearMonth month = (request.getYear() != null && request.getMonth() != null)
                ? YearMonth.of(request.getYear(), request.getMonth())
                : YearMonth.now();

        LocalDate dueDate = request.getDueDate() != null
                ? request.getDueDate()
                : month.atDay(7);

        Bill_Payment bill = billCalculationService.generateMonthlyBill(
                request.getRoomId(),
                request.getApartmentId(),
                contract,
                month,
                dueDate);

        return ResponseEntity.status(HttpStatus.CREATED).body(bill);
    }

    @PostMapping("/recalculate/{billId}")
    public ResponseEntity<Bill_Payment> recalculateBill(@PathVariable Long billId) {
        return ResponseEntity.ok(billCalculationService.recalculateBill(billId));
    }

//    @PostMapping("/generate-bulk")
//    public ResponseEntity<Map<String, Object>> generateMonthlyBillsForApartment(
//            @RequestParam Long apartmentId,
//            @RequestParam Integer year,
//            @RequestParam Integer month) {
//
//        YearMonth yearMonth = YearMonth.of(year, month);
//        List<Bill_Payment> bills = billCalculationService
//                .generateMonthlyBillsForApartment(apartmentId, yearMonth);
//
//        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
//                "apartmentId", apartmentId,
//                "period", yearMonth.toString(),
//                "billsGenerated", bills.size(),
//                "bills", bills));
//    }

    /**
     * Check whether meter input is allowed for a room.
     * Flutter calls this before opening the meter recording screen.
     * Returns 200 if allowed, 400 with a message if not.
     */
    @GetMapping("/meter-input-check")
    public ResponseEntity<Map<String, Object>> checkMeterInputAllowed(
            @RequestParam Long apartmentId,
            @RequestParam Long roomId) {

        // assertReadyForMeterInput throws BadRequestException if not ready —
        // the global exception handler returns 400 with the message.
        billCalculationService.assertReadyForMeterInput(apartmentId, roomId);

        return ResponseEntity.ok(Map.of(
                "allowed", true,
                "roomId", roomId,
                "apartmentId", apartmentId));
    }

    @lombok.Data
    public static class MonthlyBillRequest {
        private Long      roomId;
        private Long      apartmentId;
        private Long      contractId;
        private Integer   year;    // if null, defaults to current year
        private Integer   month;   // if null, defaults to current month
        private LocalDate dueDate; // if null, defaults to 7th of billing month
    }
}