package com.dormispace.backend.notification.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.notification.dto.RegisterDeviceTokenRequest;
import com.dormispace.backend.notification.dto.RemoveDeviceTokenRequest;
import com.dormispace.backend.notification.model.UserDeviceToken;
import com.dormispace.backend.notification.service.DeviceTokenService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/devices")
@RequiredArgsConstructor
public class DeviceTokenController {

    private final DeviceTokenService deviceTokenService;

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> registerToken(
            @RequestAttribute("authUser") AuthenticatedUser authUser,
            @Valid @RequestBody RegisterDeviceTokenRequest request
    ) {
        if (authUser == null) {
            throw new BadRequestException("Unauthenticated");
        }
        UserDeviceToken token = deviceTokenService.registerToken(authUser.getUserId(), request);
        Map<String, Object> response = new HashMap<>();
        response.put("tokenId", token.getId());
        response.put("platform", token.getPlatform());
        response.put("active", token.getActive());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/remove")
    public ResponseEntity<Map<String, Object>> removeToken(
            @RequestAttribute("authUser") AuthenticatedUser authUser,
            @Valid @RequestBody RemoveDeviceTokenRequest request
    ) {
        if (authUser == null) {
            throw new BadRequestException("Unauthenticated");
        }
        deviceTokenService.removeToken(authUser.getUserId(), request.getFcmToken());
        return ResponseEntity.ok(Map.of("removed", true));
    }
}
