package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.dto.MonthlyReportDTO;
import com.dormispace.backend.bill.dto.PaymentSummaryDTO;
import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.service.ReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.YearMonth;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Reports and Analytics
 * Handles report generation and statistics
 */
@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
@Slf4j
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/monthly")
    public ResponseEntity<MonthlyReportDTO> getMonthlyReport(
            @RequestParam Long apartmentId,
            @RequestParam Integer year,
            @RequestParam Integer month) {

        log.info("Getting monthly report for apartment: {}, period: {}/{}", apartmentId, year, month);
        YearMonth yearMonth = YearMonth.of(year, month);
        MonthlyReportDTO report = reportService.getMonthlyReport(apartmentId, yearMonth);
        return ResponseEntity.ok(report);
    }

    @GetMapping("/payment-summary/{userId}")
    public ResponseEntity<PaymentSummaryDTO> getPaymentSummary(@PathVariable Long userId) {
        log.info("Getting payment summary for user: {}", userId);
        PaymentSummaryDTO summary = reportService.getPaymentSummary(userId);
        return ResponseEntity.ok(summary);
    }

    @GetMapping("/overdue")
    public ResponseEntity<Map<String, Object>> getOverdueReport(@RequestParam Long apartmentId) {
        log.info("Getting overdue report for apartment: {}", apartmentId);

        List<Bill_Payment> overdueBills = reportService.getOverdueReport(apartmentId);

        Map<String, Object> response = new HashMap<>();
        response.put("apartmentId", apartmentId);
        response.put("totalOverdue", overdueBills.size());
        response.put("bills", overdueBills);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/unpaid")
    public ResponseEntity<Map<String, Object>> getUnpaidBills(@RequestParam Long apartmentId) {
        log.info("Getting unpaid bills for apartment: {}", apartmentId);

        List<Bill_Payment> unpaidBills = reportService.getUnpaidBills(apartmentId);

        Map<String, Object> response = new HashMap<>();
        response.put("apartmentId", apartmentId);
        response.put("totalUnpaid", unpaidBills.size());
        response.put("bills", unpaidBills);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/payment-history/{userId}")
    public ResponseEntity<Map<String, Object>> getPaymentHistory(@PathVariable Long userId) {
        log.info("Getting payment history for user: {}", userId);

        List<Bill_Payment> paymentHistory = reportService.getPaymentHistory(userId);

        Map<String, Object> response = new HashMap<>();
        response.put("userId", userId);
        response.put("totalPayments", paymentHistory.size());
        response.put("payments", paymentHistory);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/collection-rate")
    public ResponseEntity<Map<String, Object>> getCollectionRate(
            @RequestParam Long apartmentId,
            @RequestParam Integer year,
            @RequestParam Integer month) {

        log.info("Getting collection rate for apartment: {}, period: {}/{}", apartmentId, year, month);

        YearMonth yearMonth = YearMonth.of(year, month);
        Double collectionRate = reportService.getCollectionRate(apartmentId, yearMonth);

        Map<String, Object> response = new HashMap<>();
        response.put("apartmentId", apartmentId);
        response.put("year", year);
        response.put("month", month);
        response.put("collectionRate", collectionRate);
        response.put("collectionRatePercent", String.format("%.2f%%", collectionRate));

        return ResponseEntity.ok(response);
    }
}
