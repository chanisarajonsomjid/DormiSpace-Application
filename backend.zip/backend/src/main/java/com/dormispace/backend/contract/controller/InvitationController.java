package com.dormispace.backend.contract.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.contract.service.InvitationService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/invitation")
@RequiredArgsConstructor
public class InvitationController {

    private final InvitationService invitationService;

    // Step 1: Validate token → return email
    @GetMapping("/validate")
    public ResponseEntity<?> validateToken(@RequestParam String token) {
        try {
            String email = invitationService.validateTokenAndGetEmail(token);
            return ResponseEntity.ok(Map.of("email", email));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // Step 2: Generate Firebase custom token for existing user
    @GetMapping("/custom-token")
    public ResponseEntity<?> getCustomToken(@RequestParam String token) {
        try {
            String customToken = invitationService.generateCustomToken(token);
            return ResponseEntity.ok(Map.of("token", customToken));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // Step 2 (POST): Generate Firebase custom token for existing user
    @PostMapping("/custom-token")
    public ResponseEntity<?> postCustomToken(@RequestBody Map<String, String> body) {
        String token = body.get("token");
        if (token == null || token.isBlank()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Missing token"));
        }

        try {
            String customToken = invitationService.generateCustomToken(token);
            return ResponseEntity.ok(Map.of("token", customToken));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // Step 3: Complete setup - update user status
    @PostMapping("/complete")
    public ResponseEntity<?> completeSetup(
            @RequestBody Map<String, String> body,
            HttpServletRequest request
    ) {
        AuthenticatedUser user =
                (AuthenticatedUser) request.getAttribute("authUser");

        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Unauthenticated"));
        }

        try {
            invitationService.completeSetup(body.get("token"), user);
            return ResponseEntity.ok(Map.of("message", "Setup complete"));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }
}
