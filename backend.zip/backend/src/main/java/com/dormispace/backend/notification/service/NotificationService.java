package com.dormispace.backend.notification.service;

import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.notification.model.UserDeviceToken;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.MessagingErrorCode;
import com.google.firebase.messaging.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class NotificationService {

    private final DeviceTokenService deviceTokenService;

    public int sendToUser(Long toUserId, String title, String body, Map<String, String> data) {
        if (toUserId == null) {
            throw new BadRequestException("toUserId is required");
        }
        if (title == null || title.isBlank()) {
            throw new BadRequestException("title is required");
        }
        if (body == null || body.isBlank()) {
            throw new BadRequestException("body is required");
        }

        Map<String, String> safeData = data == null ? Map.of() : new HashMap<>(data);
        List<UserDeviceToken> tokens = deviceTokenService.getActiveTokens(toUserId);
        if (tokens.isEmpty()) {
            log.info("No active device token found for userId={}", toUserId);
            return 0;
        }

        int success = 0;
        for (UserDeviceToken token : tokens) {
            Message message = Message.builder()
                    .setToken(token.getFcmToken())
                    .setNotification(Notification.builder().setTitle(title).setBody(body).build())
                    .putAllData(safeData)
                    .build();
            try {
                String messageId = FirebaseMessaging.getInstance().send(message);
                success++;
                log.info("Push sent userId={} tokenId={} messageId={}", toUserId, token.getId(), messageId);
            } catch (FirebaseMessagingException ex) {
                log.error("Failed push userId={} tokenId={} reason={}", toUserId, token.getId(), ex.getMessage());
                if (shouldDeactivateToken(ex)) {
                    deviceTokenService.deactivateToken(token.getFcmToken());
                }
            }
        }
        return success;
    }

    private boolean shouldDeactivateToken(FirebaseMessagingException ex) {
        MessagingErrorCode code = ex.getMessagingErrorCode();
        return code == MessagingErrorCode.UNREGISTERED || code == MessagingErrorCode.INVALID_ARGUMENT;
    }
}
