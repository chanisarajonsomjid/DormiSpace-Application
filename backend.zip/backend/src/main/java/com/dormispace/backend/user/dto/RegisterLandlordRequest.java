package com.dormispace.backend.user.dto;

import lombok.Data;

@Data
public class RegisterLandlordRequest {
    private String firstName;
    private String lastName;
    private String phoneNumber;
}
