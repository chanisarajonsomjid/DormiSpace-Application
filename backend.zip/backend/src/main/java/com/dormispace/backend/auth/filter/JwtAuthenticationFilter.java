package com.dormispace.backend.auth.filter;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.auth.service.AuthService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final AuthService authService;

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain
    ) throws ServletException, IOException {

        System.out.println(
                "[FILTER] incoming: " + request.getMethod() + " " + request.getRequestURI()
        );

        String authHeader = request.getHeader("Authorization");
        System.out.println("[FILTER] Authorization header = " + authHeader);

        // update
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);

            try {
                AuthenticatedUser user = authService.authenticate(token);

                request.setAttribute("authUser", user);

                // Put user into Spring Security Context
                Authentication authentication =
                        new UsernamePasswordAuthenticationToken(
                                user,
                                null,
                                List.of()
                        );

                SecurityContextHolder
                        .getContext()
                        .setAuthentication(authentication);

                System.out.println("[FILTER] Authenticated user = " + user.getEmail());

            } catch (RuntimeException ex) {
                System.out.println("[FILTER] Authentication failed: " + ex.getMessage());
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                return;
            }
        }

        filterChain.doFilter(request, response);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();

        return path.equals("/api/auth/register-landlord")
                || path.startsWith("/public")
                || path.equals("/health");
    }
}
