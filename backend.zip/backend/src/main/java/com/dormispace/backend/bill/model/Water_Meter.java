package com.dormispace.backend.bill.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Water_Meter")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Water_Meter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Meter_WaterID")
    private Long meterWaterId;

    @Column(name = "Room_ID", nullable = false)
    private Long roomId;

    @Column(name = "RecordedDate")
    private LocalDate recordedDate;

    @Column(name = "currentRead")
    private Integer currentRead;

    @Column(name = "previousRead")
    private Integer previousRead;

    @Column(name = "collectedWaterImage", columnDefinition = "TEXT")
    private String collectedWaterImage;

    @Column(name = "usedWaterUnit")
    private Integer usedWaterUnit;

    @Column(name = "TotalWaterPrice", precision = 10, scale = 2)
    private BigDecimal totalWaterPrice;

    // ── OCR audit fields ──────────────────────────────────────────────────────

    /**
     * Confidence score returned by Google Vision API (0.0–1.0).
     * Null when reading was entered manually (readingSource = "MANUAL").
     */
    @Column(name = "ocr_confidence", precision = 5, scale = 4)
    private BigDecimal ocrConfidence;

    /**
     * Raw text returned by Vision API before digit extraction.
     */
    @Column(name = "ocr_raw_text", columnDefinition = "TEXT")
    private String ocrRawText;

    /**
     * How the reading was obtained.
     * Values: "OCR", "MANUAL", "CORRECTED".
     */
    @Column(name = "reading_source", length = 20)
    private String readingSource;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @PrePersist
    @PreUpdate
    protected void calculateUsage() {
        if (this.currentRead != null && this.previousRead != null) {
            this.usedWaterUnit = this.currentRead - this.previousRead;
        }
    }

    // ── Business logic ────────────────────────────────────────────────────────

    public void calculateTotalPrice(BigDecimal pricePerUnit) {
        if (this.usedWaterUnit != null && pricePerUnit != null) {
            this.totalWaterPrice =
                    pricePerUnit.multiply(new BigDecimal(this.usedWaterUnit));
        }
    }

    public void calculateTieredPrice(int tier1Limit,
                                     BigDecimal tier1Price,
                                     BigDecimal tier2Price) {
        if (this.usedWaterUnit != null) {
            BigDecimal total;
            if (this.usedWaterUnit <= tier1Limit) {
                total = tier1Price.multiply(new BigDecimal(this.usedWaterUnit));
            } else {
                total = tier1Price.multiply(new BigDecimal(tier1Limit))
                        .add(tier2Price.multiply(
                                new BigDecimal(this.usedWaterUnit - tier1Limit)));
            }
            this.totalWaterPrice = total;
        }
    }

    public void calculateUsedUnits() {
        if (this.currentRead != null && this.previousRead != null) {
            this.usedWaterUnit = this.currentRead - this.previousRead;
        }
    }

    public boolean isValidReading() {
        return this.currentRead != null
                && this.previousRead != null
                && this.currentRead >= this.previousRead;
    }

    public String getUsageDisplay() {
        return this.usedWaterUnit != null ? this.usedWaterUnit + " units" : "N/A";
    }
}