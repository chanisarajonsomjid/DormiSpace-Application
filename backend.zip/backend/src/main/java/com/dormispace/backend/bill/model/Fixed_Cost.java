package com.dormispace.backend.bill.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.math.BigDecimal;

/**
 * Fixed_Cost Entity
 * Represents fixed costs for apartments (water, electricity, internet, parking, etc.)
 */
@Entity
@Table(name = "Fixed_Cost")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fixed_Cost {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FixedCost_ID")
    private Long fixedCostId;

    @Column(name = "FixedcostName", nullable = false)
    private String fixedcostName;

    @Column(name = "FixedcostPrice", precision = 10, scale = 2, nullable = false)
    private BigDecimal fixedcostPrice;

    @Column(name = "Apartment_ID", nullable = false)
    private Long apartmentId;

    @Column(name = "Unit", length = 50)
    private String unit; // Per Unit, Per Month, Per Time

    @Column(name = "FixedcostType", length = 50)
    private String fixedcostType; // water, electricity, internet, parking, late_fee

    @Column(name = "Charge_Method", length = 50)
    private String chargeMethod; // Multiply by usage, Fixed, Conditional

    @Column(name = "Applies_To", length = 50)
    private String appliesTo; // room, contract, bill

    @Column(name = "Is_Metered", nullable = false)
    private Boolean isMetered; // TRUE = needs meter calculation, FALSE = fixed charge

    /**
     * Check if this cost requires meter reading
     */
    public boolean requiresMeter() {
        return this.isMetered != null && this.isMetered;
    }

    /**
     * Check if this is a fixed monthly charge
     */
    public boolean isFixedMonthly() {
        return "Per Month".equalsIgnoreCase(this.unit);
    }

    /**
     * Check if this is a per-unit charge
     */
    public boolean isPerUnit() {
        return "Per Unit".equalsIgnoreCase(this.unit);
    }

    /**
     * Calculate cost based on usage
     */
    public BigDecimal calculateCost(Integer usage) {
        if (this.isMetered && usage != null) {
            return this.fixedcostPrice.multiply(new BigDecimal(usage));
        }
        // For fixed costs, return the price as is
        return this.fixedcostPrice;
    }

    /**
     * Check if this cost applies to a specific entity type
     */
    public boolean appliesTo(String entityType) {
        return this.appliesTo != null && this.appliesTo.equalsIgnoreCase(entityType);
    }
}