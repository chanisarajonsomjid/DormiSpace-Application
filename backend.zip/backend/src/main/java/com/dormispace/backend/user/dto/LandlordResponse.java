package com.dormispace.backend.user.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class LandlordResponse {

    private Long landlordId;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
}