package com.dormispace.backend.contract.service;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.contract.dto.ContractResponse;
import com.dormispace.backend.contract.dto.SubmitContractRequest;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.model.ContractStatus;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.room.model.RoomStatus;
import com.dormispace.backend.user.model.*;
import com.dormispace.backend.room.repository.RoomRepository;
import com.dormispace.backend.user.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class ContractService {

    private final ContractRepository contractRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;
    private final EmailService emailService;
    private final PdfService pdfService;
    private final FileStorageService fileStorageService;

    // Invite tenant
    @Transactional
    public Long createContractAndSendInvitation(
            AuthenticatedUser landlord,
            Long roomId,
            String tenantEmail,
            LocalDate startDate,
            LocalDate endDate,
            BigDecimal rentalRate,
            BigDecimal depositAmount,
            String contractType
    ) {
        log.debug("Invite flow start: tenantEmail={}", tenantEmail);

        String token = UUID.randomUUID().toString();

        User landlordUser = userRepository.findById(landlord.getUserId())
                .orElseThrow(() -> new RuntimeException("Landlord not found"));

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        if (!room.getApartment().getLandlord().getUser().getId()
                .equals(landlordUser.getId())) {
            throw new AccessDeniedException("You do not own this room");
        }

        boolean exists = contractRepository.existsByRoomAndStatusIn(
                room,
                List.of(
                        ContractStatus.PENDING_TENANT,
                        ContractStatus.PENDING_LANDLORD,
                        ContractStatus.ACTIVE
                )
        );

        if (exists) {
            throw new IllegalStateException("Contract already exists for this room");
        }

        if (startDate == null || endDate == null) {
            throw new IllegalArgumentException("Start and end date are required");
        }
        if (startDate.isAfter(endDate)) {
            throw new IllegalArgumentException("End date must be after start date");
        }
        if (rentalRate == null || rentalRate.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Rental rate must be greater than zero");
        }

        User tenant = userRepository.findByEmail(tenantEmail)
                .orElseGet(() -> {
                    User u = new User();
                    u.setEmail(tenantEmail);
                    u.setRole(Role.TENANT);
                    u.setAccountStatus(AccountStatus.PENDING);
                    return userRepository.save(u);
                });

        Contract contract = new Contract();
        contract.setRoom(room);
        contract.setTenant(tenant);
        contract.setStatus(ContractStatus.PENDING_TENANT);
        contract.setStartDate(startDate);
        contract.setEndDate(endDate);
        contract.setRentalRate(rentalRate);
        contract.setDepositAmount(depositAmount);
        contract.setContractType(contractType);
        contract.setInvitationToken(token);
        contract.setTokenExpiresAt(LocalDateTime.now().plusDays(7));
        contract.setInvitationSentAt(LocalDateTime.now());
        contract.setInvitationStatus("SENT");

        contractRepository.save(contract);

        room.setStatus(RoomStatus.PENDING_TENANT);
        roomRepository.save(room);

        emailService.sendInvitationEmail(
                tenantEmail,
                landlordUser.getEmail(),
                room.getRoomNumber(),
                room.getApartment().getName(),
                token
        );

        return contract.getContractId();
    }

    // Resend invitation
    @Transactional
    public void resendInvitation(Long contractId, Long landlordId) {
        Contract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new RuntimeException("Contract not found"));

        Long ownerId = contract.getRoom().getApartment().getLandlord().getUser().getId();
        if (!ownerId.equals(landlordId)) {
            throw new AccessDeniedException("Not your contract");
        }

        String newToken = UUID.randomUUID().toString();
        contract.setInvitationToken(newToken);
        contract.setTokenExpiresAt(LocalDateTime.now().plusDays(7));
        contract.setInvitationSentAt(LocalDateTime.now());
        contract.setInvitationStatus("SENT");
        contractRepository.save(contract);

        emailService.resendInvitationEmail(
                contract.getTenant().getEmail(),
                contract.getRoom().getApartment().getLandlord().getUser().getEmail(),
                contract.getRoom().getRoomNumber(),
                contract.getRoom().getApartment().getName(),
                newToken
        );
    }

    // Tenant: submit contract
    @Transactional
    public void submitContract(
            Long contractId,
            Long tenantUserId,
            SubmitContractRequest req
    ) {
        Contract contract = contractRepository
                .findById(contractId)
                .orElseThrow(() -> new RuntimeException("Contract not found"));

        if (!contract.getTenant().getId().equals(tenantUserId)) {
            throw new IllegalStateException("Unauthorized tenant");
        }
        if (contract.getStatus() != ContractStatus.PENDING_TENANT) {
            throw new IllegalStateException("Contract locked");
        }
        if (contract.getSignatureTenant() != null) {
            throw new IllegalStateException("Already signed");
        }
        if (req.getFirstName() == null || req.getFirstName().isBlank()
                || req.getLastName() == null || req.getLastName().isBlank()
                || req.getPhoneNumber() == null || req.getPhoneNumber().isBlank()) {
            throw new IllegalArgumentException("Missing required fields");
        }
        if (req.getSignatureTenant() == null
                || req.getSignatureWitness1() == null
                || req.getSignatureWitness2() == null) {
            throw new IllegalArgumentException("All signatures are required");
        }

        contract.setFirstName(req.getFirstName());
        contract.setLastName(req.getLastName());
        contract.setAddress(req.getAddress());
        contract.setPhoneNumber(req.getPhoneNumber());
        contract.setSignatureTenant(req.getSignatureTenant());
        contract.setWitness1FirstName(req.getWitness1FirstName());
        contract.setWitness1LastName(req.getWitness1LastName());
        contract.setSignatureWitness1(req.getSignatureWitness1());
        contract.setWitness2FirstName(req.getWitness2FirstName());
        contract.setWitness2LastName(req.getWitness2LastName());
        contract.setSignatureWitness2(req.getSignatureWitness2());
        contract.setSignedTenantAt(LocalDateTime.now());
        contract.setStatus(ContractStatus.PENDING_LANDLORD);

        Room room = contract.getRoom();
        room.setStatus(RoomStatus.PENDING_LANDLORD);

        contractRepository.save(contract);
        roomRepository.save(room);
    }

    // -------------------------------------------------------------------------
    // Queries
    // -------------------------------------------------------------------------

    public ContractResponse getMyContract(Long tenantUserId) {
        log.debug("getMyContract tenantUserId={}", tenantUserId);
        Contract c = contractRepository
                .findTopByTenantIdOrderByCreatedAtDesc(tenantUserId)
                .orElseThrow(() -> new RuntimeException("No contract found"));
        return toContractResponse(c);
    }

    public List<ContractResponse> getLandlordContracts(Long landlordId) {
        return contractRepository.findByLandlordIdAndStatusIn(
                        landlordId,
                        List.of(
                                ContractStatus.DRAFT,
                                ContractStatus.ACTIVE,
                                ContractStatus.PENDING_TENANT,
                                ContractStatus.PENDING_LANDLORD
                        )
                ).stream()
                .map(this::toContractResponse)
                .toList();
    }

    public ContractResponse getContractResponseForUser(Long contractId, AuthenticatedUser user) {
        return toContractResponse(getContractByIdForUser(contractId, user));
    }

    public Contract getContractByIdForUser(Long contractId, AuthenticatedUser user) {
        Contract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new RuntimeException("Contract not found"));

        if (user.getRole() == Role.TENANT) {
            if (!contract.getTenant().getId().equals(user.getUserId())) {
                throw new RuntimeException("Unauthorized");
            }
        } else if (user.getRole() == Role.LANDLORD) {
            Long landlordId = contract.getRoom()
                    .getApartment()
                    .getLandlord()
                    .getUser()
                    .getId();
            if (!landlordId.equals(user.getUserId())) {
                throw new RuntimeException("Unauthorized");
            }
        } else {
            throw new RuntimeException("Invalid role");
        }
        return contract;
    }

    @Transactional
    public void terminateContract(Long contractId) {
        Contract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new RuntimeException("Contract not found"));
        contract.setStatus(ContractStatus.TERMINATED);
        contractRepository.save(contract);
        Room room = contract.getRoom();
        room.setStatus(RoomStatus.VACANT);
        roomRepository.save(room);
    }

    @Transactional
    public void landlordSign(Long contractId, Long landlordUserId, String signatureBase64) {
        Contract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new RuntimeException("Contract not found"));

        if (contract.getStatus() != ContractStatus.PENDING_LANDLORD) {
            throw new IllegalStateException("Contract not ready for landlord signing");
        }
        if (!contract.getRoom().getApartment().getLandlord().getUser().getId()
                .equals(landlordUserId)) {
            throw new IllegalStateException("Not your contract");
        }
        if (contract.getSignatureLandlord() != null) {
            throw new IllegalStateException("Already signed");
        }
        if (contract.getSignatureTenant() == null ||
                contract.getSignatureWitness1() == null ||
                contract.getSignatureWitness2() == null) {
            throw new IllegalStateException("Tenant signatures incomplete");
        }

        contract.setSignatureLandlord(signatureBase64);
        contract.setSignedLandlordAt(LocalDateTime.now());
        contract.setStatus(ContractStatus.ACTIVE);
        contract.setLockedAt(LocalDateTime.now());

        generateFinalPdfAndHash(contract);

        Room room = contract.getRoom();
        room.setStatus(RoomStatus.OCCUPIED);

        contractRepository.save(contract);
        roomRepository.save(room);
    }

    @Transactional
    public void cancelPendingContract(Long contractId, Long landlordUserId) {
        Contract contract = contractRepository.findById(contractId)
                .orElseThrow(() -> new RuntimeException("Contract not found"));

        // allow cancel even if tenant is missing
        if (contract.getStatus() != ContractStatus.PENDING_TENANT &&
                contract.getStatus() != ContractStatus.PENDING_LANDLORD) {
            throw new IllegalStateException("Cannot cancel this contract");
        }

        // Security check
        Long ownerId = contract.getRoom()
                .getApartment()
                .getLandlord()
                .getUser()
                .getId();

        if (!ownerId.equals(landlordUserId)) {
            throw new RuntimeException("Unauthorized");
        }

        // Reset contract
        contract.setStatus(ContractStatus.CANCELLED);

        // Reset room
        Room room = contract.getRoom();
        room.setStatus(RoomStatus.VACANT);

        contractRepository.save(contract);
        roomRepository.save(room);
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private ContractResponse toContractResponse(Contract c) {
        ContractResponse dto = new ContractResponse();
        dto.setContractId(c.getContractId());
        dto.setRoomId(c.getRoom().getRoomId());
        dto.setUserId(c.getTenant().getId());                    // ← added
        dto.setRentalRate(c.getRentalRate());                    // ← added
        dto.setDepositAmount(c.getDepositAmount());
        dto.setContractType(c.getContractType());
        dto.setStatus(c.getStatus());
        dto.setFirstName(c.getFirstName());
        dto.setLastName(c.getLastName());
        dto.setAddress(c.getAddress());
        dto.setPhoneNumber(c.getPhoneNumber());
        dto.setEmail(c.getTenant() != null ? c.getTenant().getEmail() : null);
        dto.setStartDate(c.getStartDate());
        dto.setEndDate(c.getEndDate());
        dto.setRoomNumber(c.getRoom().getRoomNumber());
        dto.setApartmentName(c.getRoom().getApartment().getName());
        dto.setSignatureTenant(c.getSignatureTenant());
        dto.setWitness1FirstName(c.getWitness1FirstName());
        dto.setWitness1LastName(c.getWitness1LastName());
        dto.setSignatureWitness1(c.getSignatureWitness1());
        dto.setWitness2FirstName(c.getWitness2FirstName());
        dto.setWitness2LastName(c.getWitness2LastName());
        dto.setSignatureWitness2(c.getSignatureWitness2());
        dto.setSignatureLandlord(c.getSignatureLandlord());
        dto.setSignedTenantAt(c.getSignedTenantAt());
        dto.setSignedLandlordAt(c.getSignedLandlordAt());
        if (c.getStatus() == ContractStatus.ACTIVE) {
            dto.setFinalPdfUrl(c.getFinalPdfUrl());
        }
        return dto;
    }

    private void generateFinalPdfAndHash(Contract contract) {
        if (contract.getStatus() != ContractStatus.ACTIVE) {
            throw new IllegalStateException("Contract must be ACTIVE before generating final PDF");
        }
        try {
            byte[] pdfBytes = pdfService.generateFinalContract(contract);
            if (pdfBytes == null || pdfBytes.length == 0) {
                throw new RuntimeException("Generated PDF is empty");
            }
            String fileName = "contract_" + contract.getContractId() + "_" + UUID.randomUUID() + ".pdf";
            String fileUrl = fileStorageService.save(pdfBytes, fileName);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(pdfBytes);
            String hashHex = HexFormat.of().formatHex(hashBytes);
            contract.setFinalPdfUrl(fileUrl);
            contract.setFinalPdfHash(hashHex);
            contractRepository.save(contract);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        } catch (Exception e) {
            throw new RuntimeException("Final PDF generation failed", e);
        }
    }
}