package com.dormispace.backend.notification.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.notification.dto.SendNotificationRequest;
import com.dormispace.backend.notification.service.NotificationService;
import com.dormispace.backend.user.model.Role;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping("/send")
    @PreAuthorize("hasRole('LANDLORD')")
    public ResponseEntity<Map<String, Object>> sendToUser(
            @RequestAttribute("authUser") AuthenticatedUser authUser,
            @Valid @RequestBody SendNotificationRequest request
    ) {
        if (authUser == null) {
            throw new BadRequestException("Unauthenticated");
        }
        if (authUser.getRole() != Role.LANDLORD) {
            throw new BadRequestException("Only landlord can send direct notifications");
        }
        int delivered = notificationService.sendToUser(
                request.getToUserId(),
                request.getTitle(),
                request.getBody(),
                request.getData()
        );
        Map<String, Object> response = new HashMap<>();
        response.put("deliveredCount", delivered);
        return ResponseEntity.ok(response);
    }
}
