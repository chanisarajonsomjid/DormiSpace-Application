package com.dormispace.backend.room.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class ContractDraftResponse {
    private Long roomId;
    private String roomNumber;
    private BigDecimal monthlyRent;
    private BigDecimal deposit;
    private int suggestedDurationMonths;
    private LocalDate suggestedStartDate;
    private LocalDate suggestedEndDate;
}
