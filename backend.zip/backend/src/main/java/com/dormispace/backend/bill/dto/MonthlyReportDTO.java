package com.dormispace.backend.bill.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * DTO for monthly report response
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MonthlyReportDTO {
    private Long apartmentId;
    private Long apartmentName;
    private Integer year;
    private Integer month;
    
    // Summary statistics
    private Integer totalBills;
    private Integer paidBills;
    private Integer unpaidBills;
    private Integer overdueBills;
    
    // Financial summary
    private BigDecimal totalAmount;
    private BigDecimal totalPaid;
    private BigDecimal totalUnpaid;
    private BigDecimal totalOverdue;
    
    // Breakdown
    private BigDecimal totalRentAmount;
    private BigDecimal totalWaterAmount;
    private BigDecimal totalElectricityAmount;
    private BigDecimal totalFixedCosts;
    private BigDecimal totalLateFees;
    
    // Dates
    private LocalDate reportGeneratedAt;
}