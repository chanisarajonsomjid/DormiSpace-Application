package com.dormispace.backend.notification.service;

import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.notification.dto.RegisterDeviceTokenRequest;
import com.dormispace.backend.notification.model.DevicePlatform;
import com.dormispace.backend.notification.model.UserDeviceToken;
import com.dormispace.backend.notification.repository.UserDeviceTokenRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class DeviceTokenService {

    private final UserDeviceTokenRepository userDeviceTokenRepository;

    public UserDeviceToken registerToken(Long userId, RegisterDeviceTokenRequest request) {
        String token = normalizeToken(request.getFcmToken());
        DevicePlatform platform = parsePlatform(request.getPlatform());

        UserDeviceToken record = userDeviceTokenRepository.findByFcmToken(token)
                .map(existing -> {
                    existing.setUserId(userId);
                    existing.setPlatform(platform);
                    existing.setActive(true);
                    existing.setLastSeenAt(OffsetDateTime.now());
                    return existing;
                })
                .orElseGet(() -> UserDeviceToken.builder()
                        .userId(userId)
                        .fcmToken(token)
                        .platform(platform)
                        .active(true)
                        .build());

        UserDeviceToken saved = userDeviceTokenRepository.save(record);
        log.info("Registered device token userId={} tokenId={} platform={}", userId, saved.getId(), saved.getPlatform());
        return saved;
    }

    public void removeToken(Long userId, String fcmToken) {
        String token = normalizeToken(fcmToken);
        userDeviceTokenRepository.findByFcmToken(token).ifPresent(record -> {
            if (!record.getUserId().equals(userId)) {
                throw new BadRequestException("Token does not belong to this user");
            }
            record.setActive(false);
            record.setLastSeenAt(OffsetDateTime.now());
            userDeviceTokenRepository.save(record);
            log.info("Disabled device token userId={} tokenId={}", userId, record.getId());
        });
    }

    @Transactional(readOnly = true)
    public List<UserDeviceToken> getActiveTokens(Long userId) {
        return userDeviceTokenRepository.findByUserIdAndActiveTrue(userId);
    }

    void deactivateToken(String fcmToken) {
        userDeviceTokenRepository.findByFcmToken(fcmToken).ifPresent(record -> {
            record.setActive(false);
            record.setLastSeenAt(OffsetDateTime.now());
            userDeviceTokenRepository.save(record);
        });
    }

    private String normalizeToken(String token) {
        if (token == null || token.isBlank()) {
            throw new BadRequestException("fcmToken is required");
        }
        String normalized = token.trim();
        if (normalized.length() < 32) {
            throw new BadRequestException("fcmToken is invalid");
        }
        return normalized;
    }

    private DevicePlatform parsePlatform(String rawPlatform) {
        if (rawPlatform == null || rawPlatform.isBlank()) {
            return DevicePlatform.UNKNOWN;
        }
        try {
            return DevicePlatform.valueOf(rawPlatform.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return DevicePlatform.UNKNOWN;
        }
    }
}
