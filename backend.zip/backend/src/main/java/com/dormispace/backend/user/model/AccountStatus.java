package com.dormispace.backend.user.model;

public enum AccountStatus {
    ACTIVE,
    PENDING,
    INACTIVE
}
