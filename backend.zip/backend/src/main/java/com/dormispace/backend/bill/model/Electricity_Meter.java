package com.dormispace.backend.bill.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Electricity_Meter")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Electricity_Meter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Meter_ID")
    private Long meterId;

    @Column(name = "Room_ID", nullable = false)
    private Long roomId;

    @Column(name = "readingDate")
    private LocalDate readingDate;

    @Column(name = "currentRead")
    private Integer currentRead;

    @Column(name = "previousRead")
    private Integer previousRead;

    @Column(name = "collectedElecImage", columnDefinition = "TEXT")
    private String collectedElecImage;

    @Column(name = "usedElecUnit")
    private Integer usedElecUnit;

    @Column(name = "TotalElectricityPrice", precision = 10, scale = 2)
    private BigDecimal totalElectricityPrice;

    // ── OCR audit fields ──────────────────────────────────────────────────────

    /**
     * Confidence score returned by Google Vision API (0.0–1.0).
     * Values below ~0.70 should be flagged for manual verification in Flutter.
     * Null when reading was entered manually (readingSource = "MANUAL").
     */
    @Column(name = "ocr_confidence", precision = 5, scale = 4)
    private BigDecimal ocrConfidence;

    /**
     * Raw text returned by Vision API before digit extraction.
     * Stored for debugging OCR failures and improving accuracy over time.
     */
    @Column(name = "ocr_raw_text", columnDefinition = "TEXT")
    private String ocrRawText;

    /**
     * How the reading was obtained.
     * Values: "OCR" (auto-read), "MANUAL" (typed by landlord),
     *         "CORRECTED" (OCR ran but landlord edited the result).
     */
    @Column(name = "reading_source", length = 20)
    private String readingSource;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @PrePersist
    @PreUpdate
    protected void calculateUsage() {
        if (this.currentRead != null && this.previousRead != null) {
            this.usedElecUnit = this.currentRead - this.previousRead;
        }
    }

    // ── Business logic ────────────────────────────────────────────────────────

    public void calculateTotalPrice(BigDecimal pricePerUnit) {
        if (this.usedElecUnit != null && pricePerUnit != null) {
            this.totalElectricityPrice =
                    pricePerUnit.multiply(new BigDecimal(this.usedElecUnit));
        }
    }

    public void calculateProgressiveTariff(
            int tier1Limit, BigDecimal tier1Price,
            int tier2Limit, BigDecimal tier2Price,
            BigDecimal tier3Price) {

        if (this.usedElecUnit != null) {
            BigDecimal total = BigDecimal.ZERO;
            if (this.usedElecUnit <= tier1Limit) {
                total = tier1Price.multiply(new BigDecimal(this.usedElecUnit));
            } else if (this.usedElecUnit <= tier2Limit) {
                total = tier1Price.multiply(new BigDecimal(tier1Limit))
                        .add(tier2Price.multiply(
                                new BigDecimal(this.usedElecUnit - tier1Limit)));
            } else {
                total = tier1Price.multiply(new BigDecimal(tier1Limit))
                        .add(tier2Price.multiply(
                                new BigDecimal(tier2Limit - tier1Limit)))
                        .add(tier3Price.multiply(
                                new BigDecimal(this.usedElecUnit - tier2Limit)));
            }
            this.totalElectricityPrice = total;
        }
    }

    public void calculateWithFT(BigDecimal basePrice, BigDecimal ftRate) {
        if (this.usedElecUnit != null && basePrice != null && ftRate != null) {
            this.totalElectricityPrice = basePrice.add(ftRate)
                    .multiply(new BigDecimal(this.usedElecUnit));
        }
    }

    public void calculateUsedUnits() {
        if (this.currentRead != null && this.previousRead != null) {
            this.usedElecUnit = this.currentRead - this.previousRead;
        }
    }

    public boolean isValidReading() {
        return this.currentRead != null
                && this.previousRead != null
                && this.currentRead >= this.previousRead;
    }

    public String getUsageDisplay() {
        return this.usedElecUnit != null ? this.usedElecUnit + " kWh" : "N/A";
    }

    public boolean isHighUsage(int threshold) {
        return this.usedElecUnit != null && this.usedElecUnit > threshold;
    }
}