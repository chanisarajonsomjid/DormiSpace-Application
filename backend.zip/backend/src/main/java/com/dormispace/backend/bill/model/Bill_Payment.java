package com.dormispace.backend.bill.model;

import com.dormispace.backend.contract.model.Contract;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "Bill_Payment")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bill_Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Bill_ID")
    private Long billId;

    @Column(name = "Apartment_ID", nullable = false)
    private Long apartmentId;

    @Column(name = "Room_ID", nullable = false)
    private Long roomId;

    @Column(name = "User_ID", nullable = false)
    private Long userId;

    /**
     * Replaced raw Long contractId with a proper ManyToOne relationship.
     * This lets you access contract.startDate for proration,
     * contract.rentalRate for the rent line item, and
     * contract.tenant for the bill recipient — all without
     * manual lookups in the service layer.
     * LAZY fetch: contract data is only loaded when explicitly accessed,
     * keeping list queries (e.g. all unpaid bills) lightweight.
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "contract_id", nullable = false)
    private Contract contract;

    @Column(name = "Created_Date")
    private LocalDate createdDate;

    @Column(name = "Payment_Date")
    private LocalDate paymentDate;

    @Column(name = "Due_Date")
    private LocalDate dueDate;

    @Column(name = "Receipt_Date")
    private LocalDate receiptDate;

    @Column(name = "Subtotal", precision = 10, scale = 2)
    private BigDecimal subtotal;

    @Column(name = "Late_Fee", precision = 10, scale = 2,
            columnDefinition = "NUMERIC(10,2) DEFAULT 0")
    private BigDecimal lateFee;

    @Column(name = "Total_Amount", precision = 10, scale = 2)
    private BigDecimal totalAmount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "Payment_Method", length = 30)
    private PaymentMethod paymentMethod;

    /**
     * Kept only createdAt (timestamp) — removed the redundant createdDate (date-only).
     * Use createdAt.toLocalDate() anywhere you need just the date.
     */
    @Column(name = "Created_At", nullable = false, updatable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private LocalDateTime createdAt;

    @Column(name = "Omise_Source_Id")
    private String omiseSourceId;

    @Column(name = "Omise_Charge_Id")
    private String omiseChargeId;

    @Column(name = "Omise_Status")
    private String omiseStatus;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.lateFee = BigDecimal.ZERO;
        this.paymentStatus = PaymentStatus.UNPAID;
    }

    // --- Business logic ---

    public boolean isOverdue() {
        return this.paymentStatus == PaymentStatus.OVERDUE;
    }

    public boolean isPaid() {
        return this.paymentStatus == PaymentStatus.PAID;
    }

    public boolean isPending() {
        return this.paymentStatus == PaymentStatus.PENDING
                || this.paymentStatus == PaymentStatus.UNPAID;
    }

    public void calculateTotalAmount() {
        if (this.subtotal != null) {
            BigDecimal fee = this.lateFee != null ? this.lateFee : BigDecimal.ZERO;
            this.totalAmount = this.subtotal.add(fee);
        }
    }

    public void markAsPaid(LocalDate paymentDate, PaymentMethod paymentMethod) {
        this.paymentStatus = PaymentStatus.PAID;
        this.paymentDate = paymentDate;
        this.receiptDate = paymentDate;
        this.paymentMethod = paymentMethod;
    }

    public void markAsOverdue() {
        this.paymentStatus = PaymentStatus.OVERDUE;
    }

    // --- Convenience accessors (avoids repeated contract.getX() chains) ---

    /**
     * Returns the tenant's User ID directly from the linked contract.
     * Useful when building bill notification payloads.
     */
    public Long getTenantUserId() {
        return this.contract != null && this.contract.getTenant() != null
                ? this.contract.getTenant().getId()
                : null;
    }

    /**
     * Returns the agreed rental rate from the contract.
     * Always use this — never Room.monthlyRent — for bill generation.
     */
    public BigDecimal getRentalRate() {
        return this.contract != null ? this.contract.getRentalRate() : null;
    }

    /**
     * Returns the contract start date, used to calculate proration
     * for a tenant's first billing cycle.
     */
    public LocalDate getContractStartDate() {
        return this.contract != null ? this.contract.getStartDate() : null;
    }
}