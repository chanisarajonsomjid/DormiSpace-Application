package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.model.PaymentMethod;
import com.dormispace.backend.bill.service.PaymentProcessingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * REST Controller for Payment Processing
 * Handles payment operations, receipts, and late fees
 */
@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
@Slf4j
public class PaymentController {

    private final PaymentProcessingService paymentProcessingService;

    @PostMapping("/process")
    public ResponseEntity<Bill_Payment> processPayment(@RequestBody PaymentRequest request) {
        log.info("Processing payment for bill: {}", request.getBillId());
        Bill_Payment paid = paymentProcessingService.processPayment(
                request.getBillId(),
                request.getPaymentMethod(),
                request.getPaymentDate()
        );
        return ResponseEntity.ok(paid);
    }

    @PostMapping("/process-with-late-fee")
    public ResponseEntity<Bill_Payment> processPaymentWithLateFee(@RequestBody PaymentWithLateFeeRequest request) {
        log.info("Processing payment with late fee check for bill: {}", request.getBillId());
        Bill_Payment paid = paymentProcessingService.processPaymentWithLateFee(
                request.getBillId(),
                request.getPaymentMethod(),
                request.getPaymentDate()
        );
        return ResponseEntity.ok(paid);
    }

    @GetMapping("/receipt/{billId}")
    public ResponseEntity<Map<String, Object>> generateReceipt(@PathVariable Long billId) {
        log.info("Generating receipt for bill: {}", billId);
        Map<String, Object> receipt = paymentProcessingService.generateReceipt(billId);
        return ResponseEntity.ok(receipt);
    }

    @PostMapping("/apply-late-fee/{billId}")
    public ResponseEntity<Bill_Payment> applyLateFee(
            @PathVariable Long billId,
            @RequestParam BigDecimal amount) {

        log.info("Applying late fee to bill: {}, amount: {}", billId, amount);
        Bill_Payment withFee = paymentProcessingService.applyLateFee(billId, amount);
        return ResponseEntity.ok(withFee);
    }

    @PostMapping("/apply-automatic-late-fee/{billId}")
    public ResponseEntity<Bill_Payment> applyAutomaticLateFee(
            @PathVariable Long billId) {

        log.info("Applying automatic late fee to bill: {}", billId);

        Bill_Payment withFee = paymentProcessingService.applyAutomaticLateFee(billId);

        return ResponseEntity.ok(withFee);
    }

    @GetMapping("/calculate-late-fee")
    public ResponseEntity<Map<String, Object>> calculateLateFee(
            @RequestParam Long apartmentId,
            @RequestParam Integer daysLate) {

        log.info("Calculating late fee for apartment: {}, days late: {}", apartmentId, daysLate);
        BigDecimal lateFee = paymentProcessingService.calculateLateFee(apartmentId, daysLate);

        Map<String, Object> response = new HashMap<>();
        response.put("apartmentId", apartmentId);
        response.put("daysLate", daysLate);
        response.put("lateFee", lateFee);

        return ResponseEntity.ok(response);
    }

    @PostMapping("/cancel/{billId}")
    public ResponseEntity<Bill_Payment> cancelPayment(
            @PathVariable Long billId,
            @RequestParam String reason) {

        log.info("Cancelling payment for bill: {}, reason: {}", billId, reason);
        Bill_Payment cancelled = paymentProcessingService.cancelPayment(billId, reason);
        return ResponseEntity.ok(cancelled);
    }

    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getPaymentStatistics(
            @RequestParam Long apartmentId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        log.info("Getting payment statistics for apartment: {}, period: {} to {}",
                apartmentId, startDate, endDate);

        Map<String, Object> stats = paymentProcessingService.getPaymentStatistics(
                apartmentId, startDate, endDate
        );
        return ResponseEntity.ok(stats);
    }

    @lombok.Data
    public static class PaymentRequest {
        private Long billId;
        private PaymentMethod paymentMethod;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
        private LocalDate paymentDate;
    }

    @lombok.Data
    public static class PaymentWithLateFeeRequest {
        private Long billId;
        private PaymentMethod paymentMethod;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
        private LocalDate paymentDate;
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
        private LocalDate dueDate;
    }
}
