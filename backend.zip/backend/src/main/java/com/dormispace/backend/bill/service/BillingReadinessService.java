package com.dormispace.backend.bill.service;

import com.dormispace.backend.apartment.model.Apartment;
import com.dormispace.backend.apartment.repository.ApartmentRepository;
import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.bill.dto.BillingReadinessResponse;
import com.dormispace.backend.bill.dto.RoomReadinessItem;
import com.dormispace.backend.bill.model.Electricity_Meter;
import com.dormispace.backend.bill.model.UtilitySetting;
import com.dormispace.backend.bill.model.Water_Meter;
import com.dormispace.backend.bill.repository.ElectricityMeterRepository;
import com.dormispace.backend.bill.repository.WaterMeterRepository;
import com.dormispace.backend.contract.model.ContractStatus;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.room.model.RoomStatus;
import com.dormispace.backend.room.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import com.dormispace.backend.bill.repository.UtilitySettingRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BillingReadinessService {

    private final UtilitySettingRepository utilitySettingRepository;
    private final RoomRepository roomRepository;
    private final ContractRepository contractRepository;
    private final WaterMeterRepository waterMeterRepository;
    private final ElectricityMeterRepository electricityMeterRepository;
    private final ApartmentRepository apartmentRepository;

    public BillingReadinessResponse getBillingReadiness(Long apartmentId, AuthenticatedUser user) {

        // ── 1. Apartment + ownership check ─────────────────────────────────
        Apartment apartment = apartmentRepository.findById(apartmentId)
                .orElseThrow(() -> new IllegalArgumentException("Apartment not found: " + apartmentId));

        // Guard against broken landlord/user relationship in DB
        if (apartment.getLandlord() == null
                || apartment.getLandlord().getUser() == null
                || apartment.getLandlord().getUser().getId() == null) {
            throw new IllegalStateException("Apartment " + apartmentId + " has no valid landlord assigned");
        }

        if (!apartment.getLandlord().getUser().getId().equals(user.getUserId())) {
            throw new AccessDeniedException("You do not own this apartment");
        }

        // ── 2. Utility setting ─────────────────────────────────────────────
        UtilitySetting setting = utilitySettingRepository
                .findByApartmentId(apartmentId)
                .orElse(null);

        boolean utilitySettingExists = setting != null;
        boolean utilitySettingComplete = isUtilitySettingComplete(setting);

        // ── 3. Occupied rooms ──────────────────────────────────────────────
        List<Room> occupiedRooms = roomRepository
                .findByApartment_ApartmentIdAndStatus(apartmentId, RoomStatus.OCCUPIED);

        // Safety: filter out any rooms with null IDs
        occupiedRooms = occupiedRooms.stream()
                .filter(r -> r.getRoomId() != null)
                .toList();

        int totalOccupiedRooms = occupiedRooms.size();

        List<Long> roomIds = occupiedRooms.stream()
                .map(Room::getRoomId)
                .toList();

        // ── 4. Active contracts (batch) ────────────────────────────────────
        Set<Long> activeRoomIds;
        if (roomIds.isEmpty()) {
            activeRoomIds = Set.of();
        } else {
            activeRoomIds = contractRepository
                    .findByRoom_RoomIdInAndStatus(roomIds, ContractStatus.ACTIVE)
                    .stream()
                    .filter(c -> c.getRoom() != null && c.getRoom().getRoomId() != null)
                    .map(c -> c.getRoom().getRoomId())
                    .collect(Collectors.toSet());
        }

        // ── 5. Current billing cycle ───────────────────────────────────────
        LocalDate now = LocalDate.now();
        LocalDate start = now.withDayOfMonth(1);
        LocalDate end = now.withDayOfMonth(now.lengthOfMonth());

        // ── 6. Meter readiness (batch, skip DB call if no rooms) ───────────
        Set<Long> waterReadyRoomIds;
        Set<Long> electricityReadyRoomIds;

        if (roomIds.isEmpty()) {
            waterReadyRoomIds = Set.of();
            electricityReadyRoomIds = Set.of();
        } else {
            waterReadyRoomIds = waterMeterRepository
                    .findByRoomIdInAndRecordedDateBetween(roomIds, start, end)
                    .stream()
                    .filter(m -> m.getRoomId() != null)
                    .map(Water_Meter::getRoomId)
                    .collect(Collectors.toSet());

            electricityReadyRoomIds = electricityMeterRepository
                    .findByRoomIdInAndReadingDateBetween(roomIds, start, end)
                    .stream()
                    .filter(m -> m.getRoomId() != null)
                    .map(Electricity_Meter::getRoomId)
                    .collect(Collectors.toSet());
        }

        // ── 7. Evaluate rooms ──────────────────────────────────────────────
        int totalBillableRooms = 0;
        int readyRooms = 0;
        List<RoomReadinessItem> roomIssues = new ArrayList<>();

        for (Room room : occupiedRooms) {
            Long roomId = room.getRoomId();
            boolean hasActiveContract = activeRoomIds.contains(roomId);

            if (!hasActiveContract) {
                roomIssues.add(new RoomReadinessItem(
                        roomId,
                        room.getRoomNumber(),
                        false, false, false,
                        List.of("activeContract")
                ));
                continue;
            }

            totalBillableRooms++;

            boolean waterReady = waterReadyRoomIds.contains(roomId);
            boolean electricityReady = electricityReadyRoomIds.contains(roomId);

            if (waterReady && electricityReady) {
                readyRooms++;
            } else {
                List<String> missing = new ArrayList<>();
                if (!waterReady) missing.add("waterReading");
                if (!electricityReady) missing.add("electricityReading");

                roomIssues.add(new RoomReadinessItem(
                        roomId,
                        room.getRoomNumber(),
                        true,
                        waterReady,
                        electricityReady,
                        missing
                ));
            }
        }

        // ── 8. Final flags ─────────────────────────────────────────────────
        boolean hasBillableRooms = totalBillableRooms > 0;
        boolean allMetersReady = hasBillableRooms && (readyRooms == totalBillableRooms);
        boolean canSendBills = utilitySettingComplete && hasBillableRooms && allMetersReady;

        // ── 9. Human-readable reasons ──────────────────────────────────────
        List<String> reasons = new ArrayList<>();

        if (!utilitySettingExists) {
            reasons.add("Utility setting has not been created");
        } else if (!utilitySettingComplete) {
            reasons.add("Please complete utility settings (rates, billing day, bank account)");
        }

        if (totalOccupiedRooms == 0) {
            reasons.add("No occupied rooms found");
        } else if (!hasBillableRooms) {
            reasons.add("No occupied rooms have an active contract");
        }

        if (hasBillableRooms && !allMetersReady) {
            int missing = totalBillableRooms - readyRooms;
            reasons.add(missing + " room(s) missing meter readings this month");
        }

        // ── 10. Build & return response ────────────────────────────────────
        BillingReadinessResponse res = new BillingReadinessResponse();

        res.setUtilitySettingExists(utilitySettingExists);
        res.setUtilitySettingComplete(utilitySettingComplete);

        res.setTotalOccupiedRooms(totalOccupiedRooms);
        res.setTotalBillableRooms(totalBillableRooms);
        res.setReadyRooms(readyRooms);

        res.setHasBillableRooms(hasBillableRooms);
        res.setAllMetersReady(allMetersReady);

        res.setCanCollectMeter(utilitySettingComplete);
        res.setCanAccessBills(utilitySettingComplete);
        res.setCanSendBills(canSendBills);

        res.setReasons(reasons);
        res.setRoomIssues(roomIssues);

        return res;
    }

    private boolean isUtilitySettingComplete(UtilitySetting setting) {
        if (setting == null) return false;

        return setting.getBillingDayOfMonth() != null
                && setting.getBankAccountName() != null
                && setting.getBankAccountNumber() != null
                && setting.getCommonAreaFee() != null
                && setting.getLateFeePerDay() != null
                && setting.getWaterRate() != null
                && setting.getElectricRate() != null;
    }
}