package com.dormispace.backend.apartment.dto;

import lombok.Data;
import java.util.Map;

@Data
public class CreateApartmentRequest {

    private String name;
    private String address;
    private String district;
    private String province;
    private String postcode;
    private String city;
    private String phone_Num;

    private Map<Integer, Integer> floors;
    // key = floor number
    // value = number of rooms
}