package com.dormispace.backend.room.service;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.contract.dto.ContractResponse;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.model.ContractStatus;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.room.dto.ContractDraftResponse;
import com.dormispace.backend.room.dto.RoomWithContractStatusResponse;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.room.model.RoomStatus;
import com.dormispace.backend.room.repository.RoomRepository;
import com.dormispace.backend.user.model.Role;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RoomService {

    private final RoomRepository roomRepository;
    private final ContractRepository contractRepository;

    // =========================================
    // PUBLIC METHODS
    // =========================================

    public List<RoomWithContractStatusResponse> getRoomsWithContractStatus(Long userId) {

        List<Room> rooms =
                roomRepository.findByApartment_Landlord_User_IdOrderByRoomNumberAsc(userId);

        return rooms.stream()
                .map(this::mapToRoomWithContractStatus)
                .toList();
    }

    public Room getRoomById(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Room not found: " + id));
    }

    public ContractResponse getCurrentContractResponse(Long roomId, AuthenticatedUser user) {

        Room room = getRoomById(roomId);

        Contract contract = findLatestContract(
                room,
                List.of(
                        ContractStatus.PENDING_TENANT,
                        ContractStatus.PENDING_LANDLORD,
                        ContractStatus.ACTIVE
                )
        ).orElseThrow(() -> new RuntimeException("No active contract"));

        validateAccessForCurrentContract(contract, user);

        return mapToContractResponse(contract);
    }

    public ContractDraftResponse getContractDraft(Long roomId, AuthenticatedUser user) {
        Room room = getRoomById(roomId);
        validateLandlordOwnership(room, user);
        ensureRoomNotOccupied(room);
        return buildDraft(room);
    }

    public Room getRoomByIdSecure(Long id, AuthenticatedUser user) {
        Room room = roomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        validateLandlordOwnership(room, user);

        return room;
    }

    // =========================================
    // PRIVATE HELPERS
    // =========================================

    private void validateAccessForCurrentContract(Contract contract, AuthenticatedUser user) {

        if (user.getRole() == Role.LANDLORD) {
            validateLandlordAccess(contract, user);
        }
        else if (user.getRole() == Role.TENANT) {
            validateTenantAccess(contract, user);
        }
        else {
            throw new AccessDeniedException("Access denied");
        }
    }

    private void validateLandlordAccess(Contract contract, AuthenticatedUser user) {

        Long ownerUserId =
                contract.getRoom()
                        .getApartment()
                        .getLandlord()
                        .getUser()
                        .getId();

        if (!ownerUserId.equals(user.getUserId())) {
            throw new AccessDeniedException("Not your room");
        }
    }

    private void validateTenantAccess(Contract contract, AuthenticatedUser user) {

        if (contract.getTenant() == null) {
            throw new AccessDeniedException("No tenant assigned");
        }

        Long tenantUserId =
                contract.getTenant()
                        .getId();

        if (!tenantUserId.equals(user.getUserId())) {
            throw new AccessDeniedException("Not your contract");
        }
    }

    private RoomWithContractStatusResponse mapToRoomWithContractStatus(Room room) {

        Contract contract = findLatestContract(
                room,
                List.of(
                        ContractStatus.PENDING_TENANT,
                        ContractStatus.PENDING_LANDLORD,
                        ContractStatus.ACTIVE
                )
        ).orElse(null);

        // Case 1: contract exists but tenant deleted
        if (contract != null && contract.getTenant() == null) {
            contract = null;
        }

        // 🔥 Case 2: contract missing but room still pending → FIX IT
        if (contract == null && room.getStatus() != RoomStatus.VACANT) {
            room.setStatus(RoomStatus.VACANT);
            roomRepository.save(room);
        }

        Long contractId = contract != null ? contract.getContractId() : null;

        String tenantEmail =
                contract != null && contract.getTenant() != null
                        ? contract.getTenant().getEmail()
                        : null;

        return new RoomWithContractStatusResponse(
                room.getRoomId(),
                room.getRoomNumber(),
                room.getStatus().toString(),
                contractId,
                room.getApartment().getApartmentId(),
                tenantEmail
        );
    }

    private ContractResponse mapToContractResponse(Contract contract) {

        ContractResponse dto = new ContractResponse();

        dto.setContractId(contract.getContractId());
        dto.setStatus(contract.getStatus());

        dto.setRoomId(contract.getRoom().getRoomId());          // add
        dto.setUserId(
                contract.getTenant() != null
                        ? contract.getTenant().getId()
                        : null
        );                                                      // add

        dto.setFirstName(contract.getFirstName());
        dto.setLastName(contract.getLastName());
        dto.setEmail(contract.getTenant() != null
                ? contract.getTenant().getEmail()
                : null);

        dto.setPhoneNumber(contract.getPhoneNumber());
        dto.setAddress(contract.getAddress());
        dto.setStartDate(contract.getStartDate());
        dto.setEndDate(contract.getEndDate());
        dto.setRoomNumber(contract.getRoom().getRoomNumber());
        dto.setApartmentName(contract.getRoom().getApartment().getName());
        dto.setRentalRate(contract.getRentalRate());
        dto.setDepositAmount(contract.getDepositAmount());
        dto.setContractType(contract.getContractType());
        dto.setApartmentId(contract.getRoom().getFloor().getApartment().getApartmentId());

        return dto;
    }

    private void validateLandlordOwnership(Room room, AuthenticatedUser user) {

        if (user.getRole() != Role.LANDLORD) {
            throw new AccessDeniedException("Only landlords can access this resource");
        }

        Long ownerUserId =
                room.getApartment()
                        .getLandlord()
                        .getUser()
                        .getId();

        if (!ownerUserId.equals(user.getUserId())) {
            throw new AccessDeniedException("Not your room");
        }
    }


    private void ensureRoomNotOccupied(Room room) {

        boolean hasActive =
                contractRepository.existsByRoomAndStatus(room, ContractStatus.ACTIVE);

        if (hasActive) {
            throw new RuntimeException("Room already occupied");
        }
    }

    private ContractDraftResponse buildDraft(Room room) {

        LocalDate start = LocalDate.now().plusDays(1);
        int duration = 6;

        return new ContractDraftResponse(
                room.getRoomId(),
                room.getRoomNumber(),
                room.getMonthlyRent(),
                room.getMonthlyRent(), // adjust if deposit separate
                duration,
                start,
                start.plusMonths(duration)
        );
    }

    private java.util.Optional<Contract> findLatestContract(
            Room room,
            List<ContractStatus> statuses
    ) {
        return contractRepository
                .findTopByRoomAndStatusInOrderByCreatedAtDesc(room, statuses);
    }
}