package com.dormispace.backend.contract.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class CreateContractRequest {

    private Long roomId;

    private BigDecimal rentalRate;
    private BigDecimal depositAmount;

    private String contractType; // 6_MONTH / YEARLY

    private LocalDate startDate;
    private LocalDate endDate;

    private String tenantEmail;
}