package com.dormispace.backend.contract.dto;

import com.dormispace.backend.contract.model.ContractStatus;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ContractResponse {

    private Long contractId;
    private Long roomId;
    private Long userId;          // ← added tenant's userId for MaintenancePage
    private String roomNumber;
    private Long apartmentId;
    private String apartmentName;

    private String firstName;
    private String lastName;
    private String address;
    private String phoneNumber;
    private String email;

    private BigDecimal rentalRate;
    private BigDecimal depositAmount;
    private String contractType;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;

    private ContractStatus status;

    private String signatureTenant;

    private String witness1FirstName;
    private String witness1LastName;
    private String signatureWitness1;

    private String witness2FirstName;
    private String witness2LastName;
    private String signatureWitness2;

    private String signatureLandlord;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime signedTenantAt;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime signedLandlordAt;

    // Only present when contract is ACTIVE
    private String finalPdfUrl;
}