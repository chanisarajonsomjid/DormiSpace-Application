package com.dormispace.backend.bill.service;

import com.dormispace.backend.bill.model.Electricity_Meter;
import com.dormispace.backend.bill.repository.ElectricityMeterRepository;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class ElectricityMeterService {

    private final ElectricityMeterRepository electricityMeterRepository;
    private final BillCalculationService     billCalculationService;

    // ─── Create ───────────────────────────────────────────────────────────────

    /**
     * Save a new electricity meter reading.
     *
     * FIX 1: assertReadyForMeterInput — blocks save if utility settings are
     *         incomplete or room has no active contract.
     * FIX 2: previousRead is always fetched from the last saved currentRead
     *         for this room, never trusted from the incoming payload.
     * FIX 3: readingSource and ocrConfidence are preserved from the payload
     *         (set by the OCR controller before calling this service).
     *
     * @param meter       the reading to save — currentRead, readingDate,
     *                    roomId, readingSource, ocrConfidence must be set.
     * @param apartmentId needed for the utility setting prerequisite check.
     */
    public Electricity_Meter createElectricityMeterReading(
            Electricity_Meter meter, Long apartmentId) {

        log.info("Creating electricity meter reading: roomId={} source={}",
                meter.getRoomId(), meter.getReadingSource());

        // FIX 1: prerequisite gate
        billCalculationService.assertReadyForMeterInput(
                apartmentId, meter.getRoomId());

        // FIX 2: enforce previousRead from DB, not from client
        enforceCorrectPreviousRead(meter);

        meter.calculateUsedUnits();

        // Guard: current must not be less than previous
        if (!meter.isValidReading()) {
            throw new BadRequestException(
                    "Current reading (" + meter.getCurrentRead()
                            + ") cannot be less than previous reading ("
                            + meter.getPreviousRead() + ").");
        }

        Electricity_Meter saved = electricityMeterRepository.save(meter);
        log.info("Created electricity meter: meterId={} units={}",
                saved.getMeterId(), saved.getUsedElecUnit());
        return saved;
    }

    // ─── Update ───────────────────────────────────────────────────────────────

    /**
     * Update an existing electricity meter reading.
     * When the landlord corrects an OCR result, readingSource should be
     * "CORRECTED" — the controller sets this before calling here.
     */
    public Electricity_Meter updateElectricityMeterReading(
            Long meterId, Electricity_Meter meter) {

        log.info("Updating electricity meter: meterId={}", meterId);

        return electricityMeterRepository.findById(meterId)
                .map(existing -> {
                    existing.setReadingDate(meter.getReadingDate());
                    existing.setCurrentRead(meter.getCurrentRead());
                    existing.setPreviousRead(meter.getPreviousRead());
                    existing.setCollectedElecImage(meter.getCollectedElecImage());

                    // Preserve audit fields if provided
                    if (meter.getReadingSource() != null) {
                        existing.setReadingSource(meter.getReadingSource());
                    }
                    if (meter.getOcrConfidence() != null) {
                        existing.setOcrConfidence(meter.getOcrConfidence());
                    }
                    if (meter.getOcrRawText() != null) {
                        existing.setOcrRawText(meter.getOcrRawText());
                    }

                    existing.calculateUsedUnits();

                    if (!existing.isValidReading()) {
                        throw new BadRequestException(
                                "Current reading cannot be less than previous reading.");
                    }

                    Electricity_Meter updated = electricityMeterRepository.save(existing);
                    log.info("Updated electricity meter: meterId={} units={}",
                            meterId, updated.getUsedElecUnit());
                    return updated;
                })
                .orElseThrow(() -> electricityMeterNotFound(meterId));
    }

    // ─── Read ─────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public Optional<Electricity_Meter> getElectricityMeterById(Long meterId) {
        return electricityMeterRepository.findById(meterId);
    }

    @Transactional(readOnly = true)
    public List<Electricity_Meter> getAllElectricityMeterReadings() {
        return electricityMeterRepository.findAll();
    }

    /**
     * FIX: uses repository query instead of findAll().stream().filter().
     * Add findByRoomId(Long roomId) to ElectricityMeterRepository.
     */
    @Transactional(readOnly = true)
    public Optional<Electricity_Meter> getLastReadingForRoom(Long roomId) {
        return electricityMeterRepository.findTopByRoomIdOrderByReadingDateDesc(roomId);
    }

    /**
     * FIX: uses repository query instead of findAll().stream().filter().
     * Add the JPQL query below to ElectricityMeterRepository:
     *
     *   @Query("SELECT COALESCE(SUM(m.usedElecUnit), 0) FROM Electricity_Meter m
     *           WHERE m.roomId = :roomId AND m.usedElecUnit IS NOT NULL")
     *   Integer sumUsedUnitsByRoomId(@Param("roomId") Long roomId);
     */
    @Transactional(readOnly = true)
    public Integer getTotalElectricityUsageForRoom(Long roomId) {
        return electricityMeterRepository.sumUsedUnitsByRoomId(roomId);
    }

    /**
     * FIX: uses repository query instead of findAll().stream().filter().
     * Add the JPQL query below to ElectricityMeterRepository:
     *
     *   @Query("SELECT AVG(m.usedElecUnit) FROM Electricity_Meter m
     *           WHERE m.roomId = :roomId AND m.usedElecUnit IS NOT NULL")
     *   Double avgUsedUnitsByRoomId(@Param("roomId") Long roomId);
     */
    @Transactional(readOnly = true)
    public Double getAverageMonthlyUsageForRoom(Long roomId) {
        Double avg = electricityMeterRepository.avgUsedUnitsByRoomId(roomId);
        return avg != null ? avg : 0.0;
    }

    /**
     * FIX: uses repository query instead of findAll().stream().filter().
     * Add the JPQL query below to ElectricityMeterRepository:
     *
     *   @Query("SELECT COALESCE(SUM(m.totalElectricityPrice), 0)
     *           FROM Electricity_Meter m
     *           WHERE m.roomId = :roomId
     *           AND m.totalElectricityPrice IS NOT NULL")
     *   BigDecimal sumTotalPriceByRoomId(@Param("roomId") Long roomId);
     */
    @Transactional(readOnly = true)
    public BigDecimal getTotalElectricityCostForRoom(Long roomId) {
        return electricityMeterRepository.sumTotalPriceByRoomId(roomId);
    }

    // ─── Validation helpers ───────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public boolean isValidReading(Long meterId) {
        return electricityMeterRepository.findById(meterId)
                .map(Electricity_Meter::isValidReading)
                .orElse(false);
    }

    @Transactional(readOnly = true)
    public boolean isHighUsage(Long meterId, int threshold) {
        return electricityMeterRepository.findById(meterId)
                .map(meter -> meter.isHighUsage(threshold))
                .orElse(false);
    }

    @Transactional(readOnly = true)
    public boolean detectUsageAnomaly(Long meterId, Integer previousMonthAverage) {
        return electricityMeterRepository.findById(meterId)
                .map(meter -> {
                    if (meter.getUsedElecUnit() == null
                            || previousMonthAverage == null) return false;
                    return meter.getUsedElecUnit() > (previousMonthAverage * 1.5);
                })
                .orElse(false);
    }

    // ─── Delete ───────────────────────────────────────────────────────────────

    public void deleteElectricityMeterReading(Long meterId) {
        log.info("Deleting electricity meter: meterId={}", meterId);
        electricityMeterRepository.deleteById(meterId);
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    /**
     * FIX: previousRead enforcement.
     *
     * The client sends previousRead from the UI field, but this can be
     * wrong if the landlord edited it or if there's a stale value cached
     * in Flutter. The authoritative previousRead is always the last saved
     * currentRead for this room in the database.
     *
     * If no prior reading exists (first ever reading for the room),
     * we keep whatever the landlord entered — it's the initial meter value.
     */
    private void enforceCorrectPreviousRead(Electricity_Meter meter) {
        electricityMeterRepository
                .findTopByRoomIdOrderByReadingDateDesc(meter.getRoomId())
                .ifPresent(last -> {
                    if (last.getCurrentRead() != null
                            && !last.getCurrentRead().equals(meter.getPreviousRead())) {
                        log.warn(
                                "previousRead mismatch for roomId={}: client sent {}, "
                                        + "overriding with last currentRead {}",
                                meter.getRoomId(),
                                meter.getPreviousRead(),
                                last.getCurrentRead());
                        meter.setPreviousRead(last.getCurrentRead());
                    }
                });
    }

    private ResourceNotFoundException electricityMeterNotFound(Long meterId) {
        log.error("Electricity meter not found: meterId={}", meterId);
        return new ResourceNotFoundException(
                "Electricity meter not found with ID: " + meterId);
    }
}