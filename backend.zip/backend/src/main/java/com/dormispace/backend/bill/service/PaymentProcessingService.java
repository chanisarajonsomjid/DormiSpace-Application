package com.dormispace.backend.bill.service;

import com.dormispace.backend.bill.dto.PromptPayResponse;
import com.dormispace.backend.bill.gateway.PaymentGateway;
import com.dormispace.backend.bill.model.*;
import com.dormispace.backend.bill.repository.BillPaymentRepository;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service for processing payments and generating receipts
 */
@Service
@RequiredArgsConstructor
@Transactional
@Slf4j

public class PaymentProcessingService {

    private final BillPaymentRepository billPaymentRepository;
    private final PaymentGateway paymentGateway;
    private final UtilitySettingService utilitySettingService;

    public PromptPayResponse createPromptPay(Long billId) {

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        if (bill.isPaid()) {
            throw new BadRequestException("Bill already paid");
        }

        PromptPayResponse response =
                paymentGateway.createPromptPay(bill);

        bill.setOmiseSourceId(response.getSourceId());
        bill.setOmiseChargeId(response.getChargeId());
        bill.setPaymentStatus(PaymentStatus.PENDING);
        bill.setPaymentMethod(PaymentMethod.PROMPTPAY_QR);
        bill.setOmiseStatus("pending");

        billPaymentRepository.save(bill);

        return response;
    }

    /**
     * Process payment for a bill
     */
    public Bill_Payment processPayment(Long billId, PaymentMethod paymentMethod, LocalDate paymentDate) {
        log.info("Processing payment for bill: {} method: {} date: {}", billId, paymentMethod, paymentDate);

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        // Validate payment
        if (bill.isPaid()) {
            log.error("Cannot process payment: billId={} already paid", billId);
            throw new BadRequestException("Bill is already paid");
        }

        // Mark as paid
        bill.markAsPaid(paymentDate, paymentMethod);
        
        Bill_Payment savedBill = billPaymentRepository.save(bill);
        
        log.info("Payment processed successfully for bill: {}", billId);
        
        return savedBill;
    }

    /**
     * Process payment with automatic late fee calculation
     */
    public Bill_Payment processPaymentWithLateFee(Long billId,
                                                  PaymentMethod paymentMethod,
                                                  LocalDate paymentDate) {

        log.info("Processing payment with late fee for bill: {}", billId);

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        // Prevent double payment
        if (bill.isPaid()) {
            throw new BadRequestException("Bill is already paid");
        }

        LocalDate dueDate = bill.getDueDate();

        // Null safety for dueDate
        if (dueDate == null) {
            throw new BadRequestException("Due date is not set for this bill");
        }

        // Apply late fee if late
        if (paymentDate.isAfter(dueDate)) {

            long daysLate = ChronoUnit.DAYS.between(dueDate, paymentDate);

            BigDecimal lateFee = calculateLateFee(bill.getApartmentId(), daysLate);

            if (lateFee.compareTo(BigDecimal.ZERO) > 0) {
                bill.setLateFee(lateFee);
                bill.calculateTotalAmount();

                log.info("Late fee applied: {} ({} days late)", lateFee, daysLate);
            }
        }

        // Mark as paid AFTER fee calculation
        bill.markAsPaid(paymentDate, paymentMethod);

        Bill_Payment saved = billPaymentRepository.save(bill);

        log.info("Payment completed for bill: {} total={}", billId, saved.getTotalAmount());

        return saved;
    }

    /**
     * Calculate late fee based on apartment's late fee configuration
     * Late fee is calculated as: price per day × number of days late
     */
    public BigDecimal calculateLateFee(Long apartmentId, long daysLate) {

        if (daysLate <= 0) {
            return BigDecimal.ZERO;
        }

        UtilitySetting setting = utilitySettingService.getByApartment(apartmentId);

        BigDecimal rate = setting.getLateFeePerDay();
        if (rate == null) {
            return BigDecimal.ZERO;
        }

        BigDecimal lateFee = rate.multiply(BigDecimal.valueOf(daysLate));

        // Apply cap safely
        if (setting.getMaxLateFee() != null &&
                setting.getMaxLateFee().compareTo(BigDecimal.ZERO) > 0) {

            lateFee = lateFee.min(setting.getMaxLateFee());
        }

        // Normalize currency scale
        lateFee = lateFee.setScale(2, RoundingMode.HALF_UP);

        log.info("Late fee calculated: {} THB/day × {} days = {} THB",
                rate, daysLate, lateFee);

        return lateFee;
    }

    /**
     * Generate receipt for a paid bill
     */
    public Map<String, Object> generateReceipt(Long billId) {
        log.info("Generating receipt for bill: {}", billId);

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        if (!bill.isPaid()) {
            log.error("Cannot generate receipt for unpaid billId={}", billId);
            throw new BadRequestException("Cannot generate receipt for unpaid bill");
        }

        Map<String, Object> receipt = new HashMap<>();
        
        // Receipt header
        receipt.put("receiptNumber", generateReceiptNumber(bill));
        receipt.put("billId", bill.getBillId());
        receipt.put("issueDate", bill.getReceiptDate());
        
        // Payer information
        receipt.put("userId", bill.getUserId());
        receipt.put("roomId", bill.getRoomId());
        receipt.put("apartmentId", bill.getApartmentId());
        
        // Payment details
        receipt.put("paymentDate", bill.getPaymentDate());
        receipt.put("paymentMethod", bill.getPaymentMethod());
        
        // Amounts
        receipt.put("subtotal", bill.getSubtotal());
        receipt.put("lateFee", bill.getLateFee());
        receipt.put("totalAmount", bill.getTotalAmount());
        
        // Billing period
        receipt.put("billingPeriod", bill.getCreatedDate());
        
        log.info("Receipt generated successfully for bill: {}", billId);
        
        return receipt;
    }

    /**
     * Generate receipt number
     */
    private String generateReceiptNumber(Bill_Payment bill) {
        // Format: RCP-YYYYMMDD-BILLID
        String date = bill.getReceiptDate() != null 
                ? bill.getReceiptDate().toString().replace("-", "")
                : LocalDate.now().toString().replace("-", "");
        
        return String.format("RCP-%s-%06d", date, bill.getBillId());
    }

    /**
     * Cancel payment (for corrections/refunds)
     */
    public Bill_Payment cancelPayment(Long billId, String reason) {
        log.info("Cancelling payment for bill: {} reason: {}", billId, reason);

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        if (!bill.isPaid()) {
            log.error("Cannot cancel payment for unpaid billId={}", billId);
            throw new BadRequestException("Cannot cancel payment for unpaid bill");
        }

        // Reset payment information
        bill.setPaymentStatus(PaymentStatus.UNPAID);
        bill.setPaymentDate(null);
        bill.setPaymentMethod(null);
        bill.setReceiptDate(null);

        Bill_Payment savedBill = billPaymentRepository.save(bill);
        
        log.info("Payment cancelled for bill: {}", billId);
        
        return savedBill;
    }

    /**
     * Apply manual late fee
     */
    public Bill_Payment applyLateFee(Long billId, BigDecimal lateFeeAmount) {
        log.info("Applying manual late fee to bill: {} amount: {}", billId, lateFeeAmount);

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        bill.setLateFee(lateFeeAmount);
        bill.calculateTotalAmount();
        
        Bill_Payment savedBill = billPaymentRepository.save(bill);
        
        log.info("Late fee applied successfully to bill: {}", billId);
        
        return savedBill;
    }

    public Bill_Payment applyAutomaticLateFee(Long billId) {

        log.info("Applying automatic late fee for bill: {}", billId);

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        if (bill.isPaid()) {
            return bill; // no need to update
        }

        LocalDate today = LocalDate.now();
        LocalDate dueDate = bill.getDueDate();

        if (today.isAfter(dueDate)) {
            long daysLate = ChronoUnit.DAYS.between(dueDate, today);

            BigDecimal lateFee = calculateLateFee(bill.getApartmentId(), daysLate);

            if (lateFee.compareTo(BigDecimal.ZERO) > 0) {
                bill.setLateFee(lateFee);
                bill.setPaymentStatus(PaymentStatus.OVERDUE);
                bill.calculateTotalAmount();
            }
        }

        return billPaymentRepository.save(bill);
    }

    /**
     * Get payment statistics for a period
     */
    public Map<String, Object> getPaymentStatistics(Long apartmentId, LocalDate startDate, LocalDate endDate) {
        log.info("Getting payment statistics for apartment: {} period: {} to {}", 
                apartmentId, startDate, endDate);

        var bills = billPaymentRepository.findAll().stream()
                .filter(bill -> bill.getApartmentId().equals(apartmentId))
                .filter(bill -> {
                    LocalDate paymentDate = bill.getPaymentDate();
                    return paymentDate != null && 
                           !paymentDate.isBefore(startDate) && 
                           !paymentDate.isAfter(endDate);
                })
                .toList();

        Map<String, Object> stats = new HashMap<>();
        
        stats.put("totalPayments", bills.size());
        
        BigDecimal totalAmount = bills.stream()
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        stats.put("totalAmount", totalAmount);
        
        // Group by payment method
        Map<String, Long> paymentMethods = bills.stream()
                .collect(Collectors.groupingBy(
                        bill -> bill.getPaymentMethod() != null
                                ? bill.getPaymentMethod().name()
                                : "UNKNOWN",
                        Collectors.counting()
                ));

        stats.put("paymentMethods", paymentMethods);
        
        // Average payment amount
        if (!bills.isEmpty()) {
            stats.put("averagePayment", totalAmount.divide(
                new BigDecimal(bills.size()), 2, java.math.RoundingMode.HALF_UP));
        } else {
            stats.put("averagePayment", BigDecimal.ZERO);
        }

        return stats;
    }

    private ResourceNotFoundException billNotFound(Long billId) {
        log.error("Bill not found billId={}", billId);
        return new ResourceNotFoundException("Bill not found with ID: " + billId);
    }
}
