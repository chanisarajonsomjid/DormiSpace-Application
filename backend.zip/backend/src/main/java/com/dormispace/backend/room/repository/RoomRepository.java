package com.dormispace.backend.room.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.room.model.RoomStatus;

public interface RoomRepository extends JpaRepository<Room, Long> {

    @Query("SELECT r FROM Room r WHERE r.apartment.apartmentId = :apartmentId")
    List<Room> findByApartmentId(@Param("apartmentId") Long apartmentId);

    // Renamed: _LandlordId → _Landlord_User_Id to reflect what's actually passed
    List<Room> findByApartment_Landlord_User_IdOrderByRoomNumberAsc(Long userId);

    List<Room> findByApartment_ApartmentIdAndStatus(Long apartmentId, RoomStatus status);
}