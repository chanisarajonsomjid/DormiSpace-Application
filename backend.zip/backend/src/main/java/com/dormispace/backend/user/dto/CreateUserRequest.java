package com.dormispace.backend.user.dto;

public class CreateUserRequest {
}
