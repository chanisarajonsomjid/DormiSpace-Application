package com.dormispace.backend.auth.service;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.user.dto.RegisterLandlordRequest;

public interface AuthService {
    AuthenticatedUser authenticate(String firebaseToken);

    AuthenticatedUser registerLandlord(String firebaseToken, RegisterLandlordRequest request);
}
