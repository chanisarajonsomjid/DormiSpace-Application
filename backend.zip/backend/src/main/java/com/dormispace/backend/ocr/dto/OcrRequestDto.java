package com.dormispace.backend.ocr.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OcrRequestDto {

    // FIX: Long to match all entity ID types (was Integer — silent truncation risk)
    private Long    roomId;

    private String  meterType;        // "electricity" or "water"
    private Integer previousReading;  // optional — used for sanity check

    /**
     * Where the image came from. Passed through to the result DTO and
     * eventually saved on the meter record as readingSource.
     * Values: "CAMERA", "GALLERY" — null if not supplied.
     */
    private String  readingSource;
}