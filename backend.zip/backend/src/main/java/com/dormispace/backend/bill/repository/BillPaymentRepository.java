package com.dormispace.backend.bill.repository;

import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.model.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface BillPaymentRepository extends JpaRepository<Bill_Payment, Long> {

    Optional<Bill_Payment> findByOmiseChargeId(String omiseChargeId);

    // Duplicate bill check — uses createdAt (LocalDateTime) since we removed
    // the redundant createdDate field from Bill_Payment
    boolean existsByRoomIdAndCreatedAtBetween(
            Long roomId, LocalDateTime start, LocalDateTime end);

    List<Bill_Payment> findByApartmentId(Long apartmentId);

    List<Bill_Payment> findByUserId(Long userId);

    // Used by markOverdueBills() to find all UNPAID bills efficiently
    List<Bill_Payment> findByPaymentStatus(PaymentStatus paymentStatus);

    // Replaces findAll().stream().filter() in getTotalOutstandingAmount
    @Query("SELECT COALESCE(SUM(b.totalAmount), 0) FROM Bill_Payment b " +
            "WHERE b.userId = :userId AND b.paymentStatus != 'PAID'")
    BigDecimal sumOutstandingByUserId(@Param("userId") Long userId);

    boolean existsByRoomIdAndCreatedDateBetween(
            Long roomId,
            LocalDate start,
            LocalDate end
    );
}