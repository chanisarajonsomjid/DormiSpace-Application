package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.model.PaymentMethod;
import com.dormispace.backend.bill.model.PaymentStatus;
import com.dormispace.backend.bill.repository.BillPaymentRepository;
import com.dormispace.backend.bill.service.PaymentProcessingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/webhook")
@RequiredArgsConstructor
@Slf4j
public class OmiseWebhookController {

    private final BillPaymentRepository billPaymentRepository;
    private final PaymentProcessingService paymentProcessingService;

    @PostMapping("/omise")
    public ResponseEntity<Void> handleOmiseWebhook(
            @RequestBody Map<String, Object> payload) {

        log.info("Received Omise webhook");

        try {

            Object keyObj = payload.get("key");
            if (!(keyObj instanceof String eventType)) {
                return ResponseEntity.ok().build();
            }

            if (!"charge.complete".equals(eventType)) {
                return ResponseEntity.ok().build();
            }

            Object dataObj = payload.get("data");
            if (!(dataObj instanceof Map<?, ?> data)) {
                return ResponseEntity.ok().build();
            }

            String chargeId = (String) data.get("id");
            String status = (String) data.get("status");

            if (!"successful".equals(status)) {
                return ResponseEntity.ok().build();
            }

            var billOpt = billPaymentRepository
                    .findByOmiseChargeId(chargeId);

            if (billOpt.isEmpty()) {
                log.warn("No bill found for chargeId={}", chargeId);
                return ResponseEntity.ok().build();
            }

            Bill_Payment bill = billOpt.get();

            if (bill.isPaid()) {
                return ResponseEntity.ok().build();
            }

            paymentProcessingService.processPayment(
                    bill.getBillId(),
                    PaymentMethod.PROMPTPAY_QR,
                    LocalDate.now()
            );

            log.info("Bill marked PAID for chargeId={}", chargeId);

        } catch (Exception e) {
            log.error("Webhook processing failed", e);
        }

        return ResponseEntity.ok().build();
    }
}