package com.dormispace.backend.apartment.repository;

import com.dormispace.backend.apartment.model.Apartment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ApartmentRepository extends JpaRepository<Apartment, Long> {

    @Query("SELECT a FROM Apartment a WHERE a.landlord.user.id = :userId")
    List<Apartment> findByUserId(@Param("userId") Long userId);

    @Query("SELECT COUNT(a) FROM Apartment a WHERE a.landlord.user.id = :userId")
    long countByUserId(@Param("userId") Long userId);

}