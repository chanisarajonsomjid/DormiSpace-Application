## 📁 **โครงสร้างไฟล์:**
```
backend/bill/controller/
├── BillPaymentController.java (เดิม - CRUD บิล)
├── WaterMeterController.java (เดิม)
├── ElectricityMeterController.java (เดิม)
├── BillCalculationController.java () NEW
├── ReportController.java () NEW
├── PaymentController.java  NEW