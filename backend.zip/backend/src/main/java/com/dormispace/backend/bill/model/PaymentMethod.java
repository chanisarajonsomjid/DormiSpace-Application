package com.dormispace.backend.bill.model;

public enum PaymentMethod {
    CASH,           // Manual payment
    PROMPTPAY_QR,   // Omise PromptPay QR
    TRUEMONEY       // Omise TrueMoney Wallet
}