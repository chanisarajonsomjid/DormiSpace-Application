package com.dormispace.backend.bill.service;

import com.dormispace.backend.bill.dto.UtilitySettingRequest;
import com.dormispace.backend.bill.model.UtilitySetting;
import com.dormispace.backend.bill.repository.UtilitySettingRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class UtilitySettingService {

    private final UtilitySettingRepository utilitySettingRepository;

    /**
     * Get settings for an apartment, creating defaults on first visit.
     *
     * FIX (Warning 3): @Transactional prevents a race condition where two
     * simultaneous first-time requests both find no record and both try to
     * insert, crashing on the unique apartment_id constraint.
     * The DataIntegrityViolationException catch handles the rare case where
     * the race slips through (e.g. across two separate transactions) by
     * falling back to a fresh read.
     */
    @Transactional
    public UtilitySetting getByApartment(Long apartmentId) {
        return utilitySettingRepository.findByApartmentId(apartmentId)
                .orElseGet(() -> createDefault(apartmentId));
    }

    /**
     * Create or update settings from a validated request DTO.
     *
     * FIX (Bug 1):    billingDayOfMonth is now saved (was silently dropped before).
     * FIX (Warning 2): accepts UtilitySettingRequest DTO instead of raw entity.
     */
    @Transactional
    public UtilitySetting saveOrUpdate(Long apartmentId, UtilitySettingRequest request) {

        UtilitySetting setting = utilitySettingRepository
                .findByApartmentId(apartmentId)
                .orElse(new UtilitySetting());

        setting.setApartmentId(apartmentId);

        // Each field is only updated when the request includes it (non-null).
        // This allows the Flutter page to send scoped partial bodies —
        // e.g. saving only the bank section won't touch water/electric fields.

        // WATER
        if (request.waterRate()        != null) setting.setWaterRate(request.waterRate());
        if (request.waterMinimum()     != null) setting.setWaterMinimum(request.waterMinimum());
        if (request.useWaterMinimum()  != null) setting.setUseWaterMinimum(request.useWaterMinimum());

        // ELECTRIC
        if (request.electricRate()       != null) setting.setElectricRate(request.electricRate());
        if (request.electricMinimum()    != null) setting.setElectricMinimum(request.electricMinimum());
        if (request.useElectricMinimum() != null) setting.setUseElectricMinimum(request.useElectricMinimum());

        // COMMON AREA
        if (request.commonAreaFee() != null) setting.setCommonAreaFee(request.commonAreaFee());

        // LATE FEE
        if (request.lateFeePerDay() != null) setting.setLateFeePerDay(request.lateFeePerDay());
        if (request.maxLateFee()    != null) setting.setMaxLateFee(request.maxLateFee());

        // BILLING CYCLE
        if (request.billingDayOfMonth() != null) setting.setBillingDayOfMonth(request.billingDayOfMonth());

        // BANK
        if (request.bankAccountName()   != null) setting.setBankAccountName(request.bankAccountName());
        if (request.bankAccountNumber() != null) setting.setBankAccountNumber(request.bankAccountNumber());

        return utilitySettingRepository.save(setting);
    }

    /**
     * Default values used on first-time apartment setup.
     *
     * FIX (Warning 3): wrapped in try/catch so that if two threads race past
     * the findByApartmentId check simultaneously, the loser catches the
     * unique-constraint violation and retries the read instead of returning a 500.
     */
    private UtilitySetting createDefault(Long apartmentId) {
        try {
            UtilitySetting setting = new UtilitySetting();
            setting.setApartmentId(apartmentId);

            setting.setWaterRate(BigDecimal.ZERO);
            setting.setWaterMinimum(BigDecimal.ZERO);
            setting.setUseWaterMinimum(false);

            setting.setElectricRate(BigDecimal.ZERO);
            setting.setElectricMinimum(BigDecimal.ZERO);
            setting.setUseElectricMinimum(false);

            setting.setCommonAreaFee(BigDecimal.ZERO);
            setting.setLateFeePerDay(BigDecimal.ZERO);
            setting.setMaxLateFee(BigDecimal.ZERO);

            setting.setBillingDayOfMonth(1);

            setting.setBankAccountName("");
            setting.setBankAccountNumber("");

            return utilitySettingRepository.save(setting);

        } catch (DataIntegrityViolationException ex) {
            // Another thread created the record between our find and our insert.
            // Retry the read — it must exist now.
            return utilitySettingRepository.findByApartmentId(apartmentId)
                    .orElseThrow(() -> new IllegalStateException(
                            "Failed to find or create utility settings for apartment: "
                                    + apartmentId, ex));
        }
    }
}