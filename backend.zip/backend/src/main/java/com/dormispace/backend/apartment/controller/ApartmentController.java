package com.dormispace.backend.apartment.controller;

import com.dormispace.backend.apartment.dto.ApartmentResponse;
import com.dormispace.backend.apartment.dto.CreateApartmentRequest;
import com.dormispace.backend.apartment.repository.ApartmentRepository;
import com.dormispace.backend.apartment.service.ApartmentService;
import com.dormispace.backend.auth.dto.AuthenticatedUser;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import java.util.List;
@RestController
@RequestMapping("/api/apartments")
@RequiredArgsConstructor
public class ApartmentController {

    private final ApartmentService apartmentService;

    @PostMapping
    public ResponseEntity<ApartmentResponse> createApartment(
            @RequestBody CreateApartmentRequest request,
            @AuthenticationPrincipal AuthenticatedUser user
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(apartmentService.createApartment(request, user.getUserId()));
    }

    @GetMapping("/my")
    public List<ApartmentResponse> myApartments(@AuthenticationPrincipal AuthenticatedUser user) {
        return apartmentService.getMyApartments(user.getUserId());
    }
}