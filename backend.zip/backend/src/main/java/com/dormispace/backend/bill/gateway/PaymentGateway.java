package com.dormispace.backend.bill.gateway;

import com.dormispace.backend.bill.dto.PromptPayResponse;
import com.dormispace.backend.bill.model.Bill_Payment;

public interface PaymentGateway {

    PromptPayResponse createPromptPay(Bill_Payment bill);
    String getQrFromCharge(String chargeId);
}