package com.dormispace.backend.bill.dto;

import lombok.Data;

import java.util.List;
@Data

public class RoomReadinessItem {
    private Long roomId;
    private String roomNumber;
    private boolean hasActiveContract;
    private boolean waterReady;
    private boolean electricityReady;
    private List<String> missing;

    public RoomReadinessItem() {
    }

    public RoomReadinessItem(
            Long roomId,
            String roomNumber,
            boolean hasActiveContract,
            boolean waterReady,
            boolean electricityReady,
            List<String> missing
    ) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.hasActiveContract = hasActiveContract;
        this.waterReady = waterReady;
        this.electricityReady = electricityReady;
        this.missing = missing;
    }
}