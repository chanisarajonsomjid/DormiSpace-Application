package com.dormispace.backend.maintenance.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public record IssueResponse(
        Long id,
        String title,
        String description,
        String status,
        BigDecimal maintenanceExpense,
        LocalDate createdDate,
        Long roomId,
        String roomNumber,
        String tenantName
) {}
