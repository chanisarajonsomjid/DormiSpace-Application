package com.dormispace.backend.user.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.user.dto.LandlordResponse;
import com.dormispace.backend.user.model.Landlord;
import com.dormispace.backend.user.repository.LandlordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.dormispace.backend.user.dto.UpdateLandlordPhoneRequest;

@RestController
@RequestMapping("/api/landlords")
@RequiredArgsConstructor
public class LandlordController {

    private final LandlordRepository landlordRepository;

    @GetMapping("/me")
    public LandlordResponse me(Authentication authentication) {

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        Landlord landlord = landlordRepository.findByUser_Id(user.getUserId())
                .orElseThrow(() -> new RuntimeException(
                        "Landlord not found for userId=" + user.getUserId()));

        return LandlordResponse.builder()
                .landlordId(landlord.getLandlordId())
                .firstName(landlord.getFirstName())
                .lastName(landlord.getLastName())
                .email(landlord.getUser().getEmail())
                .phoneNumber(landlord.getPhoneNumber())
                .build();
    }

    @PutMapping("/me")
    public LandlordResponse updatePhone(
            Authentication authentication,
            @RequestBody UpdateLandlordPhoneRequest request
    ) {

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        Landlord landlord = landlordRepository.findByUser_Id(user.getUserId())
                .orElseThrow(() -> new RuntimeException(
                        "Landlord not found for userId=" + user.getUserId()));

        landlord.setPhoneNumber(request.getPhoneNumber());

        landlordRepository.save(landlord);

        return LandlordResponse.builder()
                .landlordId(landlord.getLandlordId())
                .firstName(landlord.getFirstName())
                .lastName(landlord.getLastName())
                .phoneNumber(landlord.getPhoneNumber())
                .build();
    }
}