package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.dto.UtilitySettingRequest;
import com.dormispace.backend.bill.model.UtilitySetting;
import com.dormispace.backend.bill.service.UtilitySettingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/settings")
@RequiredArgsConstructor
public class UtilitySettingController {

    private final UtilitySettingService utilitySettingService;

    @GetMapping("/apartment/{apartmentId}")
    public ResponseEntity<UtilitySetting> getSetting(@PathVariable Long apartmentId) {
        return ResponseEntity.ok(
                utilitySettingService.getByApartment(apartmentId)
        );
    }

    /**
     * FIX (Warning 1): @Valid activates the @Min/@Max constraints on the DTO.
     * FIX (Warning 2): accepts UtilitySettingRequest DTO instead of the raw
     *                  @Entity so clients cannot inject or overwrite `id`.
     */
    @PutMapping("/apartment/{apartmentId}")
    public ResponseEntity<UtilitySetting> updateSetting(
            @PathVariable Long apartmentId,
            @Valid @RequestBody UtilitySettingRequest request
    ) {
        return ResponseEntity.ok(
                utilitySettingService.saveOrUpdate(apartmentId, request)
        );
    }
}