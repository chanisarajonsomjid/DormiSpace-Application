package com.dormispace.backend.apartment.service;

import com.dormispace.backend.apartment.dto.ApartmentResponse;
import com.dormispace.backend.apartment.dto.CreateApartmentRequest;
import com.dormispace.backend.apartment.model.Apartment;
import com.dormispace.backend.apartment.model.Floor;
import com.dormispace.backend.apartment.repository.ApartmentRepository;
import com.dormispace.backend.room.factory.RoomFactory;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.user.model.Landlord;
import com.dormispace.backend.user.repository.LandlordRepository;
import com.dormispace.backend.user.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ApartmentService {

    private final ApartmentRepository apartmentRepository;
    private final LandlordRepository landlordRepository;

    @Transactional
    public ApartmentResponse createApartment(CreateApartmentRequest request, Long userId) {

        Landlord landlord = landlordRepository.findByUser_Id(userId)
                .orElseThrow(() -> new RuntimeException("Landlord profile not found"));

        long count = apartmentRepository.countByUserId(userId); // ← was landlord.getLandlordId()

        if (count >= 2) {
            throw new RuntimeException("Maximum 2 apartments allowed");
        }

        Apartment apartment = buildApartment(request, landlord);
        List<Floor> floors = buildFloors(request.getFloors(), apartment);

        apartment.setFloors(floors);
        apartment.setTotalRooms(calculateTotalRooms(floors));

        return mapToResponse(apartmentRepository.save(apartment));
    }

    // =========================================
    // PRIVATE HELPERS
    // =========================================

    private ApartmentResponse mapToResponse(Apartment apartment) {
        return ApartmentResponse.builder()
                .apartmentId(apartment.getApartmentId())
                .name(apartment.getName())
                .address(apartment.getAddress())
                .district(apartment.getDistrict())
                .province(apartment.getProvince())
                .postcode(apartment.getPostcode())
                .city(apartment.getCity())
                .phoneNum(apartment.getPhone_num())
                .totalRooms(apartment.getTotalRooms())
                .build();
    }

    private Apartment buildApartment(CreateApartmentRequest request, Landlord landlord) {

        Apartment apartment = new Apartment();

        apartment.setName(request.getName());
        apartment.setAddress(request.getAddress());
        apartment.setDistrict(request.getDistrict());
        apartment.setProvince(request.getProvince());
        apartment.setPostcode(request.getPostcode());
        apartment.setCity(request.getCity());
        apartment.setPhone_num(request.getPhone_Num());

        apartment.setLandlord(landlord);

        return apartment;
    }

    private List<Floor> buildFloors(Map<Integer, Integer> floorMap, Apartment apartment) {

        List<Floor> floorList = new ArrayList<>();

        floorMap.forEach((floorNumber, roomCount) -> {

            Floor floor = new Floor();
            floor.setFloorNumber(floorNumber);
            floor.setRoom_total(roomCount);
            floor.setApartment(apartment);

            List<Room> rooms = RoomFactory.generateRooms(floor, roomCount);
            floor.setRooms(rooms);

            floorList.add(floor);
        });

        return floorList;
    }

    private int calculateTotalRooms(List<Floor> floors) {
        return floors.stream()
                .mapToInt(Floor::getRoom_total)
                .sum();
    }

    public List<ApartmentResponse> getMyApartments(Long userId) {
        return apartmentRepository.findByUserId(userId)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }
}