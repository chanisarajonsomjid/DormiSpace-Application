package com.dormispace.backend.contract.service;

import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.user.model.User;
import com.dormispace.backend.user.repository.LandlordRepository;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

@Service
public class PdfService {

    private final LandlordRepository landlordRepository;

    public PdfService(LandlordRepository landlordRepository) {
        this.landlordRepository = landlordRepository;
    }

    public byte[] generateFinalContract(Contract contract) {

        User owner = contract.getRoom().getApartment().getLandlord().getUser();

        var landlord = landlordRepository.findByUser_Id(owner.getId())
                .orElseThrow(() -> new RuntimeException("Landlord not found"));

        String landlordName = landlord.getFirstName() + " " + landlord.getLastName();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        try (PdfWriter writer = new PdfWriter(baos);
             PdfDocument pdf = new PdfDocument(writer);
             Document document = new Document(pdf);
             InputStream fontStream = getClass().getResourceAsStream("/fonts/THSarabunNew.ttf")) {

            if (fontStream == null) {
                throw new RuntimeException("Font file not found");
            }

            byte[] fontBytes = fontStream.readAllBytes();

            PdfFont thaiFont = PdfFontFactory.createFont(
                    fontBytes,
                    PdfEncodings.IDENTITY_H,
                    PdfFontFactory.EmbeddingStrategy.FORCE_EMBEDDED
            );

            document.setFont(thaiFont);
            document.setFontSize(16);
            document.setMargins(50, 50, 50, 50);

            DateTimeFormatter formatter =
                    DateTimeFormatter.ofPattern("dd MMMM yyyy");

            // ===== TITLE =====
            document.add(new Paragraph("สัญญาเช่าห้องพัก")
                    .setBold()
                    .setFontSize(22)
                    .setTextAlignment(TextAlignment.CENTER));

            document.add(new Paragraph("\n"));

            // ===== HEADER =====
            Table headerTable = new Table(2).useAllAvailableWidth();

            headerTable.addCell(labelCell("ทำที่:"));
            headerTable.addCell(valueCell(contract.getRoom().getApartment().getName()));

            headerTable.addCell(labelCell("วันที่:"));
            headerTable.addCell(valueCell(contract.getStartDate().format(formatter)));

            document.add(headerTable);
            document.add(new Paragraph("\n"));


// ===== INTRO SECTION =====
            document.add(new Paragraph(
                    "สัญญาเช่าฉบับนี้ทำขึ้นระหว่าง "
                            + landlordName
                            + " ซึ่งต่อไปในสัญญานี้เรียกว่า “ผู้ให้เช่า” ฝ่ายหนึ่ง กับ "
                            + contract.getFirstName() + " "
                            + contract.getLastName()
                            + " ซึ่งต่อไปในสัญญานี้เรียกว่า “ผู้ให้เช่า” ฝ่ายหนึ่ง กับ "
                            + contract.getFirstName() + " "
                            + contract.getLastName()
                            + " ซึ่งต่อไปในสัญญานี้เรียกว่า “ผู้เช่า” อีกฝ่ายหนึ่ง"
            ));

            document.add(new Paragraph("\n"));


// ===== CLAUSE 1 =====
            document.add(new Paragraph(
                    "ข้อ 1. ผู้ให้เช่าตกลงให้เช่าและผู้เช่าตกลงเช่าห้องพักเลขที่ "
                            + contract.getRoom().getRoomNumber()
                            + " ชั้นที่ "
                            + contract.getRoom().getFloor().getFloorNumber()
                            + " เพื่อเป็นที่อยู่อาศัย ภายใต้ระเบียบที่ผู้ให้เช่ากำหนด"
            ));
// ===== CLAUSE 2 =====
            BigDecimal rentBD = contract.getRentalRate();
            BigDecimal depositBD = contract.getDepositAmount();

            long rent = rentBD.longValue();
            long deposit = depositBD.longValue();

            document.add(new Paragraph(
                    "ข้อ 2. ผู้เช่าตกลงชำระค่าเช่าเป็นรายเดือน "
                            + "ในอัตราค่าเช่าเดือนละ "
                            + rent + " บาท ("
                            + thaiNumberToText(rent)
                            + ") และวางเงินประกันจำนวน "
                            + deposit + " บาท ("
                            + thaiNumberToText(deposit)
                            + ")"
            ));
// ===== CLAUSE 3 =====
            document.add(new Paragraph(
                    "ข้อ 3. ผู้เช่าตกลงชำระค่าเช่า ณ ที่ทำการของผู้ให้เช่าหรือตัวแทนภายในกำหนดเวลา"
            ));
// ===== CLAUSE 4 =====
            document.add(new Paragraph(
                    "ข้อ 4. ห้ามเช่าช่วง เว้นแต่ได้รับความยินยอมเป็นลายลักษณ์อักษรจากผู้ให้เช่า"
            ));
// ===== CLAUSE 5 =====
            document.add(new Paragraph(
                    "ข้อ 5. ค่าน้ำ ค่าไฟฟ้า และค่าใช้จ่ายอื่น ๆ ให้เป็นไปตามมิเตอร์หรืออัตราที่กำหนด"
            ));
// ===== CLAUSE 6 =====
            document.add(new Paragraph(
                    "ข้อ 6. ผู้เช่าต้องบำรุงรักษาทรัพย์สินที่เช่าให้อยู่ในสภาพดี หากเกิดความเสียหายต้องรับผิดชอบค่าใช้จ่าย"
            ));
// ===== CLAUSE 7 =====
            document.add(new Paragraph(
                    "ข้อ 7. ผู้เช่าต้องรักษาความสะอาด ไม่เก็บวัตถุอันตราย และยินยอมให้ผู้ให้เช่าเข้าตรวจสอบห้องได้"
            ));
// ===== CLAUSE 8 =====
            document.add(new Paragraph(
                    "ข้อ 8. ห้ามดัดแปลงหรือรื้อถอนทรัพย์สินที่เช่า เว้นแต่ได้รับอนุญาตเป็นหนังสือ"
            ));
// ===== CLAUSE 9 =====
            document.add(new Paragraph(
                    "ข้อ 9. หากผู้เช่าผิดสัญญา ผู้ให้เช่ามีสิทธิเข้าครอบครองทรัพย์สินทันที"
            ));
// ===== CLAUSE 10 =====
            document.add(new Paragraph(
                    "ข้อ 10. ผู้เช่าต้องแจ้งเลิกสัญญาล่วงหน้าไม่น้อยกว่า 30 วัน"
            ));

            document.add(new Paragraph("\n"));
// ===== CLAUSE 11 =====
            document.add(new Paragraph(
                    "ข้อ 11. ผู้เช่าได้ตรวจสอบทรัพย์สินแล้วเห็นว่าปกติดีทุกประการ"
            ));
// ===== CLAUSE 12 =====
            document.add(new Paragraph(
                    "ข้อ 12. ผู้เช่าได้มอบสำเนาบัตรประชาชนและเอกสารแสดงตนแก่ผู้ให้เช่าแล้ว"
            ));

            document.add(new Paragraph("\n\n"));


// ===== SIGNATURE SECTION =====
            document.add(new Paragraph(
                    "คู่สัญญาทั้งสองฝ่ายได้อ่านและเข้าใจข้อความแล้ว จึงลงลายมือชื่อไว้เป็นหลักฐาน"
            ));

            document.add(new Paragraph("\n"));

            Table signTable = new Table(2).useAllAvailableWidth();

// Tenant
            signTable.addCell(signatureBlock(
                    "ผู้เช่า",
                    contract.getFirstName() + " " + contract.getLastName(),
                    contract.getSignatureTenant()
            ));

// Landlord
            signTable.addCell(signatureBlock(
                    "ผู้ให้เช่า",
                    landlordName,
                    contract.getSignatureLandlord()
            ));

// Witness 1
            signTable.addCell(signatureBlock(
                    "พยาน",
                    contract.getWitness1FirstName() + " "
                            + contract.getWitness1LastName(),
                    contract.getSignatureWitness1()
            ));

// Witness 2
            signTable.addCell(signatureBlock(
                    "พยาน",
                    contract.getWitness2FirstName() + " "
                            + contract.getWitness2LastName(),
                    contract.getSignatureWitness2()
            ));

            document.add(signTable);

            document.add(new Paragraph("\n"));

            document.add(new Paragraph("รหัสตรวจสอบเอกสาร (SHA-256): "
                    + contract.getFinalPdfHash())
                    .setFontSize(10));

        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return baos.toByteArray();
    }

    // ===== Helper Methods =====

    private Cell labelCell(String text) {
        return new Cell()
                .add(new Paragraph(text).setBold())
                .setBorder(Border.NO_BORDER)
                .setPadding(5);
    }

    private Cell valueCell(String text) {
        return new Cell()
                .add(new Paragraph(text))
                .setBorder(Border.NO_BORDER)
                .setPadding(5);
    }

    private Cell rightAlignedCell(String text) {
        return new Cell()
                .add(new Paragraph(text))
                .setTextAlignment(TextAlignment.RIGHT)
                .setBorder(Border.NO_BORDER)
                .setPadding(5);
    }

    private Cell signatureBlock(String role, String name, String base64Signature) {

        Cell cell = new Cell().setBorder(Border.NO_BORDER);

        cell.add(new Paragraph(role)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER));

        cell.add(new Paragraph("\n"));

        if (base64Signature != null && !base64Signature.isBlank()) {
            try {
                byte[] imageBytes = Base64.getDecoder().decode(base64Signature);
                ImageData imageData = ImageDataFactory.create(imageBytes);
                Image image = new Image(imageData);
                image.scaleToFit(180, 70);
                image.setHorizontalAlignment(
                        com.itextpdf.layout.properties.HorizontalAlignment.CENTER
                );
                cell.add(image);
            } catch (Exception e) {
                cell.add(new Paragraph("(ลายมือชื่อไม่ถูกต้อง)"));
            }
        } else {
            cell.add(new Paragraph("(ยังไม่ได้ลงลายมือชื่อ)")
                    .setTextAlignment(TextAlignment.CENTER));
        }

        cell.add(new Paragraph("\n"));
        cell.add(new Paragraph(name)
                .setTextAlignment(TextAlignment.CENTER));

        return cell;
    }

    private String thaiNumberToText(long number) {

        if (number == 0) return "ศูนย์บาทถ้วน";

        String[] units = {"", "หนึ่ง", "สอง", "สาม", "สี่", "ห้า", "หก", "เจ็ด", "แปด", "เก้า"};
        String[] positions = {"", "สิบ", "ร้อย", "พัน", "หมื่น", "แสน", "ล้าน"};

        StringBuilder result = new StringBuilder();

        String numStr = Long.toString(number);
        int len = numStr.length();

        for (int i = 0; i < len; i++) {
            int digit = Character.getNumericValue(numStr.charAt(i));
            int position = len - i - 1;

            if (digit == 0) continue;

            if (position == 0 && digit == 1 && len > 1) {
                result.append("เอ็ด");
            } else if (position == 1 && digit == 2) {
                result.append("ยี่");
            } else if (position == 1 && digit == 1) {
                result.append("");
            } else {
                result.append(units[digit]);
            }

            result.append(positions[position]);
        }

        result.append("บาทถ้วน");

        return result.toString();
    }
}