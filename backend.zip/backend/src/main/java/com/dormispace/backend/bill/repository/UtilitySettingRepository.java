package com.dormispace.backend.bill.repository;

import com.dormispace.backend.bill.model.UtilitySetting;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UtilitySettingRepository extends JpaRepository<UtilitySetting, Long> {

    Optional<UtilitySetting> findByApartmentId(Long apartmentId);
}