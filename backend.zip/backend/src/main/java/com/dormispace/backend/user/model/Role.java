package com.dormispace.backend.user.model;

public enum Role {
    LANDLORD,
    TENANT
}
