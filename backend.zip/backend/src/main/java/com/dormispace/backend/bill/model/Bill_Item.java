package com.dormispace.backend.bill.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Entity
@Table(name = "Bill_Item")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bill_Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long billId;

    private String itemName;   // "Water", "Electricity", "Internet"
    private String itemType;   // WATER, ELECTRIC, FIXED, RENT

    private Integer usage;     // e.g. 30 units (nullable for fixed)
    private BigDecimal unitPrice;

    private BigDecimal totalAmount;
}
