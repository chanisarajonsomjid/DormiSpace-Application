package com.dormispace.backend.apartment.repository;

import com.dormispace.backend.apartment.model.Floor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FloorRepository extends JpaRepository<Floor, Long> {
}