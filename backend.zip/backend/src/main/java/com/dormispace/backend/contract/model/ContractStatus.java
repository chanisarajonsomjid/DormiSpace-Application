package com.dormispace.backend.contract.model;

public enum ContractStatus {
    DRAFT, // lanlord created, tenant not filled yet
    PENDING_TENANT,
    PENDING_LANDLORD,
    ACTIVE,
    CANCELLED,
    TERMINATED,
}