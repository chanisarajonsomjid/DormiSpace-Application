package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.model.Water_Meter;
import com.dormispace.backend.bill.service.WaterMeterService;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/water-meters")
@RequiredArgsConstructor
public class WaterMeterController {

    private final WaterMeterService waterMeterService;

    /**
     * Create a new water meter reading.
     *
     * apartmentId is required as a query param — the service uses it to
     * run the prerequisite gate (utility settings complete + active contract).
     *
     * Flutter sends: POST /api/v1/water-meters?apartmentId=1
     * Body: { roomId, recordedDate, currentRead, previousRead,
     *         readingSource, ocrConfidence, ocrRawText }
     */
    @PostMapping
    public ResponseEntity<Water_Meter> createWaterMeterReading(
            @RequestBody Water_Meter meter,
            @RequestParam Long apartmentId) {
        Water_Meter created =
                waterMeterService.createWaterMeterReading(meter, apartmentId);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<Water_Meter>> getAllWaterMeterReadings() {
        return ResponseEntity.ok(waterMeterService.getAllWaterMeterReadings());
    }

    @GetMapping("/{meterId}")
    public ResponseEntity<Water_Meter> getWaterMeterById(@PathVariable Long meterId) {
        Water_Meter meter = waterMeterService.getWaterMeterById(meterId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Water meter not found with ID: " + meterId));
        return ResponseEntity.ok(meter);
    }

    /**
     * Update an existing reading.
     * If the landlord corrected an OCR result, Flutter should set
     * readingSource = "CORRECTED" in the request body before calling this.
     */
    @PutMapping("/{meterId}")
    public ResponseEntity<Water_Meter> updateWaterMeterReading(
            @PathVariable Long meterId,
            @RequestBody Water_Meter meter) {
        Water_Meter updated =
                waterMeterService.updateWaterMeterReading(meterId, meter);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{meterId}")
    public ResponseEntity<Void> deleteWaterMeterReading(@PathVariable Long meterId) {
        waterMeterService.deleteWaterMeterReading(meterId);
        return ResponseEntity.noContent().build();
    }

    // ── Read helpers ──────────────────────────────────────────────────────────

    @GetMapping("/room/{roomId}/last-reading")
    public ResponseEntity<Water_Meter> getLastReadingForRoom(
            @PathVariable Long roomId) {
        Water_Meter meter = waterMeterService.getLastReadingForRoom(roomId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No water meter reading found for room: " + roomId));
        return ResponseEntity.ok(meter);
    }

    @GetMapping("/room/{roomId}/total-usage")
    public ResponseEntity<Integer> getTotalUsageForRoom(@PathVariable Long roomId) {
        return ResponseEntity.ok(
                waterMeterService.getTotalWaterUsageForRoom(roomId));
    }

    @GetMapping("/room/{roomId}/average-usage")
    public ResponseEntity<Double> getAverageUsageForRoom(@PathVariable Long roomId) {
        return ResponseEntity.ok(
                waterMeterService.getAverageMonthlyUsageForRoom(roomId));
    }

    @GetMapping("/{meterId}/validate")
    public ResponseEntity<Boolean> isValidReading(@PathVariable Long meterId) {
        return ResponseEntity.ok(waterMeterService.isValidReading(meterId));
    }
}