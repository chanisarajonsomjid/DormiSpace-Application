package com.dormispace.backend.bill.model;

public enum PaymentStatus {
    UNPAID,      // Bill created, not paid yet
    PENDING,     // Payment initiated (QR generated, waiting confirmation)
    PAID,        // Successfully paid
    FAILED,      // Payment failed
    OVERDUE      // Past due date and not paid
}