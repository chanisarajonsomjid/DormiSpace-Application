package com.dormispace.backend.bill.controller;

import com.dormispace.backend.bill.model.Electricity_Meter;
import com.dormispace.backend.bill.service.ElectricityMeterService;
import com.dormispace.backend.common.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/electricity-meters")
@RequiredArgsConstructor
public class ElectricityMeterController {

    private final ElectricityMeterService electricityMeterService;

    /**
     * Create a new electricity meter reading.
     *
     * apartmentId is required as a query param — the service uses it to
     * run the prerequisite gate (utility settings complete + active contract).
     *
     * Flutter sends: POST /api/v1/electricity-meters?apartmentId=1
     * Body: { roomId, readingDate, currentRead, previousRead,
     *         readingSource, ocrConfidence, ocrRawText }
     */
    @PostMapping
    public ResponseEntity<Electricity_Meter> createElectricityMeterReading(
            @RequestBody Electricity_Meter meter,
            @RequestParam Long apartmentId) {
        Electricity_Meter created =
                electricityMeterService.createElectricityMeterReading(meter, apartmentId);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<Electricity_Meter>> getAllElectricityMeterReadings() {
        return ResponseEntity.ok(
                electricityMeterService.getAllElectricityMeterReadings());
    }

    @GetMapping("/{meterId}")
    public ResponseEntity<Electricity_Meter> getElectricityMeterById(
            @PathVariable Long meterId) {
        Electricity_Meter meter = electricityMeterService
                .getElectricityMeterById(meterId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Electricity meter not found with ID: " + meterId));
        return ResponseEntity.ok(meter);
    }

    /**
     * Update an existing reading.
     * If the landlord corrected an OCR result, Flutter should set
     * readingSource = "CORRECTED" in the request body before calling this.
     */
    @PutMapping("/{meterId}")
    public ResponseEntity<Electricity_Meter> updateElectricityMeterReading(
            @PathVariable Long meterId,
            @RequestBody Electricity_Meter meter) {
        Electricity_Meter updated =
                electricityMeterService.updateElectricityMeterReading(meterId, meter);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{meterId}")
    public ResponseEntity<Void> deleteElectricityMeterReading(
            @PathVariable Long meterId) {
        electricityMeterService.deleteElectricityMeterReading(meterId);
        return ResponseEntity.noContent().build();
    }

    // ── Read helpers ──────────────────────────────────────────────────────────

    @GetMapping("/room/{roomId}/last-reading")
    public ResponseEntity<Electricity_Meter> getLastReadingForRoom(
            @PathVariable Long roomId) {
        Electricity_Meter meter = electricityMeterService
                .getLastReadingForRoom(roomId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No electricity meter reading found for room: " + roomId));
        return ResponseEntity.ok(meter);
    }

    @GetMapping("/room/{roomId}/total-usage")
    public ResponseEntity<Integer> getTotalUsageForRoom(@PathVariable Long roomId) {
        return ResponseEntity.ok(
                electricityMeterService.getTotalElectricityUsageForRoom(roomId));
    }

    @GetMapping("/room/{roomId}/average-usage")
    public ResponseEntity<Double> getAverageUsageForRoom(@PathVariable Long roomId) {
        return ResponseEntity.ok(
                electricityMeterService.getAverageMonthlyUsageForRoom(roomId));
    }

    @GetMapping("/room/{roomId}/total-cost")
    public ResponseEntity<java.math.BigDecimal> getTotalCostForRoom(
            @PathVariable Long roomId) {
        return ResponseEntity.ok(
                electricityMeterService.getTotalElectricityCostForRoom(roomId));
    }

    @GetMapping("/{meterId}/validate")
    public ResponseEntity<Boolean> isValidReading(@PathVariable Long meterId) {
        return ResponseEntity.ok(electricityMeterService.isValidReading(meterId));
    }

    @GetMapping("/{meterId}/is-high-usage")
    public ResponseEntity<Boolean> isHighUsage(
            @PathVariable Long meterId,
            @RequestParam(defaultValue = "500") int threshold) {
        return ResponseEntity.ok(
                electricityMeterService.isHighUsage(meterId, threshold));
    }

    @GetMapping("/{meterId}/detect-anomaly")
    public ResponseEntity<Boolean> detectUsageAnomaly(
            @PathVariable Long meterId,
            @RequestParam(defaultValue = "400") Integer previousMonthAverage) {
        return ResponseEntity.ok(
                electricityMeterService.detectUsageAnomaly(meterId, previousMonthAverage));
    }
}