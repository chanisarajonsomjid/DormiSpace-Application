package com.dormispace.backend.bill.gateway;

import com.dormispace.backend.bill.dto.PromptPayResponse;
import com.dormispace.backend.bill.model.Bill_Payment;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class OmiseGateway implements PaymentGateway {

    @Value("${omise.secret-key}")
    private String secretKey;

    @Override
    public PromptPayResponse createPromptPay(Bill_Payment bill) {

        RestTemplate restTemplate = new RestTemplate();

        BigDecimal amount = bill.getTotalAmount();
        if (amount == null) {
            amount = bill.getSubtotal();
        }
        if (amount == null) {
            throw new IllegalStateException("Bill amount is null");
        }

        int amountInSatang = amount.multiply(BigDecimal.valueOf(100)).intValue();

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(secretKey, "");
        headers.setContentType(MediaType.APPLICATION_JSON);

        log.info("OMISE KEY loaded? {}", secretKey != null);

        // ── Create Source ──────────────────────────────────────────────────────
        Map<String, Object> sourceBody = new HashMap<>();
        sourceBody.put("type", "promptpay");
        sourceBody.put("amount", amountInSatang);
        sourceBody.put("currency", "thb");

        HttpEntity<Map<String, Object>> sourceRequest =
                new HttpEntity<>(sourceBody, headers);

        ResponseEntity<Map> sourceResponse = restTemplate.postForEntity(
                "https://api.omise.co/sources",
                sourceRequest,
                Map.class
        );

        Map<String, Object> sourceData = sourceResponse.getBody();
        if (sourceData == null || !sourceData.containsKey("id")) {
            throw new RuntimeException("Invalid source response from Omise");
        }
        String sourceId = (String) sourceData.get("id");

        // ── Create Charge ──────────────────────────────────────────────────────
        Map<String, Object> chargeBody = new HashMap<>();
        chargeBody.put("amount", amountInSatang);
        chargeBody.put("currency", "thb");
        chargeBody.put("source", sourceId);

        HttpEntity<Map<String, Object>> chargeRequest =
                new HttpEntity<>(chargeBody, headers);

        ResponseEntity<Map> chargeResponse = restTemplate.postForEntity(
                "https://api.omise.co/charges",
                chargeRequest,
                Map.class
        );

        Map<String, Object> chargeData = chargeResponse.getBody();
        if (chargeData == null) {
            throw new RuntimeException("Invalid charge response from Omise");
        }

        String chargeId = (String) chargeData.get("id");

        // ── Extract QR image URL ───────────────────────────────────────────────
        String qrImageUrl = null;

        try {
            Map<String, Object> source =
                    (Map<String, Object>) chargeData.get("source");

            if (source != null) {
                Map<String, Object> scannableCode =
                        (Map<String, Object>) source.get("scannable_code");

                if (scannableCode != null) {
                    Map<String, Object> imageObject =
                            (Map<String, Object>) scannableCode.get("image");

                    if (imageObject != null) {
                        qrImageUrl = (String) imageObject.get("download_uri");
                        log.info("QR image URL from Omise: {}", qrImageUrl);
                    }
                }
            }
        } catch (Exception e) {
            log.warn("Could not extract QR image from charge response: {}", e.getMessage());
        }

        // ── Fallback: fetch QR document directly from Omise ───────────────────
        if (qrImageUrl == null || qrImageUrl.isBlank()) {
            log.info("download_uri was null — fetching QR document for charge: {}", chargeId);
            try {
                ResponseEntity<Map> docResponse = restTemplate.exchange(
                        "https://api.omise.co/charges/" + chargeId + "/documents",
                        org.springframework.http.HttpMethod.GET,
                        new HttpEntity<>(headers),
                        Map.class
                );

                Map<String, Object> docBody = docResponse.getBody();
                if (docBody != null) {
                    java.util.List<Map<String, Object>> data =
                            (java.util.List<Map<String, Object>>) docBody.get("data");

                    if (data != null && !data.isEmpty()) {
                        // First document is the QR code
                        qrImageUrl = (String) data.get(0).get("download_uri");
                        log.info("QR image URL from documents: {}", qrImageUrl);
                    }
                }
            } catch (Exception e) {
                log.warn("Could not fetch QR document: {}", e.getMessage());
            }
        }

        // ── Fallback 2: re-fetch full charge and try "uri" field ─────────────
        if (qrImageUrl == null || qrImageUrl.isBlank()) {
            log.info("Trying getQrFromCharge for: {}", chargeId);
            qrImageUrl = getQrFromCharge(chargeId);
            log.info("QR URL from getQrFromCharge: {}", qrImageUrl);
        }

        // ── Final fallback: construct URL directly ────────────────────────────
        if (qrImageUrl == null || qrImageUrl.isBlank()) {
            log.warn("All QR URL methods failed — using constructed URL for charge: {}", chargeId);
            qrImageUrl = "https://api.omise.co/charges/" + chargeId + "/documents/qrcode";
        }


        log.info("Final QR URL: {}", qrImageUrl);

        return PromptPayResponse.builder()
                .qrImageUrl(qrImageUrl)
                .sourceId(sourceId)
                .chargeId(chargeId)
                .build();
    }

    // 🔥 helper method (clean + safe)
    private void sleep() {
        try {
            Thread.sleep(800);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("Sleep interrupted", e);
        }
    }

    public String getQrFromCharge(String chargeId) {

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(secretKey, "");

        ResponseEntity<Map> response = restTemplate.exchange(
                "https://api.omise.co/charges/" + chargeId,
                HttpMethod.GET,
                new HttpEntity<>(headers),
                Map.class
        );

        Map<String, Object> fullCharge = response.getBody();
        if (fullCharge == null) return null;

        Map<String, Object> source =
                (Map<String, Object>) fullCharge.get("source");

        if (source == null) return null;

        Map<String, Object> scannableCode =
                (Map<String, Object>) source.get("scannable_code");

        if (scannableCode == null) return null;

        Map<String, Object> image =
                (Map<String, Object>) scannableCode.get("image");

        if (image == null) return null;

        return (String) image.get("uri");
    }
}