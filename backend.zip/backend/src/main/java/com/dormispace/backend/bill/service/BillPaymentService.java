package com.dormispace.backend.bill.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.dormispace.backend.bill.gateway.PaymentGateway;
import com.dormispace.backend.bill.model.PaymentMethod;
import com.dormispace.backend.bill.model.PaymentStatus;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.repository.ContractRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.repository.BillPaymentRepository;
import com.dormispace.backend.common.exception.BadRequestException;
import com.dormispace.backend.common.exception.ResourceNotFoundException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class BillPaymentService {

    private final BillPaymentRepository billPaymentRepository;
    private final PaymentGateway        paymentGateway;
    private final ContractRepository    contractRepository;

    // ─── Create ───────────────────────────────────────────────────────────────

    public Bill_Payment createBillPayment(Bill_Payment billPayment) {
        log.info("Creating bill payment: userId={} roomId={}",
                billPayment.getUserId(), billPayment.getRoomId());

        if (billPayment.getPaymentStatus() == null) {
            billPayment.setPaymentStatus(PaymentStatus.UNPAID);
        }

        billPayment.calculateTotalAmount();
        Bill_Payment saved = billPaymentRepository.save(billPayment);
        log.info("Created bill payment: billId={}", saved.getBillId());
        return saved;
    }

    // ─── Update ───────────────────────────────────────────────────────────────

    public Bill_Payment updateBillPayment(Long billId, Bill_Payment billPayment) {
        log.info("Updating bill payment: billId={}", billId);

        return billPaymentRepository.findById(billId)
                .map(existing -> {
                    if (billPayment.getContract() != null) {
                        Long contractId = billPayment.getContract().getContractId();
                        Contract contract = contractRepository.findById(contractId)
                                .orElseThrow(() -> new ResourceNotFoundException(
                                        "Contract not found: " + contractId));
                        existing.setContract(contract);
                    }

                    existing.setApartmentId(billPayment.getApartmentId());
                    existing.setRoomId(billPayment.getRoomId());
                    existing.setUserId(billPayment.getUserId());
                    existing.setSubtotal(billPayment.getSubtotal());
                    existing.setLateFee(billPayment.getLateFee());
                    existing.setPaymentStatus(billPayment.getPaymentStatus());
                    existing.setPaymentMethod(billPayment.getPaymentMethod());
                    existing.calculateTotalAmount();

                    Bill_Payment updated = billPaymentRepository.save(existing);
                    log.info("Updated bill payment: billId={}", billId);
                    return updated;
                })
                .orElseThrow(() -> billNotFound(billId));
    }

    // ─── Read ─────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public Optional<Bill_Payment> getBillPaymentById(Long billId) {
        return billPaymentRepository.findById(billId);
    }

    @Transactional(readOnly = true)
    public List<Bill_Payment> getAllBillPayments() {
        return billPaymentRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Bill_Payment> getBillsByUserId(Long userId) {
        return billPaymentRepository.findByUserId(userId);
    }

    /**
     * FIX: moved here from BillPaymentController which was querying the
     * repository directly. Controllers should only talk to services.
     */
    @Transactional(readOnly = true)
    public List<Bill_Payment> getBillsByApartmentId(Long apartmentId) {
        return billPaymentRepository.findByApartmentId(apartmentId);
    }

    @Transactional(readOnly = true)
    public BigDecimal getTotalOutstandingAmount(Long userId) {
        return billPaymentRepository.sumOutstandingByUserId(userId);
    }

    // ─── Status transitions ───────────────────────────────────────────────────

    public Bill_Payment markAsPaid(Long billId, LocalDate paymentDate,
                                   PaymentMethod paymentMethod) {
        log.info("Marking bill as paid: billId={} method={}", billId, paymentMethod);
        return billPaymentRepository.findById(billId)
                .map(bill -> {
                    bill.markAsPaid(paymentDate, paymentMethod);
                    return billPaymentRepository.save(bill);
                })
                .orElseThrow(() -> billNotFound(billId));
    }

    public Bill_Payment markAsOverdue(Long billId) {
        log.info("Marking bill as overdue: billId={}", billId);
        return billPaymentRepository.findById(billId)
                .map(bill -> {
                    bill.markAsOverdue();
                    return billPaymentRepository.save(bill);
                })
                .orElseThrow(() -> billNotFound(billId));
    }

    /**
     * Tenant declares they have paid in cash — sets status to PENDING
     * so the landlord can confirm and call markAsPaid.
     */
    public Bill_Payment declareCashPayment(Long billId) {
        log.info("Cash payment declared: billId={}", billId);
        return billPaymentRepository.findById(billId)
                .map(bill -> {
                    if (bill.getPaymentStatus() != PaymentStatus.UNPAID) {
                        throw new BadRequestException(
                                "Bill is not UNPAID — current status: "
                                        + bill.getPaymentStatus());
                    }
                    bill.setPaymentStatus(PaymentStatus.PENDING);
                    bill.setPaymentMethod(PaymentMethod.CASH);
                    return billPaymentRepository.save(bill);
                })
                .orElseThrow(() -> billNotFound(billId));
    }

    // ─── Late fees ────────────────────────────────────────────────────────────

    public Bill_Payment applyLateFee(Long billId, BigDecimal lateFeeAmount) {
        log.info("Applying late fee: billId={} amount={}", billId, lateFeeAmount);
        validateLateFeeAmount(lateFeeAmount);

        Bill_Payment bill = billPaymentRepository.findById(billId)
                .orElseThrow(() -> billNotFound(billId));

        bill.setLateFee(normalizeCurrencyAmount(lateFeeAmount));
        bill.calculateTotalAmount();

        Bill_Payment updated = billPaymentRepository.save(bill);
        log.info("Late fee applied: billId={} total={}", billId, updated.getTotalAmount());
        return updated;
    }

    /**
     * Mark all UNPAID bills past their due date as OVERDUE.
     * Call this from a @Scheduled job once per day.
     *
     * Example scheduler (add to a new LateFeeScheduler.java):
     *
     *   @Scheduled(cron = "0 0 1 * * *")  // 1 AM daily
     *   public void runDailyOverdueCheck() {
     *       billPaymentService.markOverdueBills();
     *   }
     */
    public int markOverdueBills() {
        LocalDate today = LocalDate.now();
        List<Bill_Payment> unpaid = billPaymentRepository
                .findByPaymentStatus(PaymentStatus.UNPAID);

        int count = 0;
        for (Bill_Payment bill : unpaid) {
            if (bill.getDueDate() != null && bill.getDueDate().isBefore(today)) {
                bill.markAsOverdue();
                billPaymentRepository.save(bill);
                count++;
            }
        }

        log.info("Overdue check complete: {} bills marked overdue", count);
        return count;
    }

    // ─── Payment gateway ──────────────────────────────────────────────────────

    public String getQrFromCharge(String chargeId) {
        return paymentGateway.getQrFromCharge(chargeId);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public boolean isPaymentOverdue(Long billId) {
        return billPaymentRepository.findById(billId)
                .map(Bill_Payment::isOverdue)
                .orElse(false);
    }

    @Transactional(readOnly = true)
    public boolean isPaymentPaid(Long billId) {
        return billPaymentRepository.findById(billId)
                .map(Bill_Payment::isPaid)
                .orElse(false);
    }

    public void deleteBillPayment(Long billId) {
        log.info("Deleting bill payment: billId={}", billId);
        billPaymentRepository.deleteById(billId);
    }

    private ResourceNotFoundException billNotFound(Long billId) {
        log.error("Bill not found: billId={}", billId);
        return new ResourceNotFoundException("Bill not found with ID: " + billId);
    }

    private void validateLateFeeAmount(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BadRequestException("lateFeeAmount must be greater than 0");
        }
    }

    private BigDecimal normalizeCurrencyAmount(BigDecimal amount) {
        return amount.setScale(2, RoundingMode.HALF_UP);
    }
}