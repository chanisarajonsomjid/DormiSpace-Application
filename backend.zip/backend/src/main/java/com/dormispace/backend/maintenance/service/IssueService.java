package com.dormispace.backend.maintenance.service;


import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.model.ContractStatus;
import com.dormispace.backend.maintenance.dto.IssueResponse;
import com.dormispace.backend.maintenance.model.Issue;
import com.dormispace.backend.maintenance.repository.IssueRepository;
import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.room.repository.RoomRepository;
import com.dormispace.backend.user.model.Role;
import com.dormispace.backend.user.model.User;
import com.dormispace.backend.user.repository.UserRepository;
import org.springframework.data.domain.Page;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class IssueService {

    private final IssueRepository issueRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;

    private static final List<String> VALID_STATUSES =
            List.of("Pending", "In Progress", "Completed");

    public Page<IssueResponse> getIssues(AuthenticatedUser user, Pageable pageable) {
        Page<Issue> issues = switch (user.getRole()) {
            case TENANT -> issueRepository.findByUserId(user.getUserId(), pageable);
            case LANDLORD -> issueRepository.findByRoom_Apartment_Landlord_User_Id(
                    user.getUserId(), pageable);
            default -> throw new AccessDeniedException("Access denied");
        };
        return issues.map(this::mapToResponse);
    }

    public IssueResponse createIssue(Long roomId, String title, String description,
                                     AuthenticatedUser authUser) {
        if (authUser.getRole() != Role.TENANT) {
            throw new AccessDeniedException("Tenant only");
        }

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found"));

        Contract activeContract = room.getContracts().stream()
                .filter(c -> c.getStatus() == ContractStatus.ACTIVE)
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No active contract"));

        User user = userRepository.findById(authUser.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Issue issue = new Issue();
        issue.setRoom(room);
        issue.setUser(user);
        issue.setTitle(title);
        issue.setDescription(description);
        issue.setStatus("Pending");
        issue.setCreatedDate(LocalDate.now());
        issue.setTenantFirstName(activeContract.getFirstName());
        issue.setTenantLastName(activeContract.getLastName());

        return mapToResponse(issueRepository.save(issue));
    }

    public IssueResponse updateStatus(Long id, String newStatus, String provider,
                                      String note, BigDecimal expense, AuthenticatedUser user) {  // ← add expense param
        if (user.getRole() != Role.LANDLORD) {
            throw new AccessDeniedException("Landlord only");
        }

        if (newStatus == null || !VALID_STATUSES.contains(newStatus)) {
            throw new IllegalArgumentException("Invalid status: " + newStatus);
        }

        Issue issue = issueRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Issue not found"));

        Long ownerUserId = issue.getRoom().getApartment().getLandlord().getUser().getId();
        if (!ownerUserId.equals(user.getUserId())) {
            throw new AccessDeniedException("Not your issue");
        }

        issue.setStatus(newStatus);
        if (provider != null) issue.setMaintenanceProvider(provider);
        if (note != null) issue.setNote(note);
        if (expense != null) issue.setMaintenanceExpense(expense);  // ← add this

        return mapToResponse(issueRepository.save(issue));
    }

    public IssueResponse updateIssue(Long id, String title, String description) {
        Issue issue = issueRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Issue not found"));

        if (!"Pending".equals(issue.getStatus())) {
            throw new IllegalStateException("Can only edit Pending issues");
        }

        if (title != null) issue.setTitle(title);
        if (description != null) issue.setDescription(description);

        return mapToResponse(issueRepository.save(issue));
    }

    public void deleteIssue(Long id, AuthenticatedUser user) {
        if (user.getRole() != Role.TENANT) {
            throw new AccessDeniedException("Tenant only");
        }

        Issue issue = issueRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Issue not found"));

        if (!issue.getUser().getId().equals(user.getUserId())) {
            throw new AccessDeniedException("Not your issue");
        }

        if (!"Pending".equals(issue.getStatus())) {
            throw new IllegalStateException("Can only delete Pending issues");
        }

        issueRepository.delete(issue);
    }

    // =========================================
    // PRIVATE HELPERS
    // =========================================

    private IssueResponse mapToResponse(Issue issue) {
        String tenantName = buildTenantName(issue);
        return new IssueResponse(
                issue.getId(),
                issue.getTitle(),
                issue.getDescription(),
                issue.getStatus(),
                issue.getMaintenanceExpense(),  // ← add this
                issue.getCreatedDate(),
                issue.getRoom().getRoomId(),
                issue.getRoom().getRoomNumber(),
                tenantName
        );
    }

    private String buildTenantName(Issue issue) {
        String name = (issue.getTenantFirstName() != null ? issue.getTenantFirstName() : "")
                + " "
                + (issue.getTenantLastName() != null ? issue.getTenantLastName() : "");
        return name.trim().isEmpty() ? "Unknown Tenant" : name.trim();
    }
}