package com.dormispace.backend.user.service;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.user.model.User;

public interface UserService {
    User findById(Long id);
    User findByFirebaseUid(String firebaseUid);
    User findOrCreate(AuthenticatedUser authUser);
}
