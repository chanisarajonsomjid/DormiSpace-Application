package com.dormispace.backend.bill.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dormispace.backend.bill.dto.BillSummaryDTO;
import com.dormispace.backend.bill.dto.MonthlyReportDTO;
import com.dormispace.backend.bill.dto.PaymentSummaryDTO;
import com.dormispace.backend.bill.model.Bill_Payment;
import com.dormispace.backend.bill.repository.BillPaymentRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Service for generating reports and analytics
 */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
@Slf4j
public class ReportService {

    private final BillPaymentRepository billPaymentRepository;

    /**
     * Generate monthly report for an apartment
     */
    public MonthlyReportDTO getMonthlyReport(Long apartmentId, YearMonth month) {
        log.info("Generating monthly report for apartment: {} month: {}", apartmentId, month);

        LocalDate startDate = month.atDay(1);
        LocalDate endDate = month.atEndOfMonth();

        List<Bill_Payment> bills = billPaymentRepository.findAll().stream()
                .filter(bill -> bill.getApartmentId().equals(apartmentId))
                .filter(bill -> {
                    LocalDate createdDate = bill.getCreatedDate();
                    return createdDate != null && 
                           !createdDate.isBefore(startDate) && 
                           !createdDate.isAfter(endDate);
                })
                .toList();

        // Count bills by status
        long paidCount = bills.stream().filter(Bill_Payment::isPaid).count();
        long unpaidCount = bills.stream().filter(Bill_Payment::isPending).count();
        long overdueCount = bills.stream().filter(Bill_Payment::isOverdue).count();

        // Calculate totals
        BigDecimal totalAmount = bills.stream()
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalPaid = bills.stream()
                .filter(Bill_Payment::isPaid)
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalUnpaid = bills.stream()
                .filter(Bill_Payment::isPending)
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalOverdue = bills.stream()
                .filter(Bill_Payment::isOverdue)
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalLateFees = bills.stream()
                .map(bill -> bill.getLateFee() != null ? bill.getLateFee() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return MonthlyReportDTO.builder()
                .apartmentId(apartmentId)
                .year(month.getYear())
                .month(month.getMonthValue())
                .totalBills(bills.size())
                .paidBills((int) paidCount)
                .unpaidBills((int) unpaidCount)
                .overdueBills((int) overdueCount)
                .totalAmount(totalAmount)
                .totalPaid(totalPaid)
                .totalUnpaid(totalUnpaid)
                .totalOverdue(totalOverdue)
                .totalLateFees(totalLateFees)
                .reportGeneratedAt(LocalDate.now())
                .build();
    }

    /**
     * Get payment summary for a user
     */
    public PaymentSummaryDTO getPaymentSummary(Long userId) {
        log.info("Generating payment summary for user: {}", userId);

        List<Bill_Payment> bills = billPaymentRepository.findAll().stream()
                .filter(bill -> bill.getUserId().equals(userId))
                .toList();

        // Count bills by status
        long paidCount = bills.stream().filter(Bill_Payment::isPaid).count();
        long unpaidCount = bills.stream().filter(Bill_Payment::isPending).count();
        long overdueCount = bills.stream().filter(Bill_Payment::isOverdue).count();

        // Calculate totals
        BigDecimal totalPaid = bills.stream()
                .filter(Bill_Payment::isPaid)
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalUnpaid = bills.stream()
                .filter(Bill_Payment::isPending)
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalOverdue = bills.stream()
                .filter(Bill_Payment::isOverdue)
                .map(Bill_Payment::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalLateFeesPaid = bills.stream()
                .filter(Bill_Payment::isPaid)
                .map(bill -> bill.getLateFee() != null ? bill.getLateFee() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Get last payment info
        Bill_Payment lastPayment = bills.stream()
                .filter(Bill_Payment::isPaid)
                .max((b1, b2) -> {
                    if (b1.getPaymentDate() == null || b2.getPaymentDate() == null) {
                        return 0;
                    }
                    return b1.getPaymentDate().compareTo(b2.getPaymentDate());
                })
                .orElse(null);

        // Current outstanding balance
        BigDecimal currentOutstanding = totalUnpaid.add(totalOverdue);

        // Convert bills to DTOs
        List<BillSummaryDTO> billSummaries = bills.stream()
                .map(this::convertToBillSummary)
                .collect(Collectors.toList());

        return PaymentSummaryDTO.builder()
                .userId(userId)
                .totalBills(bills.size())
                .paidBills((int) paidCount)
                .unpaidBills((int) unpaidCount)
                .overdueBills((int) overdueCount)
                .totalAmountPaid(totalPaid)
                .totalAmountUnpaid(totalUnpaid)
                .totalAmountOverdue(totalOverdue)
                .totalLateFeesPaid(totalLateFeesPaid)
                .lastPaymentDate(lastPayment != null ? lastPayment.getPaymentDate() : null)
                .lastPaymentAmount(lastPayment != null ? lastPayment.getTotalAmount() : null)
                .lastPaymentMethod(lastPayment != null ? lastPayment.getPaymentMethod() : null)
                .currentOutstandingBalance(currentOutstanding)
                .bills(billSummaries)
                .build();
    }

    /**
     * Get overdue bills report for an apartment
     */
    public List<Bill_Payment> getOverdueReport(Long apartmentId) {
        log.info("Generating overdue report for apartment: {}", apartmentId);

        return billPaymentRepository.findAll().stream()
                .filter(bill -> bill.getApartmentId().equals(apartmentId))
                .filter(Bill_Payment::isOverdue)
                .toList();
    }

    /**
     * Get all unpaid bills for an apartment
     */
    public List<Bill_Payment> getUnpaidBills(Long apartmentId) {
        return billPaymentRepository.findAll().stream()
                .filter(bill -> bill.getApartmentId().equals(apartmentId))
                .filter(bill -> !bill.isPaid())
                .toList();
    }

    /**
     * Get payment history for a user
     */
    public List<Bill_Payment> getPaymentHistory(Long userId) {
        return billPaymentRepository.findAll().stream()
                .filter(bill -> bill.getUserId().equals(userId))
                .filter(Bill_Payment::isPaid)
                .sorted((b1, b2) -> {
                    if (b1.getPaymentDate() == null || b2.getPaymentDate() == null) {
                        return 0;
                    }
                    return b2.getPaymentDate().compareTo(b1.getPaymentDate());
                })
                .toList();
    }

    /**
     * Get collection rate for an apartment (percentage of paid bills)
     */
    public Double getCollectionRate(Long apartmentId, YearMonth month) {
        LocalDate startDate = month.atDay(1);
        LocalDate endDate = month.atEndOfMonth();

        List<Bill_Payment> bills = billPaymentRepository.findAll().stream()
                .filter(bill -> bill.getApartmentId().equals(apartmentId))
                .filter(bill -> {
                    LocalDate createdDate = bill.getCreatedDate();
                    return createdDate != null && 
                           !createdDate.isBefore(startDate) && 
                           !createdDate.isAfter(endDate);
                })
                .toList();

        if (bills.isEmpty()) {
            return 0.0;
        }

        long paidCount = bills.stream().filter(Bill_Payment::isPaid).count();
        return (paidCount * 100.0) / bills.size();
    }

    /**
     * Convert Bill_Payment to BillSummaryDTO
     */
    private BillSummaryDTO convertToBillSummary(Bill_Payment bill) {
        return BillSummaryDTO.builder()
                .billId(bill.getBillId())
                .roomId(bill.getRoomId())
                .createdDate(bill.getCreatedDate())
                .paymentDate(bill.getPaymentDate())
                .receiptDate(bill.getReceiptDate())
                .subtotal(bill.getSubtotal())
                .lateFee(bill.getLateFee())
                .totalAmount(bill.getTotalAmount())
                .paymentStatus(bill.getPaymentStatus())
                .paymentMethod(bill.getPaymentMethod())
                .build();
    }
}
