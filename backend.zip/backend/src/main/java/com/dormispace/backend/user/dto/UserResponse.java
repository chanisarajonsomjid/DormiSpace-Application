package com.dormispace.backend.user.dto;

import com.dormispace.backend.user.model.AccountStatus;
import com.dormispace.backend.user.model.Role;
import com.dormispace.backend.user.model.User;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Getter
@Builder
public class UserResponse {

    private Long id;
    private String email;
    private Role role;
    private AccountStatus accountStatus;
    private OffsetDateTime createdAt;

    public static UserResponse from(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .email(user.getEmail())
                .role(user.getRole())
                .accountStatus(user.getAccountStatus())
                .createdAt(user.getCreatedAt())
                .build();
    }
}