package com.dormispace.backend.contract.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class TenantSignRequest {

    private String firstName;
    private String lastName;
    private String address;
    private String phoneNumber;

    private LocalDate startDate;
    private LocalDate endDate;

    private String signatureTenant;
    private String signatureWitness1;
    private String signatureWitness2;
}