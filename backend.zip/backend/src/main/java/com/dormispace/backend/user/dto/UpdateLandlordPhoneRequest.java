package com.dormispace.backend.user.dto;

import lombok.Data;

@Data
public class UpdateLandlordPhoneRequest {

    private String phoneNumber;

}