package com.dormispace.backend.notification.repository;

import com.dormispace.backend.notification.model.UserDeviceToken;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserDeviceTokenRepository extends JpaRepository<UserDeviceToken, Long> {
    Optional<UserDeviceToken> findByFcmToken(String fcmToken);
    List<UserDeviceToken> findByUserIdAndActiveTrue(Long userId);
}
