package com.dormispace.backend.ocr.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@Service
public class GoogleVisionOcrService {

    @Value("${google.vision.api-key}")
    private String apiKey;

    @Value("${ocr.min-confidence:0.70}")
    private float minConfidence;

    private static final String VISION_URL =
            "https://vision.googleapis.com/v1/images:annotate?key=";

    /**
     * Matches digit groups of 4–8 digits, allowing spaces/dots between groups
     * so OCR-split readings like "0023 456" or "0023.456" are captured whole.
     */
    private static final Pattern METER_DIGITS_PATTERN =
            Pattern.compile("\\d{4,8}(?:[\\s.]*\\d{1,4})*");

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();

    // ─── Public API ───────────────────────────────────────────────────────────

    /**
     * Main entry point. Source hint ("CAMERA" / "GALLERY") is used only for
     * logging — the Vision API call is identical either way. Camera images
     * should be cropped by Flutter before upload; gallery images are processed
     * as-is with a lower-confidence expectation.
     */
    public OcrExtractionResult extractMeterReading(
            MultipartFile imageFile,
            String readingSource   // "CAMERA", "GALLERY", or null
    ) throws IOException {

        String base64Image = Base64.getEncoder().encodeToString(imageFile.getBytes());
        log.info("OCR request: source={} size={}KB", readingSource,
                imageFile.getSize() / 1024);

        String requestBody = buildVisionRequest(base64Image);
        String responseBody = callVisionApi(requestBody);
        return parseResponse(responseBody, readingSource);
    }

    /** Overload for callers that don't supply a source hint. */
    public OcrExtractionResult extractMeterReading(MultipartFile imageFile) throws IOException {
        return extractMeterReading(imageFile, null);
    }

    // ─── Vision API call ──────────────────────────────────────────────────────

    private String buildVisionRequest(String base64Image) {
        /*
         * FIX: Use TEXT_DETECTION, not DOCUMENT_TEXT_DETECTION.
         *
         * DOCUMENT_TEXT_DETECTION is optimised for dense, multi-line documents
         * (invoices, forms). It applies layout analysis that actively hurts
         * meter reading by trying to infer paragraph/block structure from what
         * is essentially a single row of digits.
         *
         * TEXT_DETECTION is optimised for sparse text in natural scenes —
         * exactly what a meter display is.
         *
         * This change alone is the single highest-impact fix for accuracy.
         */
        return """
                {
                  "requests": [{
                    "image": { "content": "%s" },
                    "features": [
                      { "type": "TEXT_DETECTION", "maxResults": 1 }
                    ],
                    "imageContext": {
                      "languageHints": ["en"],
                      "textDetectionParams": {
                        "enableTextDetectionConfidenceScore": true
                      }
                    }
                  }]
                }
                """.formatted(base64Image);
    }

    private String callVisionApi(String requestBody) throws IOException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(VISION_URL + apiKey))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        HttpResponse<String> response;
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Vision API call interrupted", e);
        }

        if (response.statusCode() != 200) {
            log.error("Vision API error {}: {}", response.statusCode(), response.body());
            throw new RuntimeException("Vision API returned " + response.statusCode());
        }

        return response.body();
    }

    // ─── Response parsing ─────────────────────────────────────────────────────

    private OcrExtractionResult parseResponse(String responseBody,
                                              String readingSource) throws IOException {
        JsonNode root = objectMapper.readTree(responseBody);
        JsonNode responseNode = root.path("responses").get(0);

        // Surface any Vision API-level error
        JsonNode apiError = responseNode.path("error");
        if (!apiError.isMissingNode()) {
            String errMsg = apiError.path("message").asText("Unknown Vision API error");
            log.error("Vision API returned an error: {}", errMsg);
            return OcrExtractionResult.notFound("Vision API error: " + errMsg);
        }

        JsonNode textAnnotations = responseNode.path("textAnnotations");
        if (textAnnotations.isMissingNode() || textAnnotations.isEmpty()) {
            return OcrExtractionResult.notFound("No text detected in the image.");
        }

        String fullText = textAnnotations.get(0).path("description").asText();
        log.info("OCR full text:\n{}", fullText);

        // ── FIX: read real per-symbol confidence from fullTextAnnotation ──────
        float apiConfidence = extractApiConfidence(responseNode);
        log.info("Vision API confidence score: {}", apiConfidence);

        // Normalise common OCR mis-reads before digit extraction
        String normalised = normaliseOcrText(fullText);
        log.info("OCR normalised text:\n{}", normalised);

        List<String> candidates = extractDigitCandidates(normalised);
        log.info("Digit candidates: {}", candidates);

        if (candidates.isEmpty()) {
            return OcrExtractionResult.notFound(
                    "Text detected but no meter number found.\nRaw: " + fullText);
        }

        // ── FIX: keep leading zeros in the pipeline until the very last step ──
        // selectBestCandidate scoring relies on leading zeros to distinguish
        // real meter readings from serial numbers. Do NOT strip them here.
        String bestDigits = selectBestCandidate(candidates);
        log.info("Selected candidate (with leading zeros): {}", bestDigits);

        int bestValue = parseMeterValue(bestDigits);
        log.info("Final parsed meter reading: {}", bestValue);

        // Combine API confidence with structural heuristic:
        // A 6-digit reading starting with "00" might be a 7-digit meter with
        // one black digit dropped — downgrade confidence to flag for review.
        boolean structurallyComplete = !(bestDigits.length() == 6
                && bestDigits.startsWith("00"));
        float finalConfidence = computeFinalConfidence(apiConfidence, structurallyComplete);

        boolean meetsThreshold = finalConfidence >= minConfidence;

        log.info("Final confidence={} meetsThreshold={} source={}",
                finalConfidence, meetsThreshold, readingSource);

        return OcrExtractionResult.found(
                bestValue, finalConfidence, fullText,
                meetsThreshold, readingSource);
    }

    /**
     * FIX: Read the real confidence from Vision API's fullTextAnnotation.
     *
     * Vision API returns per-symbol confidence at:
     *   fullTextAnnotation.pages[].blocks[].paragraphs[].words[].symbols[].confidence
     *
     * We average all symbol confidences to get an overall image confidence.
     * Falls back to -1f if the path is missing (TEXT_DETECTION on simple
     * images sometimes omits fullTextAnnotation — the textAnnotations array
     * is still populated and usable).
     */
    private float extractApiConfidence(JsonNode responseNode) {
        JsonNode pages = responseNode
                .path("fullTextAnnotation")
                .path("pages");

        if (pages.isMissingNode() || pages.isEmpty()) {
            log.debug("fullTextAnnotation not present — using heuristic confidence only");
            return -1f; // sentinel: no API confidence available
        }

        double sum = 0;
        int count = 0;

        for (JsonNode page : pages) {
            for (JsonNode block : page.path("blocks")) {
                for (JsonNode para : block.path("paragraphs")) {
                    for (JsonNode word : para.path("words")) {
                        for (JsonNode symbol : word.path("symbols")) {
                            JsonNode conf = symbol.path("confidence");
                            if (!conf.isMissingNode()) {
                                sum += conf.asDouble();
                                count++;
                            }
                        }
                    }
                }
            }
        }

        return count > 0 ? (float) (sum / count) : -1f;
    }

    /**
     * Combine API confidence with structural heuristic.
     * - If API confidence is available, weight it 70% and heuristic 30%.
     * - If API confidence is missing (-1), fall back to heuristic only.
     */
    private float computeFinalConfidence(float apiConfidence,
                                         boolean structurallyComplete) {
        float heuristic = structurallyComplete ? 0.90f : 0.60f;
        if (apiConfidence < 0) {
            return heuristic;
        }
        return (apiConfidence * 0.7f) + (heuristic * 0.3f);
    }

    // ─── OCR normalisation ────────────────────────────────────────────────────

    private String normaliseOcrText(String text) {
        return text
                .replaceAll("(?<=\\d)[Oo](?=\\d)", "0")
                .replaceAll("(?<=\\d)[Oo]$",        "0")
                .replaceAll("^[Oo](?=\\d)",          "0")
                .replaceAll("(?<=\\d)[Il|](?=\\d)",  "1")
                .replaceAll("(?<=\\d)[S](?=\\d)",    "5")
                .replaceAll("(?<=\\d)[B](?=\\d)",    "8")
                .replaceAll("(?<=\\d)[G](?=\\d)",    "6")
                .replaceAll("(\\d)\\.(\\d)",         "$1$2");
    }

    // ─── Candidate extraction ─────────────────────────────────────────────────

    private List<String> extractDigitCandidates(String text) {
        List<String> candidates = new ArrayList<>();

        for (String line : text.split("\\r?\\n")) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;

            if (trimmed.matches(".*[×*]0+[.,]?0*\\d*.*")) continue;
            if (trimmed.matches(".*m³.*") || trimmed.matches(".*[Qq][=1].*")) continue;
            if (trimmed.toLowerCase().matches(".*ss\\s*\\d.*")) continue;

            Matcher matcher = METER_DIGITS_PATTERN.matcher(trimmed);
            while (matcher.find()) {
                // FIX: preserve leading zeros — only strip non-digit separators,
                // NOT leading zeros. The scoring in selectBestCandidate needs them.
                String digits = matcher.group().replaceAll("[^\\d]", "");
                if (digits.length() >= 4) {
                    candidates.add(digits);
                }
            }
        }
        return candidates;
    }

    // ─── Candidate selection ──────────────────────────────────────────────────

    /**
     * Score each candidate and return the best one.
     * Leading zeros are intentionally preserved at this stage.
     * They are the primary signal distinguishing meter readings
     * (e.g. "0028533") from serial/model numbers (e.g. "6413").
     */
    private String selectBestCandidate(List<String> candidates) {
        String best = null;
        int bestScore = Integer.MIN_VALUE;

        for (String digits : candidates) {
            int score = 0;
            int len   = digits.length();

            if (digits.startsWith("00"))     score += 10;
            else if (digits.startsWith("0")) score += 6;
            else                             score -= 8;

            if (len == 7 || len == 8)        score += 4;
            else if (len == 4 || len == 5)   score += 2;
            else                             score -= 2;

            log.info("Candidate '{}' len={} score={}", digits, len, score);

            if (score > bestScore) {
                bestScore = score;
                best = digits;
            }
        }

        return best != null ? best : candidates.getFirst();
    }

    // ─── Value parsing ────────────────────────────────────────────────────────

    /**
     * Convert the selected digit string (still with leading zeros) into an
     * integer reading. Leading zeros are stripped only here, at the final step,
     * after scoring has already used them.
     *
     * Format detection by length:
     *   8 → 5 black + 3 red decimal digits → take first 5
     *   7 → 4 black + 3 red decimal digits → take first 4
     *   6 → 3 black + 3 red decimal digits → take first 3
     *   4–5 → no decimal strip
     *   other → treat as plain integer
     */
    private int parseMeterValue(String digits) {
        String integerPart = switch (digits.length()) {
            case 8 -> digits.substring(0, 5);
            case 7 -> digits.substring(0, 4);
            case 6 -> digits.substring(0, 3);
            default -> digits;
        };

        // Strip leading zeros only here — safe because scoring is already done
        integerPart = integerPart.replaceFirst("^0+", "");
        if (integerPart.isEmpty()) integerPart = "0";

        return Integer.parseInt(integerPart);
    }

    // ─── Result record ────────────────────────────────────────────────────────

    public record OcrExtractionResult(
            Integer value,
            Float   confidence,
            String  rawText,
            boolean found,
            boolean meetsThreshold,
            String  message,
            String  readingSource   // "CAMERA", "GALLERY", or null
    ) {
        static OcrExtractionResult found(int value, float confidence,
                                         String raw, boolean meetsThreshold,
                                         String readingSource) {
            String msg = meetsThreshold
                    ? "Reading extracted successfully."
                    : String.format(
                    "Low confidence (%.0f%%). Please verify the reading.",
                    confidence * 100);
            return new OcrExtractionResult(
                    value, confidence, raw, true, meetsThreshold, msg, readingSource);
        }

        static OcrExtractionResult notFound(String message) {
            return new OcrExtractionResult(
                    null, 0f, null, false, false, message, null);
        }
    }
}