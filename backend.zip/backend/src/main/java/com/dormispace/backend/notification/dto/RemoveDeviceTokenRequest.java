package com.dormispace.backend.notification.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RemoveDeviceTokenRequest {
    @NotBlank
    private String fcmToken;
}
