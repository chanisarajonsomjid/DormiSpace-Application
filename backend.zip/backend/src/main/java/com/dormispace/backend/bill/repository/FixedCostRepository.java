package com.dormispace.backend.bill.repository;

import com.dormispace.backend.bill.model.Fixed_Cost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Fixed_Cost entity
 */
@Repository
public interface FixedCostRepository extends JpaRepository<Fixed_Cost, Long> {

    /**
     * Find all fixed costs for a specific apartment
     */
    List<Fixed_Cost> findByApartmentId(Long apartmentId);

    /**
     * Find fixed costs by apartment and type
     */
    List<Fixed_Cost> findByApartmentIdAndFixedcostType(Long apartmentId, String fixedcostType);

    /**
     * Find metered costs for apartment (water, electricity)
     */
    List<Fixed_Cost> findByApartmentIdAndIsMetered(Long apartmentId, Boolean isMetered);

    /**
     * Find fixed costs that apply to a specific entity type
     */
    List<Fixed_Cost> findByApartmentIdAndAppliesTo(Long apartmentId, String appliesTo);

    /**
     * Find water cost for apartment
     */
    Optional<Fixed_Cost> findByApartmentIdAndFixedcostTypeIgnoreCase(Long apartmentId, String type);
}