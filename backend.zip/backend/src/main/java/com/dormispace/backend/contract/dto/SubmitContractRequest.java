package com.dormispace.backend.contract.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubmitContractRequest {

    private String firstName;
    private String lastName;
    private String address;
    private String phoneNumber;
    private String signatureTenant;

    private String witness1FirstName;
    private String witness1LastName;
    private String signatureWitness1;
    private String witness2FirstName;
    private String witness2LastName;
    private String signatureWitness2;
}
