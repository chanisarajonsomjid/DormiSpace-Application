package com.dormispace.backend.notification.model;

public enum DevicePlatform {
    IOS,
    ANDROID,
    WEB,
    UNKNOWN
}
