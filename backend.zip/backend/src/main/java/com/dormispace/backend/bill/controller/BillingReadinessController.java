package com.dormispace.backend.bill.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.bill.dto.BillingReadinessResponse;
import com.dormispace.backend.bill.service.BillingReadinessService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/billing-readiness")  // ← was "/api/bills"
@RequiredArgsConstructor
public class BillingReadinessController {

    private final BillingReadinessService billingReadinessService;

    @GetMapping("/apartment/{apartmentId}/readiness")
    public ResponseEntity<BillingReadinessResponse> getBillingReadiness(
            @PathVariable Long apartmentId,
            @AuthenticationPrincipal AuthenticatedUser user
    ) {
        return ResponseEntity.ok(
                billingReadinessService.getBillingReadiness(apartmentId, user)
        );
    }
}