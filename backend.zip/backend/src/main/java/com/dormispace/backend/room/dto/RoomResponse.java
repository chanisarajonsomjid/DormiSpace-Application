package com.dormispace.backend.room.dto;

import com.dormispace.backend.room.model.Room;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
public class RoomResponse {

    private Long roomId;
    private String roomNumber;
    private BigDecimal monthlyRent;

    public RoomResponse(Room room) {
        this.roomId = room.getRoomId();
        this.roomNumber = room.getRoomNumber();
        this.monthlyRent = room.getMonthlyRent();
    }
}