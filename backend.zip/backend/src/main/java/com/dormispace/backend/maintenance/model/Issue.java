package com.dormispace.backend.maintenance.model;

import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.user.model.User;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name = "maintenance_request", schema = "public")
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "request_Id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "room_Id", nullable = false)
    private Room room;

    @ManyToOne
    @JoinColumn(name = "user_Id", nullable = false)
    private User user;

    @Column(name = "m_title", length = 100)
    private String title;

    @Column(name = "m_description")
    private String description;

    @Column(name = "m_status")
    private String status;

    @Column(name = "created_date")
    private LocalDate createdDate;

    @Column(name = "maintenance_provider", length = 150)
    private String maintenanceProvider;

    @Column(name = "maintenance_expense", precision = 10, scale = 2)
    private BigDecimal maintenanceExpense;

    @Column(name = "note")
    private String note;

    @Column(name = "tenant_first_name")
    private String tenantFirstName;

    @Column(name = "tenant_last_name")
    private String tenantLastName;
}