package com.dormispace.backend.bill.repository;

import com.dormispace.backend.bill.model.Electricity_Meter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ElectricityMeterRepository extends JpaRepository<Electricity_Meter, Long> {

    // Latest reading for a room regardless of date (used by enforceCorrectPreviousRead)
    Optional<Electricity_Meter> findTopByRoomIdOrderByReadingDateDesc(Long roomId);

    // Scoped to a billing month — used by BillCalculationService
    Optional<Electricity_Meter> findTopByRoomIdAndReadingDateBetweenOrderByReadingDateDesc(
            Long roomId, LocalDate start, LocalDate end);

    // FIX: replaces findAll().stream().filter() in getTotalElectricityUsageForRoom
    @Query("SELECT COALESCE(SUM(m.usedElecUnit), 0) FROM Electricity_Meter m " +
            "WHERE m.roomId = :roomId AND m.usedElecUnit IS NOT NULL")
    Integer sumUsedUnitsByRoomId(@Param("roomId") Long roomId);

    // FIX: replaces findAll().stream().filter() in getAverageMonthlyUsageForRoom
    @Query("SELECT AVG(m.usedElecUnit) FROM Electricity_Meter m " +
            "WHERE m.roomId = :roomId AND m.usedElecUnit IS NOT NULL")
    Double avgUsedUnitsByRoomId(@Param("roomId") Long roomId);

    // FIX: replaces findAll().stream().filter() in getTotalElectricityCostForRoom
    @Query("SELECT COALESCE(SUM(m.totalElectricityPrice), 0) FROM Electricity_Meter m " +
            "WHERE m.roomId = :roomId AND m.totalElectricityPrice IS NOT NULL")
    BigDecimal sumTotalPriceByRoomId(@Param("roomId") Long roomId);

    boolean existsByRoomIdAndReadingDateBetween(
            Long roomId,
            LocalDate start,
            LocalDate end
    );

    List<Electricity_Meter> findByRoomIdInAndReadingDateBetween(List<Long> roomIds, LocalDate start, LocalDate end);
}