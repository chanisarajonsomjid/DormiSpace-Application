package com.dormispace.backend.contract.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class FileStorageService {

    private final String uploadDir = "uploads/contracts/";

    public String save(byte[] fileBytes, String fileName) {

        try {
            Path directory = Paths.get(uploadDir);
            Files.createDirectories(directory);

            Path filePath = directory.resolve(fileName);
            Files.write(filePath, fileBytes);

            return filePath.toAbsolutePath().toString();

        } catch (IOException e) {
            throw new RuntimeException("File saving failed");
        }
    }
}
