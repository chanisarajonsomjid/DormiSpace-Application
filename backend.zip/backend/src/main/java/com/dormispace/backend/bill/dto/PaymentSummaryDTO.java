package com.dormispace.backend.bill.dto;

import com.dormispace.backend.bill.model.PaymentMethod;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * DTO for user payment summary
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentSummaryDTO {
    private Long userId;
    private String userName;
    
    // Overall statistics
    private Integer totalBills;
    private Integer paidBills;
    private Integer unpaidBills;
    private Integer overdueBills;
    
    // Financial summary
    private BigDecimal totalAmountPaid;
    private BigDecimal totalAmountUnpaid;
    private BigDecimal totalAmountOverdue;
    private BigDecimal totalLateFeesPaid;
    
    // Payment history
    private LocalDate lastPaymentDate;
    private BigDecimal lastPaymentAmount;
    private PaymentMethod lastPaymentMethod;
    
    // Current status
    private BigDecimal currentOutstandingBalance;
    private LocalDate nextDueDate;
    
    // Detailed bills
    private List<BillSummaryDTO> bills;
}