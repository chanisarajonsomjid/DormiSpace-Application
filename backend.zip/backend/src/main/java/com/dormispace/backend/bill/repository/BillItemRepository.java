package com.dormispace.backend.bill.repository;

import com.dormispace.backend.bill.model.Bill_Item;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BillItemRepository extends JpaRepository<Bill_Item, Long> {
    List<Bill_Item> findByBillId(Long billId);
}
