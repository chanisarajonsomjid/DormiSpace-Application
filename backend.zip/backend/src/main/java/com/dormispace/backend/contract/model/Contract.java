package com.dormispace.backend.contract.model;

import com.dormispace.backend.room.model.Room;
import com.dormispace.backend.user.model.User;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Entity
@Table(name = "tenant_contracts")
@Getter
@Setter
public class Contract {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long contractId;

    // -------- Relations --------

    // Tenant (nullable until tenant fills contract)
    @ManyToOne(optional = false)
    @JoinColumn(name = "tenant_id", nullable = false)
    private User tenant;

    @ManyToOne
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;

    // -------- Tenant info --------

    @Column(name = "c_first_name", length = 100)
    private String firstName;

    @Column(name = "c_last_name", length = 100)
    private String lastName;

    @Column(name = "c_address")
    private String address;

    @Column(name = "c_phone_num")
    private String phoneNumber;

    @Column(name = "c_rental_rate", precision = 10, scale = 2)
    private BigDecimal rentalRate;

    @Column(name = "c_deposit_amount", precision = 10, scale = 2)
    private BigDecimal depositAmount;

    @Column(name = "c_type")
    private String contractType; // MONTHLY / YEARLY (simple for now)

    @Enumerated(EnumType.STRING)
    @Column(name = "c_status", nullable = false)
    private ContractStatus status;

    @Column(name = "c_start_date")
    private LocalDate startDate;

    @Column(name = "c_end_date")
    private LocalDate endDate;

    @Column(name = "witness1_first_name", length = 100)
    private String witness1FirstName;

    @Column(name = "witness1_last_name", length = 100)
    private String witness1LastName;

    @Column(name = "witness2_first_name", length = 100)
    private String witness2FirstName;

    @Column(name = "witness2_last_name", length = 100)
    private String witness2LastName;

    // -------- Signatures (Base64) --------

    @Column(name = "signature_tenant", columnDefinition = "TEXT")
    private String signatureTenant;

    @Column(name = "signature_witness1", columnDefinition = "TEXT")
    private String signatureWitness1;

    @Column(name = "signature_witness2", columnDefinition = "TEXT")
    private String signatureWitness2;

    @Column(name = "signature_landlord", columnDefinition = "TEXT")
    private String signatureLandlord;

    @Column(name = "invitation_token")
    private String invitationToken;

    @Column(name = "token_expires_at")
    private LocalDateTime tokenExpiresAt;

    @Column(name = "invitation_sent_at")
    private LocalDateTime invitationSentAt;

    @Column(name = "invitation_status")
    private String invitationStatus = "PENDING";

    // -------- Metadata --------

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "signed_tenant_at")
    private LocalDateTime signedTenantAt;

    @Column(name = "signed_landlord_at")
    private LocalDateTime signedLandlordAt;

    @Column(name = "locked_at")
    private LocalDateTime lockedAt;

    @Column(name = "final_pdf_url")
    private String finalPdfUrl;

    @Column(name = "final_pdf_hash")
    private String finalPdfHash;

    @PrePersist
    protected void onCreate() {
        this.createdAt = OffsetDateTime.now();
    }

}