package com.dormispace.backend.room.model;

public enum RoomStatus {
    VACANT,
    PENDING_TENANT,
    PENDING_LANDLORD,
    OCCUPIED
}
