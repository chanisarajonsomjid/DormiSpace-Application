package com.dormispace.backend.contract.controller;

import com.dormispace.backend.auth.dto.AuthenticatedUser;
import com.dormispace.backend.contract.dto.CreateContractRequest;
import com.dormispace.backend.contract.dto.SubmitContractRequest;
import com.dormispace.backend.contract.model.Contract;
import com.dormispace.backend.contract.model.ContractStatus;
import com.dormispace.backend.contract.repository.ContractRepository;
import com.dormispace.backend.contract.service.ContractService;
import com.dormispace.backend.contract.service.PdfService;
import com.dormispace.backend.user.model.Role;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/contracts")
@RequiredArgsConstructor
public class ContractController {

    private final ContractService contractService;
    private final ContractRepository contractRepository;
    private final PdfService pdfService;

    // Landlord: invite tenant
    @PostMapping("/invite")
    public ResponseEntity<?> createContractWithInvitation(
            @RequestBody CreateContractRequest request,
            Authentication authentication
    ) {
        System.out.println(">>> CONTROLLER HIT /api/contracts/invite");

        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthenticated");
        }

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        if (user.getRole() != Role.LANDLORD) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body("Only landlord can create contract");
        }

        if (request.getRoomId() == null || request.getTenantEmail() == null) {
            return ResponseEntity
                    .badRequest()
                    .body("Room ID and tenant email are required");
        }

        // Get contractId back from service
        Long contractId = contractService.createContractAndSendInvitation(
                user,
                request.getRoomId(),
                request.getTenantEmail(),
                request.getStartDate(),
                request.getEndDate(),
                request.getRentalRate(),
                request.getDepositAmount(),
                request.getContractType()
        );

        // Return contractId in response
        return ResponseEntity.ok(Map.of(
                "message", "Invitation sent successfully",
                "contractId", contractId
        ));
    }

    @PostMapping("/{contractId}/resend-invitation")
    public ResponseEntity<?> resendInvitation(
            @PathVariable Long contractId,
            HttpServletRequest request
    ) {
        AuthenticatedUser user = (AuthenticatedUser) request.getAttribute("authUser");

        if (user == null || user.getRole() != Role.LANDLORD) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Landlord only");
        }

        contractService.resendInvitation(contractId, user.getUserId());
        return ResponseEntity.ok("Invitation resent successfully");
    }

    // Tenant: get my contract
    @GetMapping("/my")
    public ResponseEntity<?> getMyContract(Authentication authentication) {

        System.out.println(">>> HIT /api/contracts/my");

        if (authentication == null) {
            System.out.println(">>> authentication is NULL");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthenticated");
        }

        System.out.println(">>> auth class = " + authentication.getClass().getName());
        System.out.println(">>> isAuthenticated = " + authentication.isAuthenticated());

        Object principal = authentication.getPrincipal();
        System.out.println(">>> principal = " + principal);

        if (!(principal instanceof AuthenticatedUser user)) {
            System.out.println(">>> principal is not AuthenticatedUser, it is: " +
                    (principal == null ? "null" : principal.getClass().getName()));
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid principal");
        }

        System.out.println(">>> userId=" + user.getUserId() + " email=" + user.getEmail() + " role=" + user.getRole());

        if (user.getRole() != Role.TENANT) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Tenant only");
        }

        return ResponseEntity.ok(contractService.getMyContract(user.getUserId()));
    }

    // Tenant: update my phone number in profile page
    @PutMapping("/me/phone")
    public ResponseEntity<?> updatePhone(
            @RequestBody Map<String, String> body,
            Authentication authentication
    ) {
        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        if (user.getRole() != Role.TENANT) {
            throw new AccessDeniedException("Tenant only");
        }

        String newPhone = body.get("phoneNumber");

        if (newPhone == null || newPhone.isBlank()) {
            return ResponseEntity.badRequest().build();
        }

        Contract activeContract = contractRepository
                .findByTenant_IdAndStatus(user.getUserId(), ContractStatus.ACTIVE)
                .orElseThrow(() -> new RuntimeException("No active contract"));

        activeContract.setPhoneNumber(newPhone);

        contractRepository.save(activeContract);

        return ResponseEntity.ok().build();
    }


    // Tenant: submit a contract
    @PutMapping("/{contractId}/submit")
    public ResponseEntity<?> submitContract(
            @PathVariable Long contractId,
            @RequestBody SubmitContractRequest request,
            Authentication authentication
    ) {

        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Unauthenticated");
        }

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        if (user.getRole() != Role.TENANT) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Tenant only");
        }

        try {
            contractService.submitContract(
                    contractId,
                    user.getUserId(),
                    request
            );

            return ResponseEntity.ok(Map.of(
                    "message", "Contract submitted successfully",
                    "status", "PENDING_LANDLORD"
            ));

        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Landlord: get my contracts
    @GetMapping("/landlord")
    public ResponseEntity<?> getLandlordContracts(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthenticated");
        }

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        if (user.getRole() != Role.LANDLORD) {
            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body("Landlord only");
        }

        return ResponseEntity.ok(
                contractService.getLandlordContracts(user.getUserId())
        );
    }

    // Tenant / Landlord: get contract by ID
    @GetMapping("/{contractId}")
    public ResponseEntity<?> getContractById(
            @PathVariable Long contractId,
            Authentication authentication
    ) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body("Unauthenticated");
        }

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        return ResponseEntity.ok(
                contractService.getContractResponseForUser(contractId, user)
        );
    }

    @PutMapping("/{contractId}/landlord-sign")
    public ResponseEntity<?> landlordSign(
            @PathVariable Long contractId,
            @RequestBody Map<String, String> payload,
            Authentication authentication
    ) {

        if (authentication == null || !authentication.isAuthenticated()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Unauthenticated");
        }

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        if (user.getRole() != Role.LANDLORD) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Landlord only");
        }

        try {
            contractService.landlordSign(
                    contractId,
                    user.getUserId(),
                    payload.get("signatureLandlord")
            );

            return ResponseEntity.ok(Map.of(
                    "message", "Contract activated",
                    "status", "ACTIVE"
            ));

        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

//    @GetMapping("/{id}/download")
//    public ResponseEntity<Resource> downloadContract(
//            @PathVariable Long id,
//            Authentication authentication
//    ) {
//        if (authentication == null || !authentication.isAuthenticated()) {
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
//        }
//
//        AuthenticatedUser user =
//                (AuthenticatedUser) authentication.getPrincipal();
//
//        Contract contract =
//                contractService.getContractByIdForUser(id, user);
//
//        // Must be ACTIVE
//        if (contract.getStatus() != ContractStatus.ACTIVE) {
//            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                    .body(null);
//        }
//
//        // 🔴 IMPORTANT: Null guard
//        String pdfPath = contract.getFinalPdfUrl();
//        if (pdfPath == null || pdfPath.isBlank()) {
//            return ResponseEntity.status(HttpStatus.CONFLICT)
//                    .body(null);
//        }
//
//        Path path = Paths.get(pdfPath);
//
//        if (!Files.exists(path)) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND)
//                    .body(null);
//        }
//
//        Resource resource = new FileSystemResource(path);
//
//        return ResponseEntity.ok()
//                .header(HttpHeaders.CONTENT_DISPOSITION,
//                        "attachment; filename=contract_" + id + ".pdf")
//                .contentType(MediaType.APPLICATION_PDF)
//                .body(resource);
//    }

    @GetMapping("/{id}/download")
    public ResponseEntity<byte[]> downloadContract(
            @PathVariable Long id,
            Authentication authentication
    ) {

        AuthenticatedUser user =
                (AuthenticatedUser) authentication.getPrincipal();

        Contract contract =
                contractService.getContractByIdForUser(id, user);

        if (contract.getStatus() != ContractStatus.ACTIVE) {
            return ResponseEntity.badRequest().build();
        }

        byte[] pdfBytes = pdfService.generateFinalContract(contract);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=contract_" + id + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }

    @PostMapping("/{contractId}/cancel")
    public ResponseEntity<?> cancelContract(
            @PathVariable Long contractId,
            Authentication authentication
    ) {
        AuthenticatedUser user = (AuthenticatedUser) authentication.getPrincipal();

        contractService.cancelPendingContract(contractId, user.getUserId());

        return ResponseEntity.ok(Map.of(
                "message", "Contract cancelled"
        ));
    }

}