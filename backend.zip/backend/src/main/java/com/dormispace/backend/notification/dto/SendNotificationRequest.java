package com.dormispace.backend.notification.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class SendNotificationRequest {
    @NotNull
    private Long toUserId;

    @NotBlank
    private String title;

    @NotBlank
    private String body;

    private Map<String, String> data;
}
